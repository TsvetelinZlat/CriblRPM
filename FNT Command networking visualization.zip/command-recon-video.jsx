const { Easing, useComposition, CompositionStage, Captions } = window;

const M = { enter: Easing.easeOutCubic, move: Easing.easeInOutCubic, pop: Easing.easeOutBack };
const tw = (T, a, b, e = M.move) => (T <= a ? 0 : T >= b ? 1 : e((T - a) / (b - a)));
const lerp = (a, b, p) => a + (b - a) * p;
const LIN = (x) => x;
const clampN = (v) => Math.max(0, Math.min(1, v));
const mix = (a, b, p) => `color-mix(in oklch, ${b} ${Math.round(clampN(p) * 100)}%, ${a})`;
const up = (p, d = 14) => ({ opacity: clampN(p), transform: `translateY(${(1 - p) * d}px)` });
const rv = (lt, a, d = 0.4) => tw(lt, a, a + d, M.enter);
const popS = (p) => ({ opacity: clampN(p * 2), transform: `scale(${lerp(0.7, 1, Math.min(1, p))})` });

const SANS = "'IBM Plex Sans', system-ui, sans-serif";
const MONO = "'IBM Plex Mono', ui-monospace, monospace";
const CB = { bg: '#F4F2EE', line: '#E4E1DA', line2: '#CBC7BE', text: '#18213A', dim: '#566079', faint: '#9AA1B0' };
const CORAL = 'oklch(0.66 0.18 35)', CORAL_D = 'oklch(0.50 0.16 35)', CORAL_T = 'oklch(0.95 0.03 35)';
const OKG = 'oklch(0.62 0.15 150)', AMBER_T = 'oklch(0.95 0.05 85)', GREY = '#A3A9B6';
const hc = (h, a) => `oklch(0.6 0.15 ${h}${a ? ' / ' + a : ''})`;
const tint = (h) => `oklch(0.95 0.025 ${h})`;
const deep = (h) => `oklch(0.40 0.12 ${h})`;
const SHADOW = '0 24px 60px rgba(24,33,58,0.14), 0 4px 12px rgba(24,33,58,0.08)';

const IC = {
  doc: <><path d="M6 3h9l4 4v14H6z" /><path d="M15 3v4h4M9 12h7M9 16h7" /></>,
  sheet: <><rect x="4" y="3" width="16" height="18" rx="2" /><path d="M4 9h16M4 15h16M10 3v18" /></>,
  search: <><circle cx="11" cy="11" r="6" /><path d="M16 16l5 5" /></>,
  people: <><circle cx="8" cy="8" r="3" /><circle cx="16.5" cy="8.5" r="2.5" /><path d="M2 20c.5-3.5 3-5.5 6-5.5s5.5 2 6 5.5M14.5 14.6c.6-.1 1.3-.2 2-.2 3 0 5 2 5.5 5.6" /></>,
  warn: <><path d="M12 3l10 18H2z" /><path d="M12 10v5M12 18v.5" /></>,
  shield: <><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z" /><path d="M8.5 12l2.5 2.5 4.5-5" /></>,
  cal: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M3 10h18M8 3v4M16 3v4" /></>,
  mail: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 7l9 6 9-6" /></>,
  pulse: <path d="M3 12h4l2-5 4 10 2-5h6" />,
  db: <><ellipse cx="12" cy="5.5" rx="7" ry="2.5" /><path d="M5 5.5v13c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5v-13" /><path d="M5 12c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5" /></>,
  form: <><rect x="4" y="3" width="16" height="18" rx="2" /><path d="M8 8h8M8 12h8M8 16h5" /></>,
  lock: <><rect x="5" y="11" width="14" height="10" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></>,
  down: <><path d="M12 4v11M7 10l5 5 5-5" /><path d="M4 20h16" /></>,
  link: <><path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1" /><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1" /></>,
  ticket: <><path d="M3 7h18v3a2 2 0 0 0 0 4v3H3v-3a2 2 0 0 0 0-4z" /><path d="M14 7v10" strokeDasharray="2 2" /></>,
  pause: <><circle cx="12" cy="12" r="9" /><path d="M10 8.5v7M14 8.5v7" /></>,
  delta: <path d="M12 4l9 16H3z" />,
  wrench: <path d="M14.5 6.5a4 4 0 0 0-5.2 5.2L3 18l3 3 6.3-6.3a4 4 0 0 0 5.2-5.2l-2.5 2.5-2.5-2.5z" />,
  chat: <path d="M4 5h16v11H9l-5 4z" />,
};
function Icon({ n, s = 32, c = CB.text, w = 2 }) {
  return <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" style={{ flex: 'none', display: 'block' }}>{IC[n]}</svg>;
}
const Dot = ({ col, size = 14 }) => <div style={{ width: size, height: size, borderRadius: size / 2, background: col, flex: 'none' }}></div>;
function Check({ size = 30, col = OKG }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size / 2, background: col, position: 'relative', flex: 'none' }}>
      <div style={{ position: 'absolute', left: size * 0.37, top: size * 0.2, width: size * 0.22, height: size * 0.42, borderRight: `${size * 0.1}px solid #fff`, borderBottom: `${size * 0.1}px solid #fff`, transform: 'rotate(45deg)' }}></div>
    </div>
  );
}
function Box({ p = 0, lock, s = 26 }) {
  if (lock) return <div style={{ width: s, height: s, borderRadius: 6, background: '#ECE9E2', display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none' }}><Icon n="lock" s={s * 0.62} c={CB.faint} /></div>;
  return (
    <div style={{ width: s, height: s, borderRadius: 6, flex: 'none', boxSizing: 'border-box', border: `2px solid ${p > 0.5 ? OKG : CB.line2}`, background: p > 0.5 ? OKG : '#fff', position: 'relative' }}>
      <div style={{ position: 'absolute', left: s * 0.3, top: s * 0.1, width: s * 0.22, height: s * 0.44, borderRight: `${s * 0.1}px solid #fff`, borderBottom: `${s * 0.1}px solid #fff`, transform: `rotate(45deg) scale(${clampN(p)})` }}></div>
    </div>
  );
}
const Arr = ({ w = 40, col = CB.line2 }) => (
  <svg width={w} height="20" style={{ flex: 'none', display: 'block' }}><line x1="2" y1="10" x2={w - 8} y2="10" stroke={col} strokeWidth="3" strokeLinecap="round" /><polyline points={`${w - 14},4 ${w - 6},10 ${w - 14},16`} fill="none" stroke={col} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></svg>
);
const Card = ({ style, children }) => <div style={{ position: 'absolute', background: '#fff', borderRadius: 20, boxShadow: SHADOW, boxSizing: 'border-box', ...style }}>{children}</div>;
function Win({ title, icon, h, children, style, right }) {
  return (
    <Card style={{ left: 0, top: 0, width: 780, height: h, overflow: 'hidden', ...style }}>
      <div style={{ height: 62, display: 'flex', alignItems: 'center', gap: 14, padding: '0 24px', borderBottom: `1px solid ${CB.line}` }}>
        <Icon n={icon} s={24} c={CB.dim} />
        <div style={{ font: `600 20px ${MONO}`, color: CB.text, whiteSpace: 'nowrap', flex: 1, minWidth: 0 }}>{title}</div>
        {right}
      </div>
      <div style={{ position: 'relative', padding: '18px 26px' }}>{children}</div>
    </Card>
  );
}
const Lbl = ({ children, c = CB.dim }) => <div style={{ font: `600 15px ${MONO}`, color: c, letterSpacing: 1.5, textTransform: 'uppercase' }}>{children}</div>;
const Pill = ({ bg, fg, children, s = 1 }) => <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: `${5 * s}px ${14 * s}px`, borderRadius: 30, background: bg, font: `600 ${17 * s}px ${SANS}`, color: fg, whiteSpace: 'nowrap', flex: 'none' }}>{children}</div>;
function Note({ icon = 'warn', col = CORAL_D, bg = CORAL_T, children, style }) {
  return (
    <div style={{ position: 'absolute', display: 'flex', alignItems: 'center', gap: 16, padding: '16px 22px', borderRadius: 16, background: bg, boxSizing: 'border-box', ...style }}>
      <Icon n={icon} s={30} c={col} />
      <div style={{ font: `500 21px ${SANS}`, color: CB.text, lineHeight: 1.35, textWrap: 'pretty' }}>{children}</div>
    </div>
  );
}
function Field({ l, v, p, w = 190, old }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '10px 0', borderBottom: `1px solid ${CB.line}` }}>
      <div style={{ font: `500 19px ${SANS}`, color: CB.dim, width: w, flex: 'none' }}>{l}</div>
      <div style={{ flex: 1, minWidth: 0, height: 42, borderRadius: 8, background: '#fff', border: `1.5px solid ${CB.line2}`, display: 'flex', alignItems: 'center', gap: 14, padding: '0 14px', boxSizing: 'border-box', overflow: 'hidden' }}>
        {old && <div style={{ font: `500 19px ${MONO}`, color: CORAL_D, textDecoration: 'line-through', opacity: p > 0 ? 0.7 : 1 }}>{old}</div>}
        <div style={{ font: `500 19px ${MONO}`, color: CB.text, whiteSpace: 'nowrap', clipPath: `inset(0 ${(1 - p) * 100}% 0 0)` }}>{v}</div>
      </div>
    </div>
  );
}
function Btn({ children, col, press = 0, dim }) {
  return <div style={{ padding: '11px 28px', borderRadius: 12, background: dim ? CB.line : col, font: `600 20px ${SANS}`, color: dim ? CB.faint : '#fff', transform: `scale(${1 - 0.08 * Math.sin(clampN(press) * Math.PI)})`, flex: 'none' }}>{children}</div>;
}

// ---------- person ----------
const SKIN = '#E6B591', HAIR = '#3A2E2A', PANTS = '#2E3650';
const Desk = () => <g><rect x="66" y="186" width="150" height="9" rx="3" fill="#C9CED9" /><rect x="74" y="195" width="8" height="98" fill="#C9CED9" /><rect x="200" y="195" width="8" height="98" fill="#C9CED9" /></g>;
function Person({ pose = 'idle', T, shirt, s = 1 }) {
  const ty = Math.sin(T * 14) * 3, jig = Math.sin(T * 9) * 4;
  let L = [[80, 120], [72, 160], [74, 198]], R = [[140, 120], [148, 160], [146, 198]], back = null, front = null;
  if (pose === 'laptop') {
    L = [[80, 120], [82, 160], [112, 178 + ty]]; R = [[140, 120], [148, 158], [162, 178 - ty]];
    back = <g><Desk /><rect x="98" y="180" width="92" height="7" rx="3" fill="#8C93A6" /><path d="M184 184 L202 128 L210 131 L192 186Z" fill="#3B4359" /><path d="M189 178 L203 136" stroke="oklch(0.75 0.1 205)" strokeWidth="3" /></g>;
  } else if (pose === 'clip') {
    L = [[80, 120], [88, 162], [118, 172]]; R = [[140, 120], [158, 152], [148 + jig, 150]];
    back = <g><rect x="112" y="124" width="54" height="70" rx="5" fill="#fff" stroke="#8C93A6" strokeWidth="3" /><rect x="128" y="119" width="22" height="9" rx="3" fill="#8C93A6" /><path d="M121 142h34M121 154h34M121 166h24" stroke="#C9CED9" strokeWidth="3" /></g>;
    front = <line x1={148 + jig} y1="150" x2={154 + jig} y2="136" stroke="#2E3650" strokeWidth="4" strokeLinecap="round" />;
  } else if (pose === 'point') {
    R = [[140, 118], [172, 104], [200, 88]];
    front = <line x1="200" y1="88" x2="214" y2="80" stroke={SKIN} strokeWidth="6" strokeLinecap="round" />;
  } else if (pose === 'wrench') {
    R = [[140, 120], [166, 142], [188, 124]];
    front = <g transform={`rotate(${jig * 4} 188 124)`}><line x1="188" y1="124" x2="210" y2="98" stroke="#8C93A6" strokeWidth="7" strokeLinecap="round" /><circle cx="212" cy="95" r="8" fill="none" stroke="#8C93A6" strokeWidth="5" /></g>;
  }
  const arm = (P) => <g><path d={`M${P[0][0]} ${P[0][1]} L${P[1][0]} ${P[1][1]} L${P[2][0]} ${P[2][1]}`} fill="none" stroke={shirt} strokeWidth="19" strokeLinecap="round" strokeLinejoin="round" /><circle cx={P[2][0]} cy={P[2][1]} r="9" fill={SKIN} /></g>;
  const leg = (x) => <g><rect x={x} y="196" width="18" height="94" rx="9" fill={PANTS} /><ellipse cx={x + 14} cy="290" rx="15" ry="7" fill="#1C2438" /></g>;
  const bob = Math.sin(T * 2.2) * 1.5;
  return (
    <svg width={220 * s} height={300 * s} viewBox="0 0 220 300" style={{ display: 'block', overflow: 'visible' }}>
      <ellipse cx="112" cy="294" rx="62" ry="8" fill="rgba(24,33,58,0.08)" />
      <g transform={`translate(0 ${bob})`}>
        {leg(86)}{leg(114)}
        <path d="M72 122 Q72 104 90 102 L130 102 Q148 104 148 122 L152 206 Q110 214 68 206 Z" fill={shirt} />
        <rect x="102" y="90" width="16" height="16" fill={SKIN} />
        <circle cx="112" cy="64" r="31" fill={SKIN} />
        <path d="M80 70 Q76 32 112 32 Q142 32 143 58 Q126 46 106 52 Q92 58 90 78 Z" fill={HAIR} />
        <circle cx="118" cy="66" r="3" fill="#2E3650" /><circle cx="134" cy="66" r="3" fill="#2E3650" />
        <path d="M120 80 Q127 85 134 79" fill="none" stroke="#2E3650" strokeWidth="2.5" strokeLinecap="round" />
        {back}{arm(L)}{arm(R)}{front}
      </g>
    </svg>
  );
}
const ROLE = { po: ['PO', 285], team: ['Responsible team', 225] };
function Actor({ T, p, w = 'po', s = 1.1 }) {
  const [l, h] = ROLE[w];
  return (
    <div style={{ width: 220 * s, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
      <Person T={T} pose={p} shirt={hc(h)} s={s} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 16px 6px 12px', borderRadius: 20, background: '#fff', boxShadow: '0 2px 8px rgba(24,33,58,0.1)' }}>
        <Dot col={hc(h)} size={10} /><div style={{ font: `600 18px ${SANS}`, color: CB.text, whiteSpace: 'nowrap' }}>{l}</div>
      </div>
    </div>
  );
}

// ---------- phases ----------
const PH = [
  { n: '01', t: 'Delta report', i: 'delta', h: 255 },
  { n: '02', t: 'The tool', i: 'sheet', h: 225 },
  { n: '03', t: 'Review', i: 'shield', h: 150 },
  { n: '04', t: 'Errors', i: 'warn', h: 35 },
  { n: '05', t: 'Jira', i: 'ticket', h: 285 },
  { n: '06', t: 'Escalation', i: 'people', h: 75 },
];
function Header({ ph, title, o }) {
  const s = PH[ph];
  return (
    <div style={{ position: 'absolute', left: 140, top: 150, display: 'flex', alignItems: 'baseline', gap: 26, ...up(o, -12) }}>
      <div style={{ font: `600 64px ${MONO}`, color: hc(s.h), letterSpacing: -2 }}>{s.n}</div>
      <div style={{ font: `600 48px ${SANS}`, color: CB.text, letterSpacing: -1, whiteSpace: 'nowrap' }}>{title}</div>
    </div>
  );
}
function Tracker({ T, K }) {
  const a = K.It + 4.6;
  const o = tw(T, a, a + 0.8, M.enter) * (1 - tw(T, K.Su - 0.6, K.Su));
  if (o <= 0) return null;
  const marks = [a, K.To, K.Rv, K.Er, K.Ji, K.Es];
  let cur = 0;
  marks.forEach((m, i) => { if (T >= m) cur = i; });
  return (
    <div style={{ position: 'absolute', left: 0, right: 0, top: 44, display: 'flex', justifyContent: 'center', gap: 10, opacity: o }}>
      {PH.map((s, i) => {
        const act = i === cur, done = i < cur;
        return (
          <div key={s.n} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 20px 9px 14px', borderRadius: 30, background: act ? hc(s.h) : '#fff', boxShadow: act ? 'none' : '0 2px 8px rgba(24,33,58,0.08)', opacity: act || done ? 1 : 0.6 }}>
            <Icon n={s.i} s={22} c={act ? '#fff' : done ? hc(s.h) : CB.dim} />
            <div style={{ font: `600 17px ${MONO}`, color: act ? '#fff' : CB.dim }}>{s.n}</div>
            <div style={{ font: `600 18px ${SANS}`, color: act ? '#fff' : CB.text, whiteSpace: 'nowrap' }}>{s.t}</div>
          </div>
        );
      })}
    </div>
  );
}
const span = (T, a, end) => (T < a - 0.1 || T > end + 0.1 ? null : tw(T - a, 0, 0.6, M.enter) * (1 - tw(T, end - 0.6, end)));

// ---------- 01 intro / delta report ----------
const MONTHS = [['Jun', 0], ['Jul', 2], ['Aug', 1], ['Sep', 3], ['Oct', 1], ['Nov', 3]];
function Intro({ T, K }) {
  const t = T - K.It, o = span(T, K.It, K.To);
  if (o == null) return null;
  const ti = tw(t, 0.2, 1.0, M.enter) * (1 - tw(t, 4.0, 4.6));
  const d = t - 4.6;
  const ln = tw(d, 0.6, 1.6);
  const flow = { strokeDasharray: '2 12', strokeDashoffset: -T * 30 };
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      {ti > 0 && (
        <div style={{ position: 'absolute', left: 0, right: 0, top: 330, textAlign: 'center', ...up(ti, 24) }}>
          <Lbl>FNT Command · Monthly reconciliation</Lbl>
          <div style={{ font: `600 112px ${SANS}`, color: CB.text, letterSpacing: -3, marginTop: 14 }}>Command Recon</div>
          <div style={{ font: `400 34px ${SANS}`, color: CB.dim, marginTop: 12 }}>Validate once. After that, review only what changed.</div>
        </div>
      )}
      {d > -0.1 && (
        <div style={{ position: 'absolute', inset: 0, opacity: tw(d, 0, 0.5) }}>
          <Header ph={0} title="The monthly delta report" o={tw(d, 0, 0.7, M.enter)} />
          <div style={{ position: 'absolute', inset: 0, transform: 'translateY(-40px)' }}>
          <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0 }}>
            <line x1="960" y1="440" x2="960" y2={lerp(440, 540, tw(d, 1.0, 1.8))} stroke={hc(255)} strokeWidth="4" strokeLinecap="round" style={flow} />
          </svg>
          <Card style={{ left: 810, top: 330, width: 300, height: 110, padding: '0 26px', display: 'flex', alignItems: 'center', gap: 18, ...up(rv(d, 0.5)) }}>
            <div style={{ width: 56, height: 56, borderRadius: 14, background: tint(255), display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon n="db" s={30} c={hc(255)} /></div>
            <div style={{ font: `600 26px ${SANS}`, color: CB.text }}>FNT Command</div>
          </Card>
          <Card style={{ left: 810, top: 540, width: 300, padding: '18px 22px', ...popS(tw(d, 2.8, 3.4, M.pop)), boxShadow: d > 13.4 ? `0 0 0 3px ${hc(255)}, ${SHADOW}` : SHADOW }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}><Icon n="doc" s={28} c={hc(255)} /><div><Lbl>Delta report</Lbl><div style={{ font: `600 20px ${MONO}`, color: CB.text, marginTop: 2 }}>November 2026</div></div></div>
            {['CHANGED IP', 'CHANGED STATE', 'NEW ASSET'].map((c, i) => (
              <div key={c} style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: i ? 6 : 14, ...up(rv(d, 3.4 + i * 0.25), 6) }}><Dot col={CORAL} size={9} /><div style={{ font: `500 16px ${MONO}`, color: CB.text }}>{c}</div></div>
            ))}
          </Card>
          <div style={{ position: 'absolute', left: 560, top: 600, width: 230, textAlign: 'right', font: `500 19px ${SANS}`, color: CB.dim, lineHeight: 1.35, ...up(rv(d, 4.2)) }}>Changes since the previous validation</div>
          <div style={{ position: 'absolute', left: 1130, top: 580, display: 'flex', flexDirection: 'column', gap: 10, ...up(rv(d, 13.4)) }}>
            <div style={{ font: `500 19px ${SANS}`, color: CB.dim }}>Opened in Command Recon</div>
            <Arr w={360} col={hc(285)} />
          </div>
          <div style={{ position: 'absolute', left: 1520, top: 500, ...up(rv(d, 13.2), 20) }}><Actor T={T} p="laptop" s={1.0} /></div>
          <div style={{ position: 'absolute', left: 200, top: 732, ...up(rv(d, 5.6)) }}><Lbl>Validate once, then only the changes</Lbl></div>
          {MONTHS.map(([m, n], i) => {
            const p = rv(d, 5.9 + i * 0.35);
            const first = i === 0, now = i === 5 && d > 9.0;
            return (
              <div key={m} style={{ position: 'absolute', left: 200 + i * 200, top: 770, width: 184, height: 128, borderRadius: 16, background: '#fff', boxSizing: 'border-box', padding: '12px 16px', boxShadow: now ? `0 0 0 3px ${hc(255)}, ${SHADOW}` : '0 2px 10px rgba(24,33,58,0.08)', ...up(p, 12) }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                  <div style={{ font: `600 18px ${MONO}`, color: CB.text }}>{m}</div>
                  <div style={{ font: `600 15px ${SANS}`, color: first ? deep(150) : CORAL_D }}>{first ? 'All assets' : `${n} changes`}</div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 5, marginTop: 10 }}>
                  {(first ? Array.from({ length: 7 }) : Array.from({ length: n })).map((_, j) => (
                    <div key={j} style={{ height: 7, borderRadius: 4, width: first ? `${70 + ((j * 13) % 30)}%` : `${60 + j * 12}%`, background: first ? mix(CB.line, OKG, rv(d, 6.3 + j * 0.12)) : CORAL }}></div>
                  ))}
                </div>
              </div>
            );
          })}
          </div>
          <Note style={{ left: 200, top: 880, width: 1184, padding: '12px 20px', ...up(rv(d, 8.6)) }} icon="cal" col={deep(255)} bg={tint(255)}>Validated assets with no changes for <b>365 days</b> must be validated again.</Note>
        </div>
      )}
    </div>
  );
}

// ---------- 02 tool ----------
const COLS = [['cb', 'All', 56], ['act', 'ACTION_CODE', 190], ['vis', 'VISIBLE_ID', 150], ['obj', 'OBJECT_ID', 120], ['cor', 'CORIA_ID', 100], ['po', 'PO', 100], ['tpm', 'TPM', 100], ['st', 'STATE', 140], ['ip', 'IP', 130], ['sn', 'SERIAL_NO', 120], ['mon', 'MONITORING', 120], ['mg', 'MONITORING_GROUP', 180], ['fz', 'FUNCTION_ZONE', 150], ['ty', 'TYPE', 90], ['he', 'HERSTELLER', 120], ['fn', 'FUNCTION', 100], ['sw', 'SW_VERSION', 120], ['ca', 'CAMPUS', 110], ['bu', 'BUILDING', 100], ['fl', 'FLOOR', 76], ['ro', 'ROOM', 80]];
const base = { po: 'a.meyer', tpm: 'k.lang', mon: 'Active', mg: 'NMS-Core', ca: 'Campus 1', fl: '02' };
const P_ROWS = [
  { ...base, act: 'CHANGED IP', vis: 'sw-dc1-r04-01', obj: 'OBJ-48213', cor: 'CR-1182', st: 'Operational', ip: '10.24.8.17', sn: 'SN-100234', fz: 'Core', ty: 'Switch', he: 'Vendor X', fn: 'Access', sw: '17.9.4', bu: 'B12', ro: 'R04', ch: 'ip' },
  { ...base, act: 'CHANGED STATE', vis: 'rt-dc1-r07-02', obj: 'OBJ-48377', cor: 'CR-0954', st: 'Out of service', ip: '10.24.9.3', sn: 'SN-100871', mon: 'None', fz: 'Edge', ty: 'Router', he: 'Vendor Y', fn: 'WAN', sw: '16.12.1', bu: 'B12', ro: 'R07', ch: 'st' },
  { ...base, act: 'CHANGED SW_VERSION', vis: 'fw-dc2-r02-01', obj: 'OBJ-49002', cor: 'CR-1320', st: 'Operational', ip: '10.24.12.40', sn: 'SN-300512', mg: 'NMS-Sec', fz: 'DMZ', ty: 'Firewall', he: 'Vendor Z', fn: 'Security', sw: '9.1.7', bu: 'B14', ro: 'R02', ch: 'sw' },
  { ...base, act: 'CHANGED LOCATION', vis: 'sw-dc2-r11-03', obj: 'OBJ-49518', cor: 'CR-1182', st: 'Operational', ip: '10.24.14.9', sn: 'SN-200871', fz: 'Core', ty: 'Switch', he: 'Vendor X', fn: 'Access', sw: '17.9.4', bu: 'B14', ro: 'R11', ch: 'ro' },
  { ...base, act: 'NEW ASSET', vis: 'rt-dc2-r12-01', obj: 'OBJ-50114', cor: 'CR-0954', st: 'Planning', ip: '10.24.16.2', sn: 'SN-200902', fz: 'Edge', ty: 'Router', he: 'Vendor Y', fn: 'WAN', sw: '16.12.1', bu: 'B14', ro: 'R12', ch: 'act' },
];
const NAVY = '#1C2438';
function Tool({ T, K }) {
  const t = T - K.To, o = span(T, K.To, K.Rv);
  if (o == null) return null;
  const rows = P_ROWS;
  const hi = t >= 7.5 && t < 11 ? 'act' : t >= 11 && t < 13.2 ? 'obj' : t >= 13.2 && t < 15.4 ? 'cor' : null;
  const locHi = t >= 3.0 && t < 6.4;
  const TW = COLS.reduce((x, c) => x + c[2], 0), VW = 1588;
  const sx = (TW - VW) * tw(t, 3.0, 4.4) * (1 - tw(t, 5.4, 6.6));
  const cx = (k) => { let x = 0; for (const c of COLS) { if (c[0] === k) return x; x += c[2]; } return 0; };
  const grid = COLS.map((c) => c[2] + 'px').join(' ');
  const q = 'OBJ-48', qn = Math.round(q.length * tw(t, 15.6, 16.6, LIN));
  const LOC = ['ca', 'bu', 'fl', 'ro'];
  const call = hi === 'obj' ? ['Opens the object in FNT Command', cx('obj'), 'link', 11] : hi === 'cor' ? ['Opens the software product in the architecture portal', cx('cor'), 'link', 13.2] : hi === 'act' ? ['What changed. The changed value is highlighted.', cx('act'), 'delta', 7.5] : null;
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <Header ph={1} title="The Command Recon tool" o={tw(t, 0, 0.7, M.enter)} />
      <Card style={{ left: 140, top: 250, width: 1640, height: 650, overflow: 'hidden', ...up(rv(t, 0.3), 20) }}>
        <div style={{ height: 62, display: 'flex', alignItems: 'center', gap: 14, padding: '0 26px', borderBottom: `1px solid ${CB.line}` }}>
          <Icon n="sheet" s={24} c={CB.dim} />
          <div style={{ font: `600 20px ${MONO}`, color: CB.text, flex: 1 }}>Command Recon</div>
          <div style={{ ...up(rv(t, 6.4), 6) }}><Pill bg={tint(285)} fg={deep(285)}><Icon n="people" s={20} c={deep(285)} />Only assets where you are PO or TPM</Pill></div>
        </div>
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 34, padding: '0 26px', height: 62, borderBottom: `1px solid ${CB.line}` }}>
          <div style={{ paddingBottom: 14, borderBottom: `3px solid ${hc(225)}`, font: `600 21px ${SANS}`, color: CB.text, ...up(rv(t, 0.8), 6) }}>Asset Validation</div>
          <div style={{ flex: 1 }}></div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, paddingBottom: 14, opacity: rv(t, 1.6) }}>
            {['Campus', 'Building', 'Floor', 'Room'].map((l, i) => <React.Fragment key={l}>{i > 0 && <div style={{ font: `500 18px ${SANS}`, color: CB.faint }}>›</div>}<Pill bg={locHi ? hc(225) : tint(225)} fg={locHi ? '#fff' : deep(225)} s={0.9}>{l}</Pill></React.Fragment>)}
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '16px 26px' }}>
          <div style={{ font: `600 22px ${SANS}`, color: CB.text, marginRight: 18 }}>Assets Pending Validation</div>
          <div style={{ width: 320, height: 46, borderRadius: 10, border: `2px solid ${t > 15.4 ? hc(225) : CB.line2}`, display: 'flex', alignItems: 'center', gap: 10, padding: '0 14px', boxSizing: 'border-box' }}>
            <Icon n="search" s={22} c={CB.dim} />
            <div style={{ font: `500 19px ${MONO}`, color: qn ? CB.text : CB.faint }}>{qn ? q.slice(0, qn) : 'Search'}</div>
          </div>
          <div style={{ flex: 1 }}></div>
          {['Excel', 'CSV', 'Copy'].map((l, i) => {
            const p = tw(t, 16.8 + i * 0.3, 17.3 + i * 0.3);
            return <div key={l} style={{ padding: '9px 20px', borderRadius: 10, border: `2px solid ${p > 0 && p < 1 ? hc(225) : CB.line2}`, font: `600 18px ${SANS}`, color: CB.text, transform: `scale(${1 + 0.08 * Math.sin(p * Math.PI)})` }}>{l}</div>;
          })}
        </div>
        <div style={{ position: 'relative', margin: '0 26px', overflow: 'hidden', height: 420 }}>
          <div style={{ width: TW, transform: `translateX(${-sx}px)` }}>
            <div style={{ display: 'grid', gridTemplateColumns: grid, background: NAVY, borderRadius: 8 }}>
              {COLS.map(([k, l]) => {
                const on = hi === k || (locHi && LOC.includes(k));
                return <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '12px 8px', font: `600 13px ${MONO}`, color: '#fff', background: on ? hc(225) : 'transparent', whiteSpace: 'nowrap', overflow: 'hidden', borderLeft: '1px solid rgba(255,255,255,0.12)' }}>{k === 'cb' ? <><Box s={18} />All</> : l}</div>;
              })}
            </div>
            {rows.map((r, j) => (
              <div key={r.obj} style={{ display: 'grid', gridTemplateColumns: grid, alignItems: 'center', borderBottom: `1px solid ${CB.line}`, ...up(rv(t, 1.3 + j * 0.2), 6) }}>
                {COLS.map(([k]) => {
                  const ch = r.ch === k && k !== 'act';
                  const on = hi === k || (locHi && LOC.includes(k));
                  const link = k === 'obj' || k === 'cor';
                  return (
                    <div key={k} style={{ height: 52, display: 'flex', alignItems: 'center', padding: '0 8px', background: on ? tint(225) : ch ? AMBER_T : 'transparent', overflow: 'hidden' }}>
                      {k === 'cb' ? <Box s={20} /> : (
                        <div style={{ font: `${k === 'act' || ch ? 600 : 500} 15px ${MONO}`, color: k === 'act' ? CORAL_D : link ? hc(255) : CB.text, textDecoration: link ? 'underline' : 'none', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r[k]}</div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
          <div style={{ position: 'absolute', right: 0, top: 0, bottom: 0, width: 80, background: 'linear-gradient(90deg, rgba(255,255,255,0), #fff)', opacity: sx < TW - VW - 1 ? 1 : 0 }}></div>
          {call && (
            <div key={hi} style={{ position: 'absolute', top: 340, left: Math.min(call[1], 900), display: 'flex', alignItems: 'center', gap: 12, padding: '12px 20px', borderRadius: 14, background: CB.text, ...up(tw(t - call[3], 0, 0.4, M.enter), 8) }}>
              <Icon n={call[2]} s={22} c="#fff" /><div style={{ font: `600 20px ${SANS}`, color: '#fff', whiteSpace: 'nowrap' }}>{call[0]}</div>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}

// ---------- 03 review ----------
const RV = [
  { p: 'laptop', t: 'Correct: tick the asset', s: 'Checkbox or click the row. "All" selects only the current page.' },
  { p: 'laptop', t: 'Save: the PDF downloads', s: 'One PDF per tab, named with the date.' },
  { p: 'point', t: 'Attach it to the monthly task', s: 'The FNT Command Reconciliation task for the given month.' },
  { p: 'laptop', t: 'Wrong: do not tick', s: 'Create a Jira ticket for the responsible team, describe the problem and assign it.' },
  { w: 'team', p: 'wrench', t: 'Fix in Command, revalidate', s: 'The data is corrected in FNT Command, then the asset is validated.' },
  { p: 'laptop', t: 'No changes this month', s: 'No PDF. Just a comment in Jira.' },
];
const RV_ROWS = [['CHANGED IP', 'OBJ-48213', '10.24.8.17'], ['CHANGED STATE', 'OBJ-48377', 'Out of service'], ['CHANGED SW_VERSION', 'OBJ-49002', '9.1.7'], ['CHANGED LOCATION', 'OBJ-49518', 'DC-2 · R11']];
function MiniRow({ r, p = 0, lock, bg, right }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 18, height: 58, padding: '0 14px', borderRadius: 10, background: bg || (p > 0.5 ? mix('#ffffff', tint(150), p) : '#fff'), borderBottom: `1px solid ${CB.line}` }}>
      <Box p={p} lock={lock} />
      <div style={{ width: 230, font: `600 17px ${MONO}`, color: CORAL_D, whiteSpace: 'nowrap' }}>{r[0]}</div>
      <div style={{ width: 130, font: `500 17px ${MONO}`, color: hc(255), textDecoration: 'underline' }}>{r[1]}</div>
      <div style={{ flex: 1, minWidth: 0, font: `500 17px ${MONO}`, color: CB.text, whiteSpace: 'nowrap' }}>{r[2]}</div>
      {right}
    </div>
  );
}
const PDFS = ['CommandRecon_AssetValidation_2026-11-18.pdf'];
const PdfChip = ({ n, s = 1, style }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: `${10 * s}px ${16 * s}px`, borderRadius: 12, background: CORAL_T, ...style }}>
    <Icon n="doc" s={24 * s} c={CORAL_D} /><div style={{ font: `500 ${17 * s}px ${MONO}`, color: CB.text, whiteSpace: 'nowrap' }}>{n}</div>
  </div>
);
function VTick({ lt }) {
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Win title="Command Recon · Asset Validation" icon="sheet" h={420} right={<div style={{ font: `500 17px ${SANS}`, color: CB.dim }}>Page 1 of 3</div>}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '0 14px 12px', borderBottom: `2px solid ${CB.line}` }}>
          <Box p={0} s={24} /><div style={{ font: `600 15px ${MONO}`, color: lt > 2.4 ? deep(225) : CB.dim }}>All</div>
        </div>
        {RV_ROWS.map((r, i) => <MiniRow key={r[1]} r={r} p={tw(lt, 0.5 + i * 0.45, 0.8 + i * 0.45, M.pop)} />)}
      </Win>
      <Note style={{ left: 0, top: 440, width: 560, ...up(rv(lt, 2.4)) }} icon="warn" col="oklch(0.5 0.12 75)" bg={AMBER_T}>"All" selects only the current page.</Note>
      <div style={{ position: 'absolute', right: 0, top: 452, ...up(rv(lt, 2.8)) }}><Btn col={hc(150)} press={tw(lt, 3.3, 3.7)}>Save</Btn></div>
    </div>
  );
}
function VSave({ lt }) {
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Card style={{ left: 0, top: 0, width: 780, height: 110, padding: '0 28px', display: 'flex', alignItems: 'center', gap: 18 }}>
        <Check size={34} /><div style={{ flex: 1, font: `600 23px ${SANS}`, color: CB.text }}>4 assets validated</div>
        <Btn col={hc(150)} press={tw(lt, 0.3, 0.7)}>Save</Btn>
      </Card>
      <div style={{ position: 'absolute', left: 0, top: 150, display: 'flex', alignItems: 'center', gap: 12, ...up(rv(lt, 0.9)) }}><Icon n="down" s={26} c={CB.dim} /><Lbl>Downloaded automatically</Lbl></div>
      {PDFS.map((n, i) => (
        <Card key={n} style={{ left: 0, top: 200 + i * 110, width: 780, height: 92, padding: '0 24px', display: 'flex', alignItems: 'center', gap: 16, ...up(rv(lt, 1.1 + i * 0.6), 20) }}>
          <div style={{ width: 52, height: 52, borderRadius: 12, background: CORAL_T, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon n="doc" s={28} c={CORAL_D} /></div>
          <div style={{ minWidth: 0 }}>
            <div style={{ font: `500 19px ${MONO}`, color: CB.text, whiteSpace: 'nowrap' }}>{n}</div>
            <div style={{ font: `400 16px ${SANS}`, color: CB.dim, marginTop: 2 }}>{i ? 'Warehouse Asset Validation' : 'Asset Validation'} tab</div>
          </div>
        </Card>
      ))}
    </div>
  );
}
function JiraCard({ title, kind = 'Task', status, children, h, style }) {
  return (
    <Card style={{ left: 0, top: 0, width: 780, height: h, padding: '24px 28px', ...style }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ width: 30, height: 30, borderRadius: 8, background: hc(285), display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon n="ticket" s={20} c="#fff" /></div>
        <Lbl>Jira · {kind}</Lbl><div style={{ flex: 1 }}></div>{status}
      </div>
      <div style={{ font: `600 26px ${SANS}`, color: CB.text, marginTop: 14 }}>{title}</div>
      {children}
    </Card>
  );
}
const STC = { 'To do': ['#E9E6DF', '#5E6475'], 'In progress': [tint(255), deep(255)], Done: ['oklch(0.95 0.045 150)', deep(150)] };
const Status = ({ s }) => <Pill bg={STC[s][0]} fg={STC[s][1]} s={0.95}>{s}</Pill>;
function VAttach({ lt }) {
  return (
    <JiraCard title="FNT Command Reconciliation · November 2026" status={<Status s="In progress" />} h={440}>
      <div style={{ marginTop: 26 }}><Lbl>Attachments</Lbl></div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 14 }}>
        {PDFS.map((n, i) => <PdfChip key={n} n={n} style={{ ...up(tw(lt, 0.6 + i * 0.6, 1.2 + i * 0.6, M.pop), -60) }} />)}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 26, ...up(rv(lt, 2.2)) }}><Check size={28} /><div style={{ font: `500 21px ${SANS}`, color: CB.text }}>Correct changes documented for this month</div></div>
    </JiraCard>
  );
}
function VWrong({ lt }) {
  const f = (i) => tw(lt, 1.0 + i * 0.6, 1.5 + i * 0.6, LIN);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Card style={{ left: 0, top: 0, width: 780, padding: '8px 10px', boxShadow: `0 0 0 3px ${CORAL}, ${SHADOW}` }}>
        <MiniRow r={['CHANGED IP', 'OBJ-48213', '10.24.8.17']} bg="#fff" right={<Pill bg={CORAL_T} fg={CORAL_D} s={0.9}>Wrong · not ticked</Pill>} />
      </Card>
      <Win title="Jira · Create ticket" icon="ticket" h={360} style={{ top: 110, ...up(rv(lt, 0.6), 20) }}>
        <Field l="Team" v="Network core team" p={f(0)} w={150} />
        <Field l="Summary" v="OBJ-48213: IP changed to a wrong value" p={f(1)} w={150} />
        <Field l="Assignee" v="Core team engineer" p={f(2)} w={150} />
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 18 }}><Btn col={hc(285)} press={tw(lt, 3.0, 3.4)}>Create</Btn></div>
      </Win>
    </div>
  );
}
function VFix({ lt }) {
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Win title="FNT Command · OBJ-48213" icon="db" h={230}>
        <Field l="IP address" old="10.24.8.17" v="10.24.8.71" p={tw(lt, 0.6, 1.6, LIN)} w={150} />
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 18 }}><Btn col={hc(255)} press={tw(lt, 1.8, 2.2)}>Save</Btn></div>
      </Win>
      <div style={{ position: 'absolute', left: 0, top: 260, ...up(rv(lt, 2.3)) }}><Lbl>Command Recon · revalidate</Lbl></div>
      <Card style={{ left: 0, top: 296, width: 780, padding: '8px 10px', ...up(rv(lt, 2.3)) }}>
        <MiniRow r={['CHANGED IP', 'OBJ-48213', '10.24.8.71']} p={tw(lt, 3.0, 3.3, M.pop)} right={<div style={{ opacity: rv(lt, 3.2) }}><Pill bg="oklch(0.95 0.045 150)" fg={deep(150)} s={0.9}>Validated</Pill></div>} />
      </Card>
    </div>
  );
}
function VNone({ lt }) {
  const msg = 'No changes this month.';
  const n = Math.round(msg.length * tw(lt, 1.0, 2.2, LIN));
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Card style={{ left: 0, top: 0, width: 780, height: 110, padding: '0 28px', display: 'flex', alignItems: 'center', gap: 18 }}>
        <Icon n="sheet" s={30} c={CB.dim} /><div style={{ flex: 1, font: `600 23px ${SANS}`, color: CB.text }}>Asset Validation · 0 changes</div>
        <Pill bg="#E9E6DF" fg={CB.dim}><span style={{ textDecoration: 'line-through' }}>PDF</span></Pill>
      </Card>
      <JiraCard title="FNT Command Reconciliation · November 2026" status={<Status s="In progress" />} h={300} style={{ top: 140, ...up(rv(lt, 0.4), 20) }}>
        <div style={{ display: 'flex', gap: 14, alignItems: 'center', marginTop: 24, height: 62, borderRadius: 12, border: `2px solid ${CB.line2}`, padding: '0 18px' }}>
          <Icon n="chat" s={26} c={CB.dim} />
          <div style={{ font: `500 21px ${SANS}`, color: CB.text }}>{msg.slice(0, n)}<span style={{ opacity: n < msg.length ? 1 : 0 }}>|</span></div>
        </div>
      </JiraCard>
    </div>
  );
}
function Review({ T, K }) {
  const t = T - K.Rv, o = span(T, K.Rv, K.Er);
  if (o == null) return null;
  const sd = (K.Er - K.Rv - 1.4) / RV.length, s0 = 1.0;
  let idx = -1;
  RV.forEach((_, i) => { if (t >= s0 + i * sd) idx = i; });
  const lt = t - (s0 + idx * sd);
  const V = [VTick, VSave, VAttach, VWrong, VFix, VNone][Math.max(0, idx)];
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <Header ph={2} title="The PO reviews the changes" o={tw(t, 0, 0.7, M.enter)} />
      <div style={{ position: 'absolute', left: 140, top: 270, width: 540, display: 'flex', flexDirection: 'column', gap: 6 }}>
        {RV.map((s, i) => {
          const ap = tw(t, 0.3 + i * 0.1, 0.7 + i * 0.1, M.enter);
          const act = i === idx, done = i < idx;
          const grp = i < 3 ? OKG : i < 5 ? CORAL : GREY;
          return (
            <div key={i} style={{ display: 'flex', gap: 18, padding: '13px 20px', borderRadius: 18, background: act ? '#fff' : 'transparent', boxShadow: act ? SHADOW : 'none', opacity: ap * (act || done ? 1 : 0.55), transform: `translateX(${(1 - ap) * -16}px)` }}>
              {done ? <Check size={38} /> : <div style={{ width: 38, height: 38, borderRadius: 19, flex: 'none', boxSizing: 'border-box', background: act ? grp : 'transparent', border: act ? 'none' : `2.5px solid ${CB.line2}`, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `600 18px ${MONO}`, color: act ? '#fff' : CB.dim }}>{i + 1}</div>}
              <div style={{ flex: 1, minWidth: 0, paddingTop: 3 }}>
                <div style={{ font: `600 25px ${SANS}`, color: CB.text, lineHeight: 1.2 }}>{s.t}</div>
                {act && <div style={{ font: `400 20px ${SANS}`, color: CB.dim, lineHeight: 1.4, marginTop: 6, textWrap: 'pretty', opacity: rv(lt, 0, 0.45) }}>{s.s}</div>}
              </div>
            </div>
          );
        })}
      </div>
      <div style={{ position: 'absolute', left: 706, top: 480, ...up(tw(t, 0.4, 1.0, M.enter), 20) }}>
        <div key={idx} style={{ opacity: idx >= 0 ? rv(lt, 0, 0.35) : 1 }}><Actor T={T} p={RV[Math.max(0, idx)].p} w={RV[Math.max(0, idx)].w || 'po'} /></div>
      </div>
      {idx >= 0 && <div key={idx} style={{ position: 'absolute', left: 1000, top: 290, width: 780, height: 600, ...up(rv(lt, 0, 0.45), 20) }}><V lt={lt} /></div>}
    </div>
  );
}

// ---------- 04 errors ----------
const ERR = [
  { tab: 'Asset Validation', codes: [['STATE NOT ASSIGNED', 'State empty or "not assigned"', 'Set state'], ['NO IP_ADDRESS SET', 'Operational without IP', 'Enter IP'], ['serial_no not set', 'Operational without serial, virtual excluded', 'Enter serial'], ['TEST ERROR', "Operational with SW_VERSION 'test123'", 'Enter real version']], rows: [['OBJ-49870', 'NO IP_ADDRESS SET'], ['OBJ-50021', 'serial_no not set'], ['OBJ-50233', 'STATE NOT ASSIGNED']], ok: [['CHANGED IP', 'OBJ-48213'], ['CHANGED STATE', 'OBJ-48377']] },
  { tab: 'Warehouse Asset Validation', codes: [['wrong state information', 'State is not Lager', 'Set Lager'], ['IP still populated please delete', 'IP still assigned', 'Delete IP'], ['wrong monitoring information', 'Monitoring is not none', 'Set none'], ['serial NO not set', 'Serial number missing', 'Enter serial']], rows: [['OBJ-51302', 'IP still populated please delete'], ['OBJ-51417', 'wrong state information'], ['OBJ-51560', 'serial NO not set']], ok: [['NEW ASSET', 'OBJ-51210'], ['CHANGED STATE', 'OBJ-47731']] },
];
const DISABLED = ['No active monitoring', 'IP not in private range', 'SW version not set'];
function Errors({ T, K }) {
  const t = T - K.Er, o = span(T, K.Er, K.Ji);
  if (o == null) return null;
  const g = 0, E = ERR[0], gt = t;
  const fx = t - 13.5;
  const gone = tw(fx, 1.6, 2.3);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <Header ph={3} title="Assets with errors" o={tw(t, 0, 0.7, M.enter)} />
      <Card style={{ left: 140, top: 260, width: 820, height: 640, overflow: 'hidden', ...up(rv(t, 0.3), 20) }}>
        <div style={{ height: 62, display: 'flex', alignItems: 'center', gap: 14, padding: '0 24px', borderBottom: `1px solid ${CB.line}` }}>
          <Icon n="sheet" s={24} c={CB.dim} /><div key={g} style={{ font: `600 20px ${MONO}`, color: CB.text, opacity: rv(gt, 0, 0.3) }}>Command Recon · {E.tab}</div>
        </div>
        <div key={g} style={{ padding: '14px 22px', opacity: rv(gt, 0, 0.3) }}>
          <Lbl>Changes</Lbl>
          <div style={{ marginTop: 8 }}>{E.ok.map((r) => <MiniRow key={r[1]} r={[r[0], r[1], '']} />)}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 22, ...up(rv(gt, 0.8)) }}>
            <Icon n="warn" s={24} c={CORAL} /><Lbl c={CORAL_D}>Assets with errors</Lbl><div style={{ font: `500 17px ${SANS}`, color: CB.dim }}>cannot be validated</div>
          </div>
          <div style={{ marginTop: 8 }}>
            {E.rows.map((r, i) => {
              const fixRow = i === 0 && fx > 0;
              const h = fixRow ? 58 * (1 - gone) : 58;
              return (
                <div key={r[0]} style={{ height: h, overflow: 'hidden', opacity: fixRow ? 1 - gone : 1, ...(fixRow ? {} : up(rv(gt, 1.1 + i * 0.3), 6)) }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 16, height: 58, padding: '0 14px', borderRadius: 10, background: fixRow ? mix(CORAL_T, 'oklch(0.95 0.045 150)', rv(fx, 0.6)) : CORAL_T, marginBottom: 0, borderBottom: '2px solid #fff' }}>
                    <Box lock />
                    <div style={{ width: 120, font: `500 17px ${MONO}`, color: hc(255), textDecoration: 'underline' }}>{r[0]}</div>
                    <div style={{ flex: 1, minWidth: 0, font: `600 17px ${MONO}`, color: CORAL_D, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r[1]}</div>
                    {fixRow && <div style={{ display: 'flex', alignItems: 'center', gap: 8, opacity: rv(fx, 0.6) }}><Check size={24} /><div style={{ font: `600 17px ${SANS}`, color: deep(150), whiteSpace: 'nowrap' }}>Fixed in Command</div></div>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        {fx > 2.0 && (
          <div style={{ position: 'absolute', left: 22, right: 22, bottom: 22, padding: '14px 16px', borderRadius: 14, background: '#F4F2EE', ...up(rv(fx, 2.2)) }}>
            <Lbl>December · ready for validation</Lbl>
            <div style={{ marginTop: 8 }}><MiniRow r={['CHANGED IP', 'OBJ-49870', '10.24.18.5']} /></div>
          </div>
        )}
      </Card>
      <Card key={g} style={{ left: 1000, top: 260, width: 780, padding: '22px 28px', ...up(rv(t - (g ? 12 : 5.6), 0, 0.5), 20) }}>
        <Lbl>{g ? 'Warehouse assets' : 'Placed assets'}</Lbl>
        {E.codes.map(([c, why, fix], i) => (
          <div key={c} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '14px 0', borderBottom: i < 3 ? `1px solid ${CB.line}` : 'none', ...up(rv(t - (g ? 12 : 5.6), 0.4 + i * 0.55), 8) }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ font: `600 19px ${MONO}`, color: CORAL_D }}>{c}</div>
              <div style={{ font: `400 18px ${SANS}`, color: CB.dim, marginTop: 3 }}>{why}</div>
            </div>
            <Arr w={34} />
            <Pill bg={tint(150)} fg={deep(150)} s={0.95}>{fix}</Pill>
          </div>
        ))}
      </Card>
      <Card style={{ left: 1000, top: 700, width: 780, padding: '18px 28px', ...up(rv(t, 11.4)) }}>
        <Lbl>Further error checks</Lbl>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginTop: 12 }}>
          {DISABLED.map((d) => <Pill key={d} bg={CORAL_T} fg={CORAL_D} s={0.95}><Icon n="warn" s={18} c={CORAL} />{d}</Pill>)}
        </div>
      </Card>
    </div>
  );
}

// ---------- 05 jira ----------
const MN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const FIN = ['All assets reviewed', 'Every wrong asset has a Jira ticket', 'PDFs attached'];
function Jira({ T, K }) {
  const t = T - K.Ji, o = span(T, K.Ji, K.Es);
  if (o == null) return null;
  const st = t >= 13.4 ? 'Done' : 'In progress';
  const NX = 140 + 10 * 76;
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <Header ph={4} title="Tracking in Jira" o={tw(t, 0, 0.7, M.enter)} />
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0 }}>
        <path d={`M200 386 L200 420`} stroke={CB.line2} strokeWidth="3" opacity={rv(t, 1.2)} />
        <path d={`M${NX + 34} 500 L${NX + 34} 540 L${NX + 34 - 300} 540 L${NX + 34 - 300} 566 M${NX + 34} 540 L${NX + 34} 566`} fill="none" stroke={hc(285)} strokeWidth="3" strokeLinejoin="round" opacity={rv(t, 3.4)} />
      </svg>
      <Card style={{ left: 140, top: 270, width: 420, height: 116, padding: '0 24px', display: 'flex', alignItems: 'center', gap: 16, ...up(rv(t, 0.6)) }}>
        <div style={{ width: 48, height: 48, borderRadius: 12, background: hc(285), display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon n="ticket" s={28} c="#fff" /></div>
        <div><Lbl>Epic · one per year</Lbl><div style={{ font: `600 25px ${SANS}`, color: CB.text, marginTop: 4 }}>Command Recon 2026</div></div>
      </Card>
      <div style={{ position: 'absolute', left: 140, top: 404, ...up(rv(t, 1.4)) }}><Lbl>Stories · one per month</Lbl></div>
      <div style={{ position: 'absolute', left: 140, top: 434, display: 'flex', gap: 8 }}>
        {MN.map((m, i) => {
          const now = i === 10, past = i < 10;
          return <div key={m} style={{ width: 68, height: 64, borderRadius: 12, boxSizing: 'border-box', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4, background: now ? hc(285) : '#fff', boxShadow: now ? 'none' : '0 2px 8px rgba(24,33,58,0.08)', opacity: past || now ? 1 : 0.5, ...popS(tw(t, 1.6 + i * 0.08, 2.0 + i * 0.08, M.pop)) }}>
            <div style={{ font: `600 17px ${MONO}`, color: now ? '#fff' : CB.text }}>{m}</div>
            {past ? <Dot col={OKG} size={8} /> : now ? <Dot col="#fff" size={8} /> : <Dot col={CB.line2} size={8} />}
          </div>;
        })}
      </div>
      {[['Review started', 'Task'], ['Review completed', 'Task']].map(([l, k], i) => (
        <Card key={l} style={{ left: NX + 34 - 300 - 140 + i * 300, top: 566, width: 280, padding: '18px 22px', ...up(rv(t, 3.6 + i * 0.4)) }}>
          <Lbl>{k}</Lbl>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 6 }}>
            <div style={{ font: `600 22px ${SANS}`, color: CB.text, flex: 1 }}>{l}</div>
            {(i === 0 || st === 'Done') && <Check size={26} />}
          </div>
        </Card>
      ))}
      <Card style={{ left: 1180, top: 270, width: 600, padding: '26px 30px', ...up(rv(t, 7.0), 20) }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Lbl>Story · November 2026</Lbl><div style={{ flex: 1 }}></div>
          <div key={st} style={{ ...popS(tw(t - (st === 'Done' ? 13.4 : 7.0), 0, 0.5, M.pop)) }}><Status s={st} /></div>
        </div>
        <div style={{ font: `600 26px ${SANS}`, color: CB.text, marginTop: 14 }}>Finished when</div>
        {FIN.map((l, i) => (
          <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 16, ...up(rv(t, 7.8 + i * 1.1), 8) }}><Check size={30} /><div style={{ font: `500 22px ${SANS}`, color: CB.text }}>{l}</div></div>
        ))}
        <div style={{ height: 1, background: CB.line, margin: '22px 0 18px' }}></div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, ...up(rv(t, 12.6), 8) }}>
          <div style={{ width: 30, height: 30, borderRadius: 15, background: hc(285), display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon n="people" s={18} c="#fff" /></div>
          <div style={{ font: `600 22px ${SANS}`, color: CB.text }}>PO confirms the monthly review is complete</div>
        </div>
      </Card>
    </div>
  );
}

// ---------- 06 escalation ----------
const ESC = [[5, 'mail', 'Reminder', 'To the PO'], [15, 'people', 'Chapter Lead', 'Reminder sent'], [30, 'people', 'Cluster Lead', 'Reminder sent']];
function Escalation({ T, K }) {
  const t = T - K.Es, o = span(T, K.Es, K.Su);
  if (o == null) return null;
  const XS = 200, XM = 560, DX = 37.33, Y = 640, ND = 30;
  const xd = (d) => XM + d * DX;
  const mp = tw(t, 1.0, 4.2, LIN);
  const T0 = 4.8, TD = 7.4;
  const day = ND * tw(t, T0, T0 + TD, LIN);
  const lab = (x, txt, a) => <div style={{ position: 'absolute', left: x - 80, top: Y + 40, width: 160, textAlign: 'center', font: `500 17px ${MONO}`, color: CB.dim, opacity: rv(t, a) }}>{txt}</div>;
  const dot = (x, on, col) => <div style={{ position: 'absolute', left: x - 22, top: Y - 22, width: 44, height: 44, borderRadius: 22, background: on ? col : '#fff', border: `4px solid ${on ? '#fff' : CB.line2}`, boxSizing: 'border-box', boxShadow: '0 2px 8px rgba(24,33,58,0.12)' }}></div>;
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <Header ph={5} title="Escalation" o={tw(t, 0, 0.7, M.enter)} />
      <div style={{ position: 'absolute', left: 140, top: 236, font: `500 26px ${SANS}`, color: CB.dim, ...up(rv(t, 0.4)) }}>The PO has the whole month to validate. Reminders start after month end.</div>
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0, opacity: rv(t, 0.6) }}>
        <line x1={XS} y1={Y} x2={xd(ND)} y2={Y} stroke={CB.line2} strokeWidth="6" strokeLinecap="round" />
        <line x1={XS} y1={Y} x2={lerp(XS, XM, mp)} y2={Y} stroke={hc(150)} strokeWidth="12" strokeLinecap="round" />
        {day > 0 && <line x1={XM} y1={Y} x2={xd(day)} y2={Y} stroke={hc(75)} strokeWidth="6" strokeLinecap="round" />}
        {Array.from({ length: ND + 1 }).map((_, i) => <line key={i} x1={xd(i)} y1={Y + 14} x2={xd(i)} y2={Y + (i % 5 ? 20 : 30)} stroke={CB.line2} strokeWidth="3" strokeLinecap="round" />)}
      </svg>
      {lab(XS, 'report created', 0.8)}{lab(XM, 'month end', 0.8)}
      {ESC.map(([d]) => <React.Fragment key={d}>{lab(xd(d), `+${d} days`, 0.8)}</React.Fragment>)}
      {dot(XS, t > 1.0, hc(150))}{dot(XM, mp >= 1, hc(150))}
      <Card style={{ left: (XS + XM) / 2 - 160, top: 380, width: 320, padding: '20px 22px', ...popS(tw(t, 0.8, 1.4, M.pop)) }}>
        <div style={{ width: 54, height: 54, borderRadius: 14, background: tint(150), display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon n="cal" s={30} c={deep(150)} /></div>
        <div style={{ font: `600 16px ${MONO}`, color: deep(150), marginTop: 14 }}>Whole month</div>
        <div style={{ font: `600 24px ${SANS}`, color: CB.text, marginTop: 4 }}>Validation period</div>
        <div style={{ font: `400 19px ${SANS}`, color: CB.dim, marginTop: 4 }}>The PO reviews and validates</div>
      </Card>
      {ESC.map(([d, ic, l, sub], i) => {
        const at = T0 + (d / ND) * TD;
        const pp = tw(t, at, at + 0.6, M.pop);
        const x = xd(d), am = i === 0;
        return (
          <React.Fragment key={d}>
            {dot(x, pp > 0, am ? hc(75) : CORAL)}
            <Card style={{ left: x - 110, top: 380, width: 220, padding: '20px 20px', ...popS(pp) }}>
              <div style={{ width: 54, height: 54, borderRadius: 14, background: am ? tint(75) : CORAL_T, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon n={ic} s={30} c={am ? deep(75) : CORAL_D} /></div>
              <div style={{ font: `600 16px ${MONO}`, color: am ? deep(75) : CORAL_D, marginTop: 14 }}>+{d} days</div>
              <div style={{ font: `600 24px ${SANS}`, color: CB.text, marginTop: 4 }}>{l}</div>
              <div style={{ font: `400 19px ${SANS}`, color: CB.dim, marginTop: 4 }}>{sub}</div>
            </Card>
          </React.Fragment>
        );
      })}
      {t > T0 && t < T0 + TD + 0.4 && <div style={{ position: 'absolute', left: xd(day) - 45, top: Y + 80, width: 90, textAlign: 'center', padding: '6px 0', borderRadius: 10, background: CB.text, font: `600 18px ${MONO}`, color: '#fff' }}>+{Math.floor(day)}</div>}
    </div>
  );
}

// ---------- summary ----------
function Summary({ T, K, end }) {
  const t = T - K.Su;
  if (t < -0.1) return null;
  const o = tw(t, 0, 0.6, M.enter) * (1 - tw(T, end - 0.7, end - 0.05));
  const node = (ic, h, title, sub, x, y, w, a, bg) => (
    <Card style={{ left: x, top: y, width: w, padding: '22px 24px', background: bg || '#fff', ...up(rv(t, a), 16) }}>
      <div style={{ width: 52, height: 52, borderRadius: 14, background: tint(h), display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon n={ic} s={28} c={hc(h)} /></div>
      <div style={{ font: `600 24px ${SANS}`, color: CB.text, marginTop: 14, lineHeight: 1.2 }}>{title}</div>
      {sub && <div style={{ font: `400 19px ${SANS}`, color: CB.dim, marginTop: 6, lineHeight: 1.35, textWrap: 'pretty' }}>{sub}</div>}
    </Card>
  );
  const ar = (x, y, a, col) => <div style={{ position: 'absolute', left: x, top: y, opacity: rv(t, a) }}><Arr w={44} col={col} /></div>;
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{ position: 'absolute', left: 120, top: 120, ...up(tw(t, 0, 0.7, M.enter), -12) }}>
        <Lbl>Short version</Lbl>
        <div style={{ font: `600 56px ${SANS}`, color: CB.text, letterSpacing: -1.5, marginTop: 8 }}>Command Recon, every month</div>
      </div>
      {node('delta', 255, 'Report created', null, 120, 420, 230, 0.6)}
      {ar(362, 490, 1.0)}
      {node('sheet', 225, 'PO opens the tool', null, 418, 420, 230, 1.2)}
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0, opacity: rv(t, 2.0) }}>
        <path d="M660 500 C 700 500, 690 370, 730 370 M660 500 C 700 500, 690 650, 730 650" fill="none" stroke={CB.line2} strokeWidth="3" strokeLinecap="round" />
      </svg>
      {node('shield', 150, 'Correct', 'Validate, save, PDF into the monthly Reconciliation task', 740, 270, 440, 2.2)}
      {node('ticket', 35, 'Wrong', 'Jira ticket, fix in Command, revalidate', 740, 560, 440, 3.6)}
      {ar(1194, 490, 6.0)}
      {node('people', 285, 'PO confirms in Jira', null, 1250, 420, 240, 6.2)}
      {ar(1502, 490, 7.6, CORAL)}
      {node('warn', 75, 'No response', 'After month end: reminders at 5 / 15 / 30 days', 1558, 420, 242, 7.8)}
    </div>
  );
}

// ---------- piece ----------
const SCN = JSON.parse(window.OM_SCENES || '[]');
const KV = (() => { const n = ['It', 'To', 'Rv', 'Er', 'Ji', 'Es', 'Su'], o = {}; let a = 0; n.forEach((k, i) => { o[k] = a; a += (SCN[i] && SCN[i].dur) || 15; }); o.end = a; return o; })();
function Piece({ tweaks }) {
  const { T } = useComposition();
  const K = KV, end = KV.end;
  const rsd = (K.Er - K.Rv - 1.4) / RV.length;
  const raw = [
    [K.It + 0.6, 'Command Recon checks your assets in FNT Command every month.'],
    [K.It + 5.2, 'It creates a delta report with only what has changed since the previous validation.'],
    [K.It + 10.4, 'You validate your assets once. From then on, you only review the changes.'],
    [K.It + 13.3, 'Validated assets without any change for 365 days come back and must be validated again.'],
    [K.It + 17.9, 'The PO opens the report in the Command Recon tool.'],
    [K.To + 0.6, 'The Asset Validation tab lists your placed assets: campus, building, floor and room.'],
    [K.To + 6.3, 'Only assets where you are PO or TPM are listed. The ACTION_CODE shows what changed, next to the key fields.'],
    [K.To + 11, 'OBJECT_ID opens the object in FNT Command. CORIA_ID opens the software product in the architecture portal.'],
    [K.To + 15.4, 'Search and Excel, CSV or Copy export are available.'],
    ...['If a change is correct, tick the asset. "All" selects only the current page.', 'Click Save, and the PDF downloads automatically.', 'Attach the PDF to the FNT Command Reconciliation task for the month.', 'If a change is wrong, do not tick it. Create a Jira ticket for the responsible team, describe the problem and assign it.', 'The data is fixed in Command, and the asset is revalidated.', 'No changes this month? No PDF, just a comment in Jira.'].map((s, i) => [K.Rv + 1.0 + i * rsd + 0.3, s]),
    [K.Er + 0.6, 'Assets that fail a data quality check are listed below the list. They cannot be validated until they are fixed in Command.'],
    [K.Er + 6.0, 'For placed assets: no state, no IP address, no serial number, or a test software version.'],
    [K.Er + 11.4, 'Further checks flag assets with no active monitoring, an IP outside the private range, or no SW version.'],
    [K.Er + 13.6, 'Once fixed, the asset disappears from the error list and shows up for validation the following month.'],
    [K.Ji + 0.6, 'Jira tracks the review: one Epic per year, one Story per month, and tasks for the start and completion.'],
    [K.Ji + 7.2, 'The month is finished when all assets are reviewed, every wrong asset has a Jira ticket, and the PDFs are attached.'],
    [K.Ji + 12.6, 'Then the PO confirms in Jira that the monthly review is complete.'],
    [K.Es + 0.6, 'The PO has the whole month to validate. If the review is not confirmed by month end, reminders follow.'],
    [K.Es + 4.8, '5 days after month end, a reminder goes to the PO. After 15 days, to the Chapter Lead. After 30 days, to the Cluster Lead.'],
    [K.Su + 0.6, 'In short: the report is created, and the PO opens the tool.'],
    [K.Su + 3.4, 'Correct changes are validated and the PDF goes into the monthly task. Wrong ones get a Jira ticket, a fix in Command and revalidation.'],
    [K.Su + 9.6, 'The PO confirms in Jira. Without a response, reminders follow 5, 15 and 30 days after month end.'],
  ];
  const caps = raw.map(([at, text], i) => ({ at, text, until: i < raw.length - 1 ? raw[i + 1][0] - 0.15 : end - 0.6 }));
  const hueAt = [[K.It, 255], [K.To, 225], [K.Rv, 150], [K.Er, 35], [K.Ji, 285], [K.Es, 75], [K.Su, 255]];
  let gh = 255;
  hueAt.forEach(([a, h]) => { if (T >= a) gh = h; });
  const fade = 1 - tw(T, end - 0.7, end - 0.05);
  return (
    <div data-screen-label={`t=${Math.floor(T)}s`} style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: CB.bg }}>
      <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(ellipse 65% 60% at 50% 50%, oklch(0.94 0.04 ${gh}), transparent 75%)` }}></div>
      <div style={{ position: 'absolute', inset: -40, backgroundImage: 'radial-gradient(circle, #DDD8CD 1.4px, transparent 1.8px)', backgroundSize: '40px 40px', transform: `translate(${(T * 3) % 40}px, ${(T * 1.5) % 40}px)` }}></div>
      <div style={{ position: 'absolute', inset: 0, opacity: fade }}>
        <Intro T={T} K={K} />
        <Tool T={T} K={K} />
        <Review T={T} K={K} />
        <Errors T={T} K={K} />
        <Jira T={T} K={K} />
        <Escalation T={T} K={K} />
        <Summary T={T} K={K} end={end} />
        <Tracker T={T} K={K} />
      </div>
      {tweaks.captions !== false && (
        <Captions items={caps} style={{ left: '50%', right: 'auto', bottom: 36, transform: 'translateX(-50%)', width: 'max-content', maxWidth: 1560, padding: '14px 30px', borderRadius: 14, background: 'rgba(24,33,58,0.94)', font: `500 32px ${SANS}`, color: '#F4F2EE', textShadow: 'none', lineHeight: 1.3, textAlign: 'center' }} />
      )}
    </div>
  );
}
function ReconVideo() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <>
      <CompositionStage width={1920} height={1080} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#F4F2EE">
        <Piece tweaks={t} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Playback" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        <TweakToggle label="Captions" value={t.captions} onChange={(v) => setTweak('captions', v)} />
      </TweaksPanel>
    </>
  );
}
window.ReconVideo = ReconVideo;

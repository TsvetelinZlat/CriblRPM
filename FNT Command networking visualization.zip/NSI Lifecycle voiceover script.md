# NSI Hardware Lifecycle — voiceover & chapters (v1)

Runtime ≈ 3:46 · 16:9 · English subtitles burned in (toggle in Tweaks). Chapters = scene names in the timeline.

| Chapter | Start | Who is shown |
|---|---|---|
| Intro | 0:00 | NSI engineer walks the six stages |
| 01 Procurement | 0:14 | NSI engineer |
| 02 Delivery and Storage | 0:40.5 | NSI engineer |
| 02 Commercial Inventory and Shipping | 1:06.5 | NSI PO, then NSI engineer |
| 03 Inventory in FNT Command | 1:24.5 | NSI engineer |
| 04 Setup, Operation and Maintenance | 1:48.5 | NSI engineer |
| 05 Decommissioning and Disposal | 2:20.5 | Requester (NSI) |
| 06 Sale of Hardware | 2:46.5 | NSI engineer |
| Summary | 3:08.5 | — |
| Remember | 3:24.5 | — |

Narration lines are the on-screen captions (see `nsi-lifecycle-video.jsx`, `caps` array).

## Filled in or invented (please confirm)
- Text cut off in the photos, completed by me: intro narration ending, "the vendor must confirm this", storage overflow → "contact SL-Datacenter", warehouses "visible in FNT Command", last summary row "Moved to the destruction warehouse or sold → Disposal".
- Company data made generic: Commerzbank → company, DLZ-1 → data centre / DC-1, Frankfurt mail service → company mail service, bank policy → company policy, vendor/models/serials → placeholders (Vendor X, SW-48P, SN-…), shipping checklist → Shipping_Checklist.pdf. Kept: FNT Command, StableNet, ServiceNow/DCBI, 01-54-58_Default, contact roles.
- Status colours: None grey, Lager blue, Planning amber, Operational green, Out of service orange, Decommissioned red, Disposal brown (from your reference).
- No email addresses, user names or ticket numbers shown.

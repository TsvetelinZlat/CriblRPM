const { Easing, useComposition, CompositionStage, Captions } = window;

const M = { enter: Easing.easeOutCubic, move: Easing.easeInOutCubic, pop: Easing.easeOutBack };
const tw = (T, a, b, e = M.move) => (T <= a ? 0 : T >= b ? 1 : e((T - a) / (b - a)));
const lerp = (a, b, p) => a + (b - a) * p;
function kf(T, fr, e = M.move) {
  if (T <= fr[0][0]) return fr[0].slice(1);
  for (let i = 0; i < fr.length - 1; i++) {
    const a = fr[i], b = fr[i + 1];
    if (T < b[0]) { const p = e((T - a[0]) / (b[0] - a[0])); return a.slice(1).map((v, k) => lerp(v, b[k + 1], p)); }
  }
  return fr[fr.length - 1].slice(1);
}
const clampN = (v) => Math.max(0, Math.min(1, v));
const mix = (a, b, p) => `color-mix(in oklch, ${b} ${Math.round(clampN(p) * 100)}%, ${a})`;
const nh = (h) => ((h % 360) + 360) % 360;

const SANS = "'IBM Plex Sans', system-ui, sans-serif";
const MONO = "'IBM Plex Mono', ui-monospace, monospace";
// Location levels share one cool analogous ramp (violet → green). Coral marks problems and the signal path.
const LV = { city: 290, bldg: 255, floor: 220, room: 185, rack: 150 };
const NAV_C = 'oklch(0.55 0.15 285)', OM_C = 'oklch(0.56 0.13 150)';
const CORAL = 'oklch(0.66 0.18 35)', CORAL_D = 'oklch(0.50 0.16 35)', CORAL_S = 'oklch(0.66 0.18 35 / 0.3)';
const LED = 'oklch(0.82 0.19 150)', AMBER = 'oklch(0.84 0.15 85)', OKG = 'oklch(0.62 0.15 150)';
const hc = (h, a) => `oklch(0.6 0.15 ${h}${a ? ' / ' + a : ''})`;
const tint = (h) => `oklch(0.95 0.025 ${h})`;
const tint2 = (h) => `oklch(0.86 0.065 ${h})`;
const deep = (h) => `oklch(0.40 0.12 ${h})`;
const shade = (h, l, c) => ({ top: `oklch(${(l + 0.07).toFixed(3)} ${c} ${h})`, sy: `oklch(${l} ${c} ${h})`, sx: `oklch(${(l - 0.09).toFixed(3)} ${c} ${h})` });
const CB = { bg: '#F4F2EE', line: '#E4E1DA', line2: '#CBC7BE', text: '#18213A', dim: '#566079', faint: '#9AA1B0', navy: '#1C2438', navy2: '#131A2A', navy3: '#2B3550', navyTop: '#3A4560' };
let C = CB;
const useHue = (h) => { C = { ...CB, h, acc: hc(h), tint: tint(h), tint2: tint2(h), deep: deep(h) }; };
const SHADOW = '0 24px 60px rgba(24,33,58,0.14), 0 4px 12px rgba(24,33,58,0.08)';
const blink = (T, seed) => (Math.sin(T * 5.3 + seed * 2.7) > -0.3 ? 1 : 0.25);

const ZD = 1.3;
const HIDDEN = { display: 'none' };
function zoomXf(T, inAt, inF, Z1, outAt, outF, Z2) {
  if (inAt != null) {
    if (T < inAt) return HIDDEN;
    if (T < inAt + ZD) {
      const p = tw(T, inAt, inAt + ZD);
      return { transform: `translate(${(inF[0] - 960) * (1 - p)}px, ${(inF[1] - 540) * (1 - p)}px) scale(${Math.pow(Z1, p - 1)})`, transformOrigin: '960px 540px', opacity: tw(T, inAt + 0.15 * ZD, inAt + 0.55 * ZD, M.enter) };
    }
  }
  if (outAt != null && T >= outAt) {
    if (T > outAt + ZD) return HIDDEN;
    const p = tw(T, outAt, outAt + ZD);
    return { transform: `translate(${(960 - outF[0]) * p}px, ${(540 - outF[1]) * p}px) scale(${Math.pow(Z2, p)})`, transformOrigin: `${outF[0]}px ${outF[1]}px`, opacity: 1 - tw(T, outAt + 0.4 * ZD, outAt + 0.8 * ZD) };
  }
  return { opacity: 1 };
}
const Layer = ({ xf, children }) => (xf.display === 'none' ? null : <div style={{ position: 'absolute', inset: 0, ...xf }}>{children}</div>);
const sel = (T, at) => tw(T, at, at + 0.45, M.enter);
const ring = (T, at) => (T > at ? ((T - at) % 1.1) / 1.1 : -1);

// ---------- isometric helpers (2:1) ----------
const IX = 0.7071, IY = 0.3536, IZ = 0.866;
const iso = (o, x, y, z = 0) => [o[0] + (x - y) * IX, o[1] + (x + y) * IY - z * IZ];
const pts = (a) => a.map((p) => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
const isoRect = (o, x, y, w, d, z = 0) => pts([iso(o, x, y, z), iso(o, x + w, y, z), iso(o, x + w, y + d, z), iso(o, x, y + d, z)]);
function IsoBox({ o, x, y, z = 0, w, d, h, top, sy, sx }) {
  const P = (a, b, c) => iso(o, a, b, c);
  const f = (fill, p) => <polygon points={pts(p)} fill={fill} stroke={fill} strokeWidth="0.8" strokeLinejoin="round" />;
  return (
    <g>
      {f(sy, [P(x, y + d, z), P(x + w, y + d, z), P(x + w, y + d, z + h), P(x, y + d, z + h)])}
      {f(sx, [P(x + w, y, z), P(x + w, y + d, z), P(x + w, y + d, z + h), P(x + w, y, z + h)])}
      {f(top, [P(x, y, z + h), P(x + w, y, z + h), P(x + w, y + d, z + h), P(x, y + d, z + h)])}
    </g>
  );
}

// ---------- icons ----------
function NavIcon({ size = 40, col = NAV_C, ring: rc }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size / 2, border: `${Math.round(size * 0.1)}px solid ${rc || col}`, boxSizing: 'border-box', position: 'relative', flex: 'none' }}>
      <div style={{ position: 'absolute', left: '50%', top: '50%', width: size * 0.24, height: size * 0.66, transform: 'translate(-50%, -50%) rotate(40deg)', clipPath: 'polygon(50% 0, 100% 50%, 50% 100%, 0 50%)', background: `linear-gradient(${rc || col} 50%, ${CORAL} 50%)` }}></div>
    </div>
  );
}
function OMIcon({ size = 40, col = OM_C }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size * 0.24, background: col, flex: 'none', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: size * 0.11, paddingLeft: size * 0.2, boxSizing: 'border-box' }}>
      {[0.5, 0.36, 0.44].map((w, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: size * 0.08 }}>
          <div style={{ width: size * 0.1, height: size * 0.1, borderRadius: size, background: '#fff' }}></div>
          <div style={{ height: size * 0.08, borderRadius: 2, background: '#fff', width: size * w }}></div>
        </div>
      ))}
    </div>
  );
}
function Check({ size = 30, col = OKG }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size / 2, background: col, position: 'relative', flex: 'none' }}>
      <div style={{ position: 'absolute', left: size * 0.37, top: size * 0.2, width: size * 0.22, height: size * 0.42, borderRight: `${size * 0.1}px solid #fff`, borderBottom: `${size * 0.1}px solid #fff`, transform: 'rotate(45deg)' }}></div>
    </div>
  );
}


// ================= NSI Hardware Lifecycle =================
const GREY = '#A3A9B6';
const Dot = ({ col, size = 14 }) => <div style={{ width: size, height: size, borderRadius: size / 2, background: col, flex: 'none' }}></div>;
const up = (p, d = 14) => ({ opacity: clampN(p), transform: `translateY(${(1 - p) * d}px)` });
const rv = (lt, a, d = 0.4) => tw(lt, a, a + d, M.enter);
const IC = {
  cart: <><path d="M3 4h2.5l2.2 11h10.6L21 8H6.4" /><circle cx="9.5" cy="19.5" r="1.5" /><circle cx="17" cy="19.5" r="1.5" /></>,
  truck: <><path d="M2 6h11v10H2z" /><path d="M13 9.5h4.2l3.3 3.5v3H13z" /><circle cx="6" cy="18" r="2" /><circle cx="17" cy="18" r="2" /></>,
  db: <><ellipse cx="12" cy="5.5" rx="7" ry="2.5" /><path d="M5 5.5v13c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5v-13" /><path d="M5 12c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5" /></>,
  gear: <><circle cx="12" cy="12" r="3" /><circle cx="12" cy="12" r="7" /><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1" /></>,
  trash: <path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6" />,
  tag: <><path d="M3 12V3h9l9 9-9 9z" /><circle cx="7.5" cy="7.5" r="1.5" /></>,
  mail: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 7l9 6 9-6" /></>,
  sheet: <><rect x="4" y="3" width="16" height="18" rx="2" /><path d="M4 9h16M4 15h16M10 3v18" /></>,
  search: <><circle cx="11" cy="11" r="6" /><path d="M16 16l5 5" /></>,
  people: <><circle cx="8" cy="8" r="3" /><circle cx="16.5" cy="8.5" r="2.5" /><path d="M2 20c.5-3.5 3-5.5 6-5.5s5.5 2 6 5.5M14.5 14.6c.6-.1 1.3-.2 2-.2 3 0 5 2 5.5 5.6" /></>,
  box: <><path d="M3 7l9-4 9 4v10l-9 4-9-4z" /><path d="M3 7l9 4 9-4M12 11v10" /></>,
  warn: <><path d="M12 3l10 18H2z" /><path d="M12 10v5M12 18v.5" /></>,
  doc: <><path d="M6 3h9l4 4v14H6z" /><path d="M15 3v4h4M9 12h7M9 16h7" /></>,
  shield: <><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z" /><path d="M8.5 12l2.5 2.5 4.5-5" /></>,
  tools: <path d="M14.5 6.5a4 4 0 0 0-5.2 5.2L3 18l3 3 6.3-6.3a4 4 0 0 0 5.2-5.2l-2.5 2.5-2.5-2.5z" />,
  hand: <path d="M2 12l4-5h4l2 2 2-2h4l4 5-6.5 7-1.5-1.5L12 19l-1.5-1.5L9 19l-1.5-1.5L6 19z" />,
  pulse: <path d="M3 12h4l2-5 4 10 2-5h6" />,
  pause: <><circle cx="12" cy="12" r="9" /><path d="M10 8.5v7M14 8.5v7" /></>,
  home: <><path d="M3 21V9l9-6 9 6v12" /><path d="M7 21v-8h10v8M7 17h10" /></>,
  cal: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M3 10h18M8 3v4M16 3v4" /></>,
  pen: <path d="M3 19c2-3 3-6 5-6s1 5 3 5 2-3 4-3 2 2 4 2M15 4l4 4-8 8H7v-4z" />,
  form: <><rect x="4" y="3" width="16" height="18" rx="2" /><path d="M8 8h8M8 12h8M8 16h5" /></>,
};
function Icon({ n, s = 32, c = CB.text, w = 2 }) {
  return <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" style={{ flex: 'none', display: 'block' }}>{IC[n]}</svg>;
}
const SKIN = '#E6B591', HAIR = '#3A2E2A', PANTS = '#2E3650';
const ROLE = { eng: ['NSI engineer', 225], po: ['NSI PO', 285], req: ['Requester (NSI)', 225], dcbi: ['DCBI · SL-Datacenter', 35] };
const Desk = () => <g><rect x="66" y="186" width="150" height="9" rx="3" fill="#C9CED9" /><rect x="74" y="195" width="8" height="98" fill="#C9CED9" /><rect x="200" y="195" width="8" height="98" fill="#C9CED9" /></g>;
function Person({ pose = 'idle', T, shirt, s = 1, walk = 0 }) {
  const ty = Math.sin(T * 14) * 3, jig = Math.sin(T * 9) * 4, sw = walk ? Math.sin(T * 7) * 20 : 0;
  const idleL = [[80, 120], [72, 160], [74, 198]], idleR = [[140, 120], [148, 160], [146, 198]];
  let L = idleL, R = idleR, back = null, front = null;
  if (pose === 'laptop') {
    L = [[80, 120], [82, 160], [112, 178 + ty]]; R = [[140, 120], [148, 158], [162, 178 - ty]];
    back = <g><Desk /><rect x="98" y="180" width="92" height="7" rx="3" fill="#8C93A6" /><path d="M184 184 L202 128 L210 131 L192 186Z" fill="#3B4359" /><path d="M189 178 L203 136" stroke="oklch(0.75 0.1 205)" strokeWidth="3" /></g>;
  } else if (pose === 'sign') {
    L = [[80, 120], [84, 160], [112, 182]]; R = [[140, 120], [152, 160], [150 + jig * 1.5, 180]];
    back = <g><Desk /><path d="M104 184 L176 184 L182 178 L110 178Z" fill="#fff" stroke="#A3A9B6" strokeWidth="2" /></g>;
    front = <line x1={150 + jig * 1.5} y1="180" x2={158 + jig * 1.5} y2="164" stroke="#2E3650" strokeWidth="4" strokeLinecap="round" />;
  } else if (pose === 'box') {
    L = [[80, 120], [84, 160], [96, 180]]; R = [[140, 120], [162, 150], [178, 168]];
    back = <g><rect x="92" y="126" width="88" height="66" rx="4" fill="#D9B27C" stroke="#B88F58" strokeWidth="2.5" /><rect x="128" y="126" width="16" height="66" fill="#C99E66" /></g>;
  } else if (pose === 'clip') {
    L = [[80, 120], [88, 162], [118, 172]]; R = [[140, 120], [158, 152], [148 + jig, 150]];
    back = <g><rect x="112" y="124" width="54" height="70" rx="5" fill="#fff" stroke="#8C93A6" strokeWidth="3" /><rect x="128" y="119" width="22" height="9" rx="3" fill="#8C93A6" /><path d="M121 142h34M121 154h34M121 166h24" stroke="#C9CED9" strokeWidth="3" /></g>;
    front = <line x1={148 + jig} y1="150" x2={154 + jig} y2="136" stroke="#2E3650" strokeWidth="4" strokeLinecap="round" />;
  } else if (pose === 'phone') {
    R = [[140, 120], [162, 108], [134, 80]];
    front = <rect x="126" y="62" width="13" height="26" rx="3" fill="#2E3650" />;
  } else if (pose === 'mail') {
    R = [[140, 118], [168, 112], [190, 100 + ty * 0.5]];
    front = <g transform={`translate(0 ${ty * 0.5})`}><rect x="186" y="80" width="42" height="28" rx="3" fill="#fff" stroke="#8C93A6" strokeWidth="2.5" /><path d="M187 82 L207 96 L227 82" fill="none" stroke="#8C93A6" strokeWidth="2.5" /></g>;
  } else if (pose === 'point') {
    R = [[140, 118], [172, 104], [200, 88]];
    front = <line x1="200" y1="88" x2="214" y2="80" stroke={SKIN} strokeWidth="6" strokeLinecap="round" />;
  } else if (pose === 'wrench') {
    L = [[80, 120], [74, 160], [78, 196]]; R = [[140, 120], [166, 142], [188, 124]];
    front = <g transform={`rotate(${jig * 4} 188 124)`}><line x1="188" y1="124" x2="210" y2="98" stroke="#8C93A6" strokeWidth="7" strokeLinecap="round" /><circle cx="212" cy="95" r="8" fill="none" stroke="#8C93A6" strokeWidth="5" /></g>;
  }
  const arm = (P) => <g><path d={`M${P[0][0]} ${P[0][1]} L${P[1][0]} ${P[1][1]} L${P[2][0]} ${P[2][1]}`} fill="none" stroke={shirt} strokeWidth="19" strokeLinecap="round" strokeLinejoin="round" /><circle cx={P[2][0]} cy={P[2][1]} r="9" fill={SKIN} /></g>;
  const leg = (x, a) => <g transform={`rotate(${a} ${x + 9} 200)`}><rect x={x} y="196" width="18" height="94" rx="9" fill={PANTS} /><ellipse cx={x + 14} cy="290" rx="15" ry="7" fill="#1C2438" /></g>;
  const bob = walk ? Math.abs(Math.sin(T * 7)) * -4 : Math.sin(T * 2.2) * 1.5;
  return (
    <svg width={220 * s} height={300 * s} viewBox="0 0 220 300" style={{ display: 'block', overflow: 'visible' }}>
      <ellipse cx="112" cy="294" rx="62" ry="8" fill="rgba(24,33,58,0.08)" />
      <g transform={`translate(0 ${bob})`}>
        {leg(86, sw)}{leg(114, -sw)}
        <path d="M72 122 Q72 104 90 102 L130 102 Q148 104 148 122 L152 206 Q110 214 68 206 Z" fill={shirt} />
        <rect x="102" y="90" width="16" height="16" fill={SKIN} />
        <circle cx="112" cy="64" r="31" fill={SKIN} />
        <path d="M80 70 Q76 32 112 32 Q142 32 143 58 Q126 46 106 52 Q92 58 90 78 Z" fill={HAIR} />
        <circle cx="118" cy="66" r="3" fill="#2E3650" /><circle cx="134" cy="66" r="3" fill="#2E3650" />
        <path d="M120 80 Q127 85 134 79" fill="none" stroke="#2E3650" strokeWidth="2.5" strokeLinecap="round" />
        {back}{arm(L)}{arm(R)}{front}
      </g>
    </svg>
  );
}
function Actor({ T, a, x, y, s = 1.2 }) {
  const [l, h] = ROLE[a.w || 'eng'];
  return (
    <div style={{ position: 'absolute', left: x, top: y, width: 220 * s, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
      <Person T={T} pose={a.p} shirt={hc(h)} s={s} walk={a.walk} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 16px 6px 12px', borderRadius: 20, background: '#fff', boxShadow: '0 2px 8px rgba(24,33,58,0.1)' }}>
        <Dot col={hc(h)} size={10} /><div style={{ font: `600 18px ${SANS}`, color: CB.text, whiteSpace: 'nowrap' }}>{l}</div>
      </div>
    </div>
  );
}
const ST = { none: 'None', lager: 'Lager / Warehouse', planning: 'Planning', operational: 'Operational', oos: 'Out of service', decom: 'Decommissioned', disposal: 'Disposal' };
const SH = { lager: 255, planning: 80, operational: 150, oos: 50, decom: 20, disposal: 45 };
function SC(k) {
  if (k === 'none') return { bg: '#E9E6DF', dot: GREY, fg: '#5E6475' };
  if (k === 'disposal') return { bg: 'oklch(0.92 0.025 45)', dot: 'oklch(0.32 0.06 40)', fg: 'oklch(0.3 0.05 40)' };
  if (k === 'lager') return { bg: 'oklch(0.93 0.02 245)', dot: 'oklch(0.35 0.14 265)', fg: 'oklch(0.33 0.12 265)' };
  const h = SH[k];
  return { bg: `oklch(0.95 0.045 ${h})`, dot: `oklch(0.45 0.14 ${h})`, fg: `oklch(0.4 0.11 ${h})` };
}
function Chip({ k, s = 1, label }) {
  const c = SC(k);
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 10 * s, padding: `${7 * s}px ${18 * s}px ${7 * s}px ${13 * s}px`, borderRadius: 40, background: c.bg, flex: 'none' }}>
      <Dot col={c.dot} size={12 * s} />
      <div style={{ font: `600 ${21 * s}px ${SANS}`, color: c.fg, whiteSpace: 'nowrap' }}>{label || ST[k]}</div>
    </div>
  );
}
const Arr = ({ w = 40, col = CB.line2 }) => (
  <svg width={w} height="20" style={{ flex: 'none' }}><line x1="2" y1="10" x2={w - 8} y2="10" stroke={col} strokeWidth="3" strokeLinecap="round" /><polyline points={`${w - 14},4 ${w - 6},10 ${w - 14},16`} fill="none" stroke={col} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" /></svg>
);
const STAGES = [
  { n: '01', t: 'Procurement', i: 'cart', h: 285 },
  { n: '02', t: 'Delivery & Storage', i: 'truck', h: 255 },
  { n: '03', t: 'Inventory', i: 'db', h: 225 },
  { n: '04', t: 'Setup & Operation', i: 'gear', h: 160 },
  { n: '05', t: 'Decommissioning', i: 'trash', h: 35 },
  { n: '06', t: 'Sale', i: 'tag', h: 75 },
];
const FLOW = ['none', 'lager', 'planning', 'operational', 'oos', 'decom'];
const Card = ({ style, children }) => <div style={{ position: 'absolute', background: '#fff', borderRadius: 20, boxShadow: SHADOW, boxSizing: 'border-box', ...style }}>{children}</div>;
function Win({ title, icon, h, children, style }) {
  return (
    <Card style={{ left: 0, top: 0, width: 780, height: h, overflow: 'hidden', ...style }}>
      <div style={{ height: 64, display: 'flex', alignItems: 'center', gap: 14, padding: '0 24px', borderBottom: `1px solid ${CB.line}` }}>
        <Icon n={icon} s={24} c={CB.dim} />
        <div style={{ font: `600 20px ${MONO}`, color: CB.text, whiteSpace: 'nowrap' }}>{title}</div>
      </div>
      <div style={{ position: 'relative', padding: '20px 26px' }}>{children}</div>
    </Card>
  );
}
const Lbl = ({ children, c = CB.dim }) => <div style={{ font: `600 15px ${MONO}`, color: c, letterSpacing: 1.5, textTransform: 'uppercase' }}>{children}</div>;
function Note({ icon = 'warn', col = CORAL_D, bg = 'oklch(0.95 0.03 35)', children, style }) {
  return (
    <div style={{ position: 'absolute', display: 'flex', alignItems: 'center', gap: 16, padding: '16px 22px', borderRadius: 16, background: bg, boxSizing: 'border-box', ...style }}>
      <Icon n={icon} s={30} c={col} />
      <div style={{ font: `500 21px ${SANS}`, color: CB.text, lineHeight: 1.35, textWrap: 'pretty' }}>{children}</div>
    </div>
  );
}
function Field({ l, v, p, w }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '10px 0', borderBottom: `1px solid ${CB.line}` }}>
      <div style={{ font: `500 19px ${SANS}`, color: CB.dim, width: w || 230, flex: 'none' }}>{l}</div>
      <div style={{ flex: 1, minWidth: 0, height: 40, borderRadius: 8, background: mix('#F4F2EE', '#ffffff', p), border: `1.5px solid ${p > 0.5 ? CB.line2 : CB.line}`, display: 'flex', alignItems: 'center', padding: '0 14px', boxSizing: 'border-box', overflow: 'hidden' }}>
        <div style={{ font: `500 19px ${MONO}`, color: CB.text, whiteSpace: 'nowrap', clipPath: `inset(0 ${(1 - p) * 100}% 0 0)` }}>{v}</div>
      </div>
      {p >= 1 && <Check size={26} />}
    </div>
  );
}

// ---------- step scene shell ----------
function Header({ st, title, o }) {
  const s = STAGES[st];
  return (
    <div style={{ position: 'absolute', left: 140, top: 150, display: 'flex', alignItems: 'baseline', gap: 26, ...up(o, -12) }}>
      <div style={{ font: `600 64px ${MONO}`, color: hc(s.h), letterSpacing: -2 }}>{s.n}</div>
      <div style={{ font: `600 48px ${SANS}`, color: CB.text, letterSpacing: -1, whiteSpace: 'nowrap' }}>{title}</div>
    </div>
  );
}
function StepScene({ T, at, end, st, title, steps, sd, visual, s0 = 1.0 }) {
  const t = T - at;
  if (t < -0.1 || T > end + 0.1) return null;
  const o = tw(t, 0, 0.6, M.enter) * (1 - tw(T, end - 0.6, end));
  const h = STAGES[st].h;
  let idx = -1;
  steps.forEach((_, i) => { if (t >= s0 + i * sd) idx = i; });
  const lt = t - (s0 + idx * sd);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <Header st={st} title={title} o={tw(t, 0, 0.7, M.enter)} />
      <div style={{ position: 'absolute', left: 140, top: 290, width: 540, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {steps.map((s, i) => {
          const ap = tw(t, 0.3 + i * 0.1, 0.7 + i * 0.1, M.enter);
          const act = i === idx, done = i < idx;
          const ex = act ? tw(lt, 0, 0.45, M.enter) : 0;
          return (
            <div key={i} style={{ display: 'flex', gap: 20, padding: '16px 22px', borderRadius: 18, background: act ? '#fff' : 'transparent', boxShadow: act ? SHADOW : 'none', opacity: ap * (act || done ? 1 : 0.55), transform: `translateX(${(1 - ap) * -16}px)` }}>
              {done ? <Check size={42} /> : (
                <div style={{ width: 42, height: 42, borderRadius: 21, flex: 'none', boxSizing: 'border-box', background: act ? hc(h) : 'transparent', border: act ? 'none' : `2.5px solid ${CB.line2}`, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `600 20px ${MONO}`, color: act ? '#fff' : CB.dim }}>{i + 1}</div>
              )}
              <div style={{ flex: 1, minWidth: 0, paddingTop: 4 }}>
                <div style={{ font: `600 27px ${SANS}`, color: CB.text, lineHeight: 1.2 }}>{s.t}</div>
                {act && s.s && <div style={{ font: `400 21px ${SANS}`, color: CB.dim, lineHeight: 1.4, marginTop: 8, textWrap: 'pretty', opacity: ex }}>{s.s}</div>}
              </div>
            </div>
          );
        })}
      </div>
      <div style={{ position: 'absolute', left: 706, top: 470, width: 242, height: 400, ...up(tw(t, 0.4, 1.0, M.enter), 20) }}>
        <div key={idx} style={{ position: 'relative', opacity: idx >= 0 ? tw(lt, 0, 0.35, M.enter) : 1 }}><Actor T={T} a={steps[Math.max(0, idx)]} x={0} y={0} s={1.1} /></div>
      </div>
      {idx >= 0 && (
        <div key={idx} style={{ position: 'absolute', left: 1000, top: 290, width: 780, height: 600, ...up(tw(lt, 0, 0.45, M.enter), 20) }}>
          {visual(idx, lt / SLOW)}
        </div>
      )}
    </div>
  );
}

// ---------- persistent overlays ----------
function Tracker({ T, K }) {
  const o = tw(T, K.Pr, K.Pr + 0.8, M.enter) * (1 - tw(T, K.Su - 0.6, K.Su));
  if (o <= 0) return null;
  const marks = [[K.Pr, 0], [K.Dl, 1], [K.In, 2], [K.Se, 3], [K.De, 4], [K.Sa, 5]];
  let cur = 0;
  marks.forEach(([a, i]) => { if (T >= a) cur = i; });
  return (
    <div style={{ position: 'absolute', left: 0, right: 0, top: 44, display: 'flex', justifyContent: 'center', gap: 10, opacity: o }}>
      {STAGES.map((s, i) => {
        const act = i === cur, done = i < cur;
        return (
          <div key={s.n} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 20px 9px 14px', borderRadius: 30, background: act ? hc(s.h) : '#fff', boxShadow: act ? 'none' : '0 2px 8px rgba(24,33,58,0.08)', opacity: act || done ? 1 : 0.6 }}>
            <Icon n={s.i} s={22} c={act ? '#fff' : done ? hc(s.h) : CB.dim} />
            <div style={{ font: `600 17px ${MONO}`, color: act ? '#fff' : CB.dim }}>{s.n}</div>
            <div style={{ font: `600 18px ${SANS}`, color: act ? '#fff' : CB.text, whiteSpace: 'nowrap' }}>{s.t}</div>
          </div>
        );
      })}
    </div>
  );
}
function StatusWidget({ T, K, keys }) {
  const o = tw(T, K.Pr + 0.4, K.Pr + 1.0, M.enter) * (1 - tw(T, K.Su - 0.6, K.Su));
  if (o <= 0) return null;
  let cur = keys[0], since = -9;
  keys.forEach(([a, k]) => { if (T >= a) { cur = [a, k]; since = a; } });
  const pop = tw(T, since, since + 0.5, M.pop);
  return (
    <div style={{ position: 'absolute', right: 140, top: 150, display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 10, opacity: o }}>
      <Lbl>FNT Command status</Lbl>
      <div style={{ transform: `scale(${lerp(0.7, 1, Math.min(1, pop))})`, transformOrigin: 'right center', opacity: clampN(pop * 2) }}><Chip k={cur[1]} s={1.35} label={cur[1] === 'none' ? 'None · not yet registered' : undefined} /></div>
    </div>
  );
}

// ---------- intro ----------
function Intro({ T, K }) {
  const t = (T - K.It) / SLOW;
  if (T > K.Pr + 0.1) return null;
  const out = tw(T, K.Pr - 0.7, K.Pr);
  const ti = tw(t, 0.2, 1.0, M.enter);
  const lineP = tw(t, 1.6, 6.0, M.move);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: 1 - out }}>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 110, textAlign: 'center', ...up(ti, 24) }}>
        <Lbl>NSI · IT Asset Management</Lbl>
        <div style={{ font: `600 104px ${SANS}`, color: CB.text, letterSpacing: -3, marginTop: 14 }}>NSI Hardware Lifecycle</div>
        <div style={{ font: `400 32px ${SANS}`, color: CB.dim, marginTop: 10 }}>Procurement, logistics, storage and decommissioning</div>
      </div>
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0 }}>
        <line x1="290" y1="560" x2={lerp(290, 1630, lineP)} y2="560" stroke={CB.line2} strokeWidth="4" strokeLinecap="round" strokeDasharray="2 12" />
      </svg>
      {STAGES.map((s, i) => {
        const p = tw(t, 1.6 + i * 0.75, 2.2 + i * 0.75, M.pop);
        const x = 290 + i * 268;
        return (
          <div key={s.n} style={{ position: 'absolute', left: x - 120, top: 500, width: 240, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16, opacity: clampN(p * 2), transform: `scale(${lerp(0.6, 1, Math.min(1, p))})` }}>
            <div style={{ width: 120, height: 120, borderRadius: 60, background: '#fff', boxShadow: SHADOW, display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: -60 + 60 }}>
              <Icon n={s.i} s={52} c={hc(s.h)} w={1.8} />
            </div>
            <div style={{ font: `600 20px ${MONO}`, color: hc(s.h) }}>{s.n}</div>
            <div style={{ font: `600 24px ${SANS}`, color: CB.text, textAlign: 'center', lineHeight: 1.2 }}>{s.t}</div>
          </div>
        );
      })}
      {t > 1.2 && <div style={{ position: 'absolute', left: lerp(290, 1630, lineP) - 60, top: 330, opacity: tw(t, 1.2, 1.7) }}><Person T={T} pose={lineP >= 1 ? 'point' : 'idle'} walk={lineP > 0 && lineP < 1 ? 1 : 0} shirt={hc(225)} s={0.55} /></div>}
      <div style={{ position: 'absolute', left: 0, right: 0, top: 830, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 12 }}>
        {[...FLOW, 'end'].map((k, i) => {
          const p = tw(t, 7.0 + i * 0.35, 7.4 + i * 0.35, M.pop);
          return (
            <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 12, opacity: clampN(p * 2), transform: `scale(${lerp(0.7, 1, Math.min(1, p))})` }}>
              {i > 0 && <Arr w={26} />}
              {k === 'end' ? <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 6 }}><Chip k="lager" s={0.85} /><Chip k="disposal" s={0.85} /></div> : <Chip k={k} s={0.85} />}
            </div>
          );
        })}
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 790, textAlign: 'center', ...up(tw(t, 6.8, 7.3, M.enter)) }}><Lbl>FNT Command status flow</Lbl></div>
    </div>
  );
}

// ---------- 01 procurement visuals ----------
function VBom({ lt }) {
  const rows = [['Router', 'RTR-2000', '2× PSU', '2'], ['Switch', 'SW-48P', '8× 10G module', '4'], ['Firewall', 'FW-3200', '—', '2'], ['Patch cords', 'Cat6A · 3 m', '—', '24']];
  const cols = [190, 220, 170, 80];
  return (
    <Win title="BOM_Example.xlsx" icon="sheet" h={440}>
      <div style={{ position: 'absolute', right: 26, top: -50, padding: '5px 14px', borderRadius: 14, background: tint(285), font: `600 16px ${SANS}`, color: deep(285) }}>BoM example</div>
      <div style={{ display: 'flex', padding: '8px 0 12px', borderBottom: `2px solid ${CB.line}` }}>
        {['Device', 'Model', 'Add-ons', 'Qty'].map((c, i) => <div key={c} style={{ width: cols[i], font: `600 18px ${SANS}`, color: CB.dim }}>{c}</div>)}
      </div>
      {rows.map((r, j) => (
        <div key={j} style={{ display: 'flex', padding: '16px 0', borderBottom: `1px solid ${CB.line}`, ...up(rv(lt, 0.4 + j * 0.45), 8) }}>
          {r.map((c, i) => <div key={i} style={{ width: cols[i], font: `${i ? 500 : 600} 21px ${i ? MONO : SANS}`, color: CB.text }}>{c}</div>)}
        </div>
      ))}
    </Win>
  );
}
function VStock({ lt }) {
  const q = 'SW-48P';
  const n = Math.round(q.length * tw(lt, 0.3, 1.2, LIN0));
  const rows = [['Warehouse DC-1 · Storage room A', 2], ['Warehouse DC-1 · Storage room B', 0], ['Central warehouse', 0]];
  const hi = rv(lt, 2.4);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
    <Win title="FNT Command · Storage rooms" icon="home" h={380}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, height: 52, borderRadius: 12, border: `2px solid ${CB.line2}`, padding: '0 16px' }}>
        <Icon n="search" s={24} c={CB.dim} />
        <div style={{ font: `500 22px ${MONO}`, color: CB.text }}>{q.slice(0, n)}<span style={{ opacity: n < q.length ? 1 : 0 }}>|</span></div>
      </div>
      <div style={{ marginTop: 14 }}>
        {rows.map(([l, c], i) => (
          <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '16px 16px', borderRadius: 12, background: c && hi ? mix('#ffffff', tint(75), hi) : '#fff', ...up(rv(lt, 1.3 + i * 0.3), 8) }}>
            <Icon n="box" s={26} c={c ? hc(75) : CB.faint} />
            <div style={{ flex: 1, font: `500 21px ${SANS}`, color: CB.text }}>{l}</div>
            <div style={{ font: `600 21px ${MONO}`, color: c ? deep(75) : CB.faint }}>{c} in stock</div>
          </div>
        ))}
      </div>
    </Win>
    {[['In stock', 'Use the existing devices. No procurement needed.', OKG, 'oklch(0.95 0.04 150)', 'shield'], ['Not in stock', 'Continue with the next step.', GREY, '#fff', 'cart']].map(([a, b, col, bg, ic], i) => (
      <div key={a} style={{ position: 'absolute', left: i * 396, top: 400, width: 384, boxSizing: 'border-box', padding: '18px 22px', borderRadius: 18, background: bg, boxShadow: i ? SHADOW : 'none', display: 'flex', gap: 14, alignItems: 'flex-start', ...up(rv(lt, 3.0 + i * 0.5)) }}>
        <Icon n={ic} s={30} c={col} />
        <div style={{ minWidth: 0 }}>
          <div style={{ font: `600 22px ${SANS}`, color: CB.text }}>{a}</div>
          <div style={{ font: `400 19px ${SANS}`, color: CB.dim, marginTop: 4, lineHeight: 1.35 }}>{b}</div>
        </div>
      </div>
    ))}
    </div>
  );
}
function VAlign({ lt }) {
  const roles = [['Cluster lead', '', 390, 60], ['NSI CMO', 'Cluster management', 140, 420], ['Corporate procurement', 'GM-OS, CP Sourcing Activities – Category', 640, 420]];
  const c = rv(lt, 0.2);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <svg width="780" height="560" style={{ position: 'absolute', inset: 0 }}>
        {roles.map(([l, , x, y], i) => { const p = tw(lt, 0.8 + i * 0.4, 1.4 + i * 0.4); return <line key={l} x1="390" y1="255" x2={lerp(390, x, p)} y2={lerp(255, y + 40, p)} stroke={hc(285)} strokeOpacity="0.4" strokeWidth="3" strokeDasharray="2 9" strokeLinecap="round" />; })}
      </svg>
      <Card style={{ left: 250, top: 205, width: 280, height: 100, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 14, background: tint(285), boxShadow: 'none', opacity: c }}>
        <div style={{ font: `600 24px ${SANS}`, color: deep(285), textAlign: 'center' }}>Budget &amp; next steps</div>
      </Card>
      {roles.map(([l, s, x, y], i) => {
        const p = tw(lt, 0.8 + i * 0.4, 1.3 + i * 0.4, M.pop);
        return (
          <Card key={l} style={{ left: x - 140, top: y, width: 280, padding: '18px 20px', display: 'flex', alignItems: 'center', gap: 14, opacity: clampN(p * 2), transform: `scale(${lerp(0.7, 1, Math.min(1, p))})` }}>
            <Icon n="people" s={34} c={hc(285)} />
            <div style={{ minWidth: 0 }}>
              <div style={{ font: `600 22px ${SANS}`, color: CB.text }}>{l}</div>
              {s && <div style={{ font: `400 16px ${SANS}`, color: CB.dim, lineHeight: 1.3, marginTop: 2 }}>{s}</div>}
            </div>
          </Card>
        );
      })}
    </div>
  );
}
function VOffers({ lt }) {
  const q = [['Reseller A', '€ 48,200'], ['Reseller B', '€ 45,900', 1], ['Reseller C', '€ 51,700']];
  const best = rv(lt, 2.0);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <div style={{ position: 'absolute', left: 0, top: 0, display: 'flex', alignItems: 'center', gap: 10, ...up(rv(lt, 0.1)) }}>
        <Icon n="mail" s={26} c={CB.dim} />
        <div style={{ font: `500 20px ${SANS}`, color: CB.dim }}>Cc: Corporate procurement · NSI CMO</div>
      </div>
      {q.map(([n, v, b], i) => {
        const p = tw(lt, 0.4 + i * 0.35, 0.9 + i * 0.35, M.pop);
        const w = b ? best : 0;
        return (
          <Card key={n} style={{ left: i * 264, top: 60, width: 248, height: 200, padding: '22px 24px', opacity: clampN(p * 2) * (b ? 1 : lerp(1, 0.55, best)), transform: `translateY(${(1 - Math.min(1, p)) * 20 - w * 8}px)`, boxShadow: w ? `0 0 0 ${3 * w}px ${hc(150)}, ${SHADOW}` : SHADOW }}>
            <Icon n="doc" s={30} c={CB.dim} />
            <div style={{ font: `600 22px ${SANS}`, color: CB.text, marginTop: 14 }}>{n}</div>
            <div style={{ font: `600 28px ${MONO}`, color: CB.text, marginTop: 6 }}>{v}</div>
            {b && <div style={{ position: 'absolute', left: 24, top: -16, padding: '4px 12px', borderRadius: 12, background: hc(150), font: `600 15px ${SANS}`, color: '#fff', opacity: w }}>Most economical</div>}
          </Card>
        );
      })}
      <Note style={{ left: 0, top: 300, width: 780, ...up(rv(lt, 2.8)) }} icon="warn" col="oklch(0.5 0.12 75)" bg="oklch(0.95 0.04 85)">Exclusive reseller or direct order at the vendor: the vendor must confirm this.</Note>
    </div>
  );
}
function VMail({ lt }) {
  const sent = rv(lt, 2.4, 0.5);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Win title="New message" icon="mail" h={390} style={{ transform: `translateX(${sent * 40}px)`, opacity: 1 - 0.3 * sent }}>
        {[['To', 'NSI CMO'], ['Cc', 'Corporate procurement'], ['Subject', 'Start procurement · BoM attached']].map(([l, v], i) => (
          <div key={l} style={{ display: 'flex', gap: 18, padding: '12px 0', borderBottom: `1px solid ${CB.line}`, ...up(rv(lt, 0.3 + i * 0.35), 6) }}>
            <div style={{ width: 100, font: `500 20px ${SANS}`, color: CB.dim }}>{l}</div>
            <div style={{ font: `600 21px ${SANS}`, color: CB.text }}>{v}</div>
          </div>
        ))}
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 16px', borderRadius: 12, background: '#F4F2EE', ...up(rv(lt, 1.4), 6) }}>
            <Icon n="sheet" s={22} c={hc(150)} /><div style={{ font: `500 18px ${MONO}`, color: CB.text }}>BOM_Example.xlsx</div>
          </div>
          <div style={{ flex: 1 }}></div>
          <div style={{ padding: '12px 30px', borderRadius: 12, background: hc(285), font: `600 21px ${SANS}`, color: '#fff', transform: `scale(${1 - 0.08 * Math.sin(tw(lt, 2.1, 2.5) * Math.PI)})` }}>Send</div>
        </div>
      </Win>
      <div style={{ position: 'absolute', left: 0, top: 430, display: 'flex', alignItems: 'center', gap: 14, ...up(sent) }}>
        <Check size={34} /><div style={{ font: `600 24px ${SANS}`, color: CB.text }}>Procurement process started</div>
      </div>
    </div>
  );
}


// ---------- illustrations ----------
const CARD = '#D9B27C', CARD_D = '#B88F58', BEAM = 'oklch(0.7 0.15 55)', UPR = 'oklch(0.42 0.06 255)';
function Truck({ x, y, rot = 0 }) {
  const wheel = (cx) => (
    <g key={cx} transform={`rotate(${rot} ${cx} 175)`}>
      <circle cx={cx} cy="175" r="27" fill="#2B3245" /><circle cx={cx} cy="175" r="12" fill="#C9CED9" />
      <line x1={cx - 12} y1="175" x2={cx + 12} y2="175" stroke="#8C93A6" strokeWidth="3" /><line x1={cx} y1="163" x2={cx} y2="187" stroke="#8C93A6" strokeWidth="3" />
    </g>
  );
  return (
    <svg width="420" height="210" viewBox="0 0 420 210" style={{ position: 'absolute', left: x, top: y, overflow: 'visible' }}>
      <rect x="0" y="0" width="292" height="168" rx="6" fill="#F8F7F4" stroke="#D2CEC5" strokeWidth="3" />
      <rect x="0" y="118" width="292" height="16" fill={hc(255)} />
      {[60, 120, 180, 240].map((v) => <line key={v} x1={v} y1="6" x2={v} y2="112" stroke="#ECE9E2" strokeWidth="3" />)}
      <path d="M296 52 L360 52 Q372 52 380 66 L404 112 Q408 120 408 130 L408 168 L296 168 Z" fill={hc(255)} />
      <path d="M312 64 L356 64 Q364 64 368 72 L388 110 L312 110 Z" fill="oklch(0.88 0.04 230)" />
      <rect x="396" y="140" width="14" height="10" rx="3" fill={AMBER} />
      <rect x="0" y="168" width="410" height="12" rx="4" fill="#3B4359" />
      {[64, 226, 350].map(wheel)}
    </svg>
  );
}
function Pallet({ x, y, n = 3 }) {
  return (
    <div style={{ position: 'absolute', left: x, top: y, width: 120 }}>
      {Array.from({ length: n }).map((_, i) => (
        <div key={i} style={{ position: 'absolute', left: i % 2 ? 58 : 4, bottom: 14 + Math.floor(i / 2) * 50, width: 56, height: 48, background: CARD, border: `2px solid ${CARD_D}`, borderRadius: 3, boxSizing: 'border-box' }}>
          <div style={{ position: 'absolute', left: 22, top: 0, width: 10, height: '100%', background: '#C99E66' }}></div>
        </div>
      ))}
      <div style={{ position: 'absolute', left: 0, bottom: 0, width: 120, height: 14, background: 'repeating-linear-gradient(90deg, #A9814C 0 22px, transparent 22px 32px)', borderTop: '4px solid #A9814C', boxSizing: 'border-box' }}></div>
    </div>
  );
}
function VTruck({ lt }) {
  const drive = tw(lt, 0.2, 2.2, M.move);
  const door = tw(lt, 2.4, 3.2, M.enter);
  const pal = tw(lt, 3.3, 4.6, M.move);
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', borderRadius: 22, background: 'linear-gradient(180deg, oklch(0.95 0.025 230), oklch(0.97 0.01 230) 70%)', boxShadow: SHADOW }}>
      <div style={{ position: 'absolute', left: 0, top: 40, width: 330, height: 400, background: '#E6E1D6', backgroundImage: 'repeating-linear-gradient(90deg, transparent 0 54px, rgba(0,0,0,0.04) 54px 56px)' }}></div>
      <div style={{ position: 'absolute', left: 0, top: 40, width: 330, height: 16, background: '#CFC9BC' }}></div>
      <div style={{ position: 'absolute', left: 28, top: 82 }}><Lbl>Data centre</Lbl></div>
      <div style={{ position: 'absolute', left: 150, top: 176, width: 170, padding: '6px 10px', borderRadius: 6, background: hc(255), font: `600 15px ${SANS}`, color: '#fff', textAlign: 'center' }}>Delivery area · backside</div>
      <div style={{ position: 'absolute', left: 160, top: 222, width: 150, height: 188, background: '#4A5268', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', left: 0, top: 0, width: 150, height: 188 * (1 - door), background: 'repeating-linear-gradient(180deg, #B9BFCC 0 14px, #A6ADBC 14px 16px)' }}></div>
      </div>
      <div style={{ position: 'absolute', left: 0, top: 410, width: 340, height: 40, background: '#C9C3B6' }}></div>
      <div style={{ position: 'absolute', left: 326, top: 360, width: 14, height: 50, borderRadius: 4, background: '#2B3245' }}></div>
      <div style={{ position: 'absolute', left: 0, top: 450, width: 780, height: 150, background: '#BDB8AD' }}></div>
      <div style={{ position: 'absolute', left: 0, top: 520, width: 780, height: 6, background: 'repeating-linear-gradient(90deg, #F4F2EE 0 50px, transparent 50px 90px)', opacity: 0.7 }}></div>
      {pal > 0 && <div style={{ opacity: tw(lt, 3.3, 3.6) }}><Pallet x={lerp(330, 175, pal)} y={300} /></div>}
      <Truck x={lerp(820, 336, drive)} y={232} rot={-drive * 900} />
    </div>
  );
}
function VStore({ lt }) {
  const shelves = [[[70, 50, 90], [60, 80], [100, 60]], [[80, 60], [70, 0, 70], [60, 90, 60]]];
  const slide = tw(lt, 0.8, 2.0, M.move);
  const hi = rv(lt, 2.0);
  const unit = (ux, rows, ui) => (
    <div key={ui} style={{ position: 'absolute', left: ux, top: 90, width: 320, height: 370 }}>
      {[0, 310].map((x) => <div key={x} style={{ position: 'absolute', left: x, top: 0, width: 10, height: 370, background: UPR }}></div>)}
      {[110, 230, 350].map((y, li) => (
        <div key={y}>
          <div style={{ position: 'absolute', left: 0, top: y, width: 320, height: 10, background: BEAM }}></div>
          <div style={{ position: 'absolute', left: 16, top: y - 84, width: 288, height: 84, display: 'flex', alignItems: 'flex-end', gap: 8 }}>
            {rows[li].map((w, bi) => {
              const empty = w === 0;
              if (empty) return (
                <div key={bi} style={{ width: 84, height: 70, borderRadius: 4, border: `3px dashed ${mix(CB.line2, hc(255), hi)}`, boxSizing: 'border-box', position: 'relative', background: hi ? mix('transparent', tint(255), hi) : 'transparent' }}>
                  <div style={{ position: 'absolute', left: 0, bottom: 0, width: 84, height: 66, background: CARD, border: `2px solid ${CARD_D}`, borderRadius: 3, boxSizing: 'border-box', transform: `translateX(${(1 - slide) * 140}px)`, opacity: clampN(slide * 3) }}>
                    <div style={{ position: 'absolute', left: 14, top: 14, width: 40, height: 22, background: '#fff', borderRadius: 2 }}></div>
                  </div>
                </div>
              );
              return (
                <div key={bi} style={{ width: w, height: 40 + ((bi * 17 + li * 11) % 30), background: CARD, border: `2px solid ${CARD_D}`, borderRadius: 3, boxSizing: 'border-box', position: 'relative' }}>
                  {(bi + li) % 2 === 0 && <div style={{ position: 'absolute', left: 8, top: 8, width: 26, height: 14, background: '#fff', borderRadius: 2 }}></div>}
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <div style={{ position: 'absolute', left: 0, top: 0, width: 780, height: 480, overflow: 'hidden', borderRadius: 22, background: 'linear-gradient(180deg, #ECE8E0 0 72%, #D9D4C8 72%)', boxShadow: SHADOW }}>
        {[180, 600].map((x) => <div key={x} style={{ position: 'absolute', left: x - 50, top: 0, width: 100, height: 10, background: '#B9BFCC' }}><div style={{ position: 'absolute', left: -60, top: 10, width: 220, height: 160, background: 'radial-gradient(ellipse at 50% 0, rgba(255,250,230,0.9), transparent 70%)' }}></div></div>)}
        <div style={{ position: 'absolute', left: 24, top: 26 }}><Lbl>Storage room A</Lbl></div>
        {unit(40, shelves[0], 0)}{unit(420, shelves[1], 1)}
        <div style={{ position: 'absolute', left: 560, top: 218, transform: 'translateX(-50%)', padding: '5px 12px', borderRadius: 10, background: hc(255), font: `600 15px ${MONO}`, color: '#fff', whiteSpace: 'nowrap', ...up(hi, 8) }}>Shelf B2</div>
      </div>
      <Card style={{ left: 0, top: 500, width: 780, padding: '16px 24px', display: 'flex', alignItems: 'center', gap: 16, ...up(rv(lt, 2.6)) }}>
        <Icon n="home" s={26} c={hc(255)} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: `600 20px ${SANS}`, color: CB.text }}>Storage room registered in FNT Command</div>
          <div style={{ font: `400 18px ${SANS}`, color: CB.dim, marginTop: 2 }}>Not enough space? Contact SL-Datacenter.</div>
        </div>
        <Chip k="none" s={0.9} />
      </Card>
    </div>
  );
}
function VShip({ lt }) {
  const mv = tw(lt, 0.6, 1.8, M.move);
  const van = tw(lt, 2.6, 4.0, M.move);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <div style={{ position: 'absolute', left: 0, top: 0, width: 780, height: 470, overflow: 'hidden', borderRadius: 22, background: 'linear-gradient(180deg, #ECE8E0 0 70%, #D9D4C8 70%)', boxShadow: SHADOW }}>
        <div style={{ position: 'absolute', left: 300, top: 40, padding: '8px 18px', borderRadius: 8, background: hc(255), display: 'flex', alignItems: 'center', gap: 10 }}><Icon n="mail" s={24} c="#fff" /><div style={{ font: `600 20px ${SANS}`, color: '#fff' }}>Company mail service</div></div>
        <div style={{ position: 'absolute', left: 60, top: 230, width: 520, height: 20, borderRadius: 6, background: '#B9BFCC' }}></div>
        <div style={{ position: 'absolute', left: 80, top: 250, width: 480, height: 110, background: '#CDD2DC' }}></div>
        <div style={{ position: 'absolute', left: lerp(-140, 300, mv), top: 140, width: 120, height: 90, background: CARD, border: `2px solid ${CARD_D}`, borderRadius: 4, boxSizing: 'border-box' }}>
          <div style={{ position: 'absolute', left: 50, top: 0, width: 16, height: '100%', background: '#C99E66' }}></div>
          <div style={{ position: 'absolute', left: 10, top: 16, width: 34, height: 26, background: '#fff', borderRadius: 2, opacity: rv(lt, 1.6) }}></div>
        </div>
        <div style={{ position: 'absolute', left: 600, top: 90, width: 150, height: 240, border: '8px solid #B9BFCC', borderBottom: 'none', boxSizing: 'border-box', background: 'oklch(0.93 0.03 230)', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', left: lerp(10, 170, van), top: 120, width: 110, height: 70 }}>
            <div style={{ position: 'absolute', left: 0, top: 0, width: 80, height: 54, background: '#fff', border: '2px solid #D2CEC5', borderRadius: 4 }}></div>
            <div style={{ position: 'absolute', left: 80, top: 16, width: 30, height: 38, background: hc(255), borderRadius: '0 10px 4px 0' }}></div>
            {[18, 86].map((x) => <div key={x} style={{ position: 'absolute', left: x - 10, top: 48, width: 20, height: 20, borderRadius: 10, background: '#2B3245' }}></div>)}
          </div>
        </div>
        <div style={{ position: 'absolute', left: 24, top: 26, display: 'flex', gap: 10 }}>
          {['Wrong delivery', 'RMA'].map((l) => <div key={l} style={{ padding: '6px 16px', borderRadius: 20, background: '#fff', boxShadow: '0 2px 8px rgba(24,33,58,0.1)', font: `600 18px ${SANS}`, color: CB.text }}>{l}</div>)}
        </div>
      </div>
    </div>
  );
}

// ---------- 02 delivery visuals ----------
function VAnnounce({ lt }) {
  const f = ['NSI contact (name, phone)', 'Estimated delivery date', 'Freight forwarder / parcel service', "Driver's name", 'License plate', 'Supplier (reseller or manufacturer)'];
  const sent = rv(lt, 3.4);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Win title="Delivery announcement" icon="form" h={470} style={{ width: 540 }}>
        {f.map((l, i) => {
          const p = rv(lt, 0.4 + i * 0.4, 0.3);
          return (
            <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '11px 0', borderBottom: `1px solid ${CB.line}` }}>
              <div style={{ flex: 1, font: `500 20px ${SANS}`, color: CB.text }}>{l}</div>
              <div style={{ width: 90, height: 12, borderRadius: 6, background: mix(CB.line, CB.line2, p), transform: `scaleX(${p})`, transformOrigin: 'left' }}></div>
              <div style={{ opacity: p >= 1 ? 1 : 0 }}><Check size={24} /></div>
            </div>
          );
        })}
      </Win>
      <div style={{ position: 'absolute', left: 556, top: 200, opacity: sent }}><Arr w={50} col={hc(255)} /></div>
      <div style={{ position: 'absolute', left: 612, top: 110, width: 168, height: 250, ...up(rv(lt, 0.2)) }}>
        <div style={{ position: 'absolute', left: 10, top: 40, width: 96, height: 130, background: '#fff', borderRadius: '8px 8px 0 0', boxShadow: SHADOW }}>
          <div style={{ position: 'absolute', left: -8, top: -14, width: 112, height: 16, borderRadius: 6, background: hc(255) }}></div>
          <div style={{ position: 'absolute', left: 14, top: 18, width: 68, height: 44, borderRadius: 6, background: 'oklch(0.9 0.04 230)' }}></div>
          <div style={{ position: 'absolute', left: 30, top: 80, display: 'flex' }}><Icon n="shield" s={34} c={hc(255)} /></div>
        </div>
        <div style={{ position: 'absolute', left: 104, top: 128, width: 12, height: 42, background: UPR, borderRadius: 3 }}></div>
        <div style={{ position: 'absolute', left: 110, top: 128, width: 80, height: 10, borderRadius: 5, background: 'repeating-linear-gradient(90deg, #fff 0 12px, oklch(0.62 0.18 30) 12px 24px)', transformOrigin: '0 50%', transform: `rotate(${-70 * sent}deg)` }}></div>
        <div style={{ position: 'absolute', left: 0, top: 170, width: 168, height: 6, background: CB.line2, borderRadius: 3 }}></div>
        <div style={{ position: 'absolute', left: 0, top: 190, width: 168, textAlign: 'center', font: `600 19px ${SANS}`, color: CB.text }}>Security centre</div>
      </div>
      <div style={{ position: 'absolute', left: 0, top: 492, font: `500 20px ${SANS}`, color: CB.dim, ...up(rv(lt, 0.2)) }}>For larger volumes, e.g. pallets from a freight forwarder</div>
    </div>
  );
}
function VCheck({ lt }) {
  const pr = [['Serial number', 'SN-100234'], ['Model', 'SW-48P'], ['Manufacturer', 'Vendor X']];
  const big = rv(lt, 2.6);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      {[['Delivery note', 'doc', 0], ['On the device', 'box', 420]].map(([l, ic, x], k) => (
        <Card key={l} style={{ left: x, top: 0, width: 360, padding: '20px 24px', ...up(rv(lt, 0.1 + k * 0.25)) }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}><Icon n={ic} s={26} c={CB.dim} /><Lbl>{l}</Lbl></div>
          {pr.map(([a, b]) => (
            <div key={a} style={{ marginTop: 14 }}>
              <div style={{ font: `500 16px ${SANS}`, color: CB.dim }}>{a}</div>
              <div style={{ font: `600 22px ${MONO}`, color: CB.text }}>{b}</div>
            </div>
          ))}
        </Card>
      ))}
      {pr.map((_, i) => { const p = rv(lt, 0.9 + i * 0.4, 0.3); return <div key={i} style={{ position: 'absolute', left: 372, top: 96 + i * 66, transform: `scale(${p})` }}><Check size={36} /></div>; })}
      <Card style={{ left: 0, top: 340, width: 780, padding: '22px 28px', display: 'flex', alignItems: 'center', gap: 22, ...up(big) }}>
        <Icon n="people" s={46} c={hc(255)} />
        <div style={{ flex: 1, font: `600 24px ${SANS}`, color: CB.text }}>Four-eyes principle</div>
        <div style={{ font: `600 56px ${MONO}`, color: hc(255), letterSpacing: -1 }}>5</div>
        <div style={{ font: `500 21px ${SANS}`, color: CB.dim, lineHeight: 1.2 }}>working<br />days</div>
      </Card>
    </div>
  );
}
function VProblem({ lt }) {
  const a = rv(lt, 1.2);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Card style={{ left: 0, top: 60, width: 320, padding: '24px 26px', ...up(rv(lt, 0.1)) }}>
        <Icon n="box" s={44} c={CB.dim} w={1.8} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 18 }}>
          {['Incomplete', 'Wrong delivery', 'Defective'].map((l, i) => (
            <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 10, ...up(rv(lt, 0.4 + i * 0.25), 6) }}><Dot col={CORAL} size={12} /><div style={{ font: `600 22px ${SANS}`, color: CORAL_D }}>{l}</div></div>
          ))}
        </div>
      </Card>
      <div style={{ position: 'absolute', left: 340, top: 175, opacity: a }}><Arr w={90} col={CORAL} /></div>
      <Card style={{ left: 450, top: 90, width: 330, padding: '24px 26px', ...up(a) }}>
        <Icon n="people" s={40} c={hc(255)} />
        <div style={{ font: `600 26px ${SANS}`, color: CB.text, marginTop: 14 }}>Align with the vendor</div>
        <div style={{ font: `400 20px ${SANS}`, color: CB.dim, marginTop: 6, lineHeight: 1.35 }}>Manufacturer or reseller, depending on the product</div>
      </Card>
    </div>
  );
}
// ---------- 02 commercial visuals ----------
function Invoice({ stamp, col, x = 0 }) {
  return (
    <Card style={{ left: x, top: 20, width: 330, height: 400, padding: '26px 28px' }}>
      <Lbl>Invoice</Lbl>
      {[0.9, 0.6, 0.75, 0.5, 0.8, 0.4].map((w, i) => <div key={i} style={{ height: 12, width: `${w * 100}%`, borderRadius: 6, background: CB.line, marginTop: i === 0 ? 24 : 16 }}></div>)}
      <div style={{ height: 2, background: CB.line, margin: '28px 0 14px' }}></div>
      <div style={{ display: 'flex', justifyContent: 'space-between', font: `600 22px ${MONO}`, color: CB.text }}><span>Total</span><span>€ 45,900</span></div>
      {stamp}
    </Card>
  );
}
const Stamp = ({ p, col, text }) => (
  <div style={{ position: 'absolute', left: 60, top: 150, padding: '10px 20px', border: `4px solid ${col}`, borderRadius: 12, font: `700 26px ${MONO}`, color: col, letterSpacing: 1, textTransform: 'uppercase', opacity: clampN(p * 2), transform: `rotate(-12deg) scale(${lerp(1.8, 1, Math.min(1, p))})`, background: 'rgba(255,255,255,0.85)', whiteSpace: 'nowrap' }}>{text}</div>
);
function VInvoice({ lt }) {
  const s = tw(lt, 0.8, 1.2, M.pop), a = rv(lt, 1.6);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Invoice stamp={<Stamp p={s} col={hc(150)} text="Approved · NSI PO" />} />
      <div style={{ position: 'absolute', left: 350, top: 210, opacity: a }}><Arr w={80} col={hc(255)} /></div>
      <Card style={{ left: 450, top: 120, width: 330, padding: '26px', ...up(a) }}>
        <Icon n="sheet" s={40} c={hc(255)} />
        <div style={{ font: `600 26px ${SANS}`, color: CB.text, marginTop: 14 }}>Commercial inventory</div>
        <div style={{ font: `400 20px ${SANS}`, color: CB.dim, marginTop: 6 }}>Done by the NSI CMO</div>
      </Card>
    </div>
  );
}
function VBlocked({ lt }) {
  const s = tw(lt, 0.6, 1.0, M.pop);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Invoice stamp={<Stamp p={s} col={CORAL} text="Not released" />} />
      <Card style={{ left: 380, top: 100, width: 400, padding: '26px 28px', ...up(rv(lt, 1.0)) }}>
        <Lbl c={CORAL_D}>Invoice is held if</Lbl>
        {['Delivery is incomplete', 'Delivery is wrong', 'Hardware is defective'].map((l, i) => (
          <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 16, ...up(rv(lt, 1.3 + i * 0.25), 6) }}><Icon n="warn" s={26} c={CORAL} /><div style={{ font: `500 22px ${SANS}`, color: CB.text }}>{l}</div></div>
        ))}
      </Card>
    </div>
  );
}
function VShipForm({ lt }) {
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      {[['form', 'Shipping form', 'Request it from mail services and fill it in before handing over'], ['doc', 'Shipping_Checklist.pdf', 'Shipping checklist'], ['truck', 'Different pick-up location', 'Can be requested from mail services']].map(([ic, a, b], i) => (
        <Card key={a} style={{ left: 0, top: i * 150, width: 780, height: 130, padding: '0 28px', display: 'flex', alignItems: 'center', gap: 22, ...up(rv(lt, 0.2 + i * 0.7)) }}>
          <div style={{ width: 64, height: 64, borderRadius: 16, background: tint(255), display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none' }}><Icon n={ic} s={34} c={hc(255)} /></div>
          <div style={{ minWidth: 0 }}>
            <div style={{ font: `600 25px ${i === 1 ? MONO : SANS}`, color: CB.text }}>{a}</div>
            <div style={{ font: `400 20px ${SANS}`, color: CB.dim, marginTop: 4 }}>{b}</div>
          </div>
        </Card>
      ))}
    </div>
  );
}

// ---------- 03 inventory visuals ----------
function VDeadline({ lt }) {
  const days = ['M', 'T', 'W', 'T', 'F', 'M', 'T', 'W', 'T', 'F'];
  const f = tw(lt, 0.6, 2.6, LIN0);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Card style={{ left: 0, top: 30, width: 780, padding: '30px 34px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 18 }}>
          <div style={{ font: `600 110px ${MONO}`, color: hc(225), letterSpacing: -4, lineHeight: 1 }}>{Math.max(1, Math.ceil(f * 10))}</div>
          <div style={{ font: `600 34px ${SANS}`, color: CB.text }}>working days</div>
        </div>
        <div style={{ font: `400 21px ${SANS}`, color: CB.dim, marginTop: 8 }}>after delivery, to register in FNT Command</div>
        <div style={{ display: 'flex', gap: 8, marginTop: 30 }}>
          {days.map((d, i) => (
            <div key={i} style={{ flex: 1, height: 76, borderRadius: 12, background: i < f * 10 ? hc(225) : '#F4F2EE', display: 'flex', alignItems: 'center', justifyContent: 'center', font: `600 20px ${MONO}`, color: i < f * 10 ? '#fff' : CB.faint, marginRight: i === 4 ? 14 : 0 }}>{d}</div>
          ))}
        </div>
      </Card>
      <div style={{ position: 'absolute', left: 0, top: 400, display: 'flex', alignItems: 'center', gap: 14, ...up(rv(lt, 2.6)) }}>
        <Icon n="people" s={36} c={hc(225)} /><div style={{ font: `500 22px ${SANS}`, color: CB.text }}>Done by the NSI person who initiated the order</div>
      </div>
    </div>
  );
}
function VWhView({ lt }) {
  const nav = ['Navigator', 'Inventory Management', 'Object Management'];
  const sel = rv(lt, 0.8);
  return (
    <Win title="FNT Command" icon="db" h={420}>
      <div style={{ display: 'flex', gap: 24 }}>
        <div style={{ width: 280, display: 'flex', flexDirection: 'column', gap: 6 }}>
          {nav.map((n, i) => <div key={n} style={{ padding: '12px 16px', borderRadius: 10, background: i === 1 ? mix('#ffffff', tint(225), sel) : 'transparent', font: `${i === 1 ? 600 : 500} 20px ${SANS}`, color: i === 1 ? mix(CB.text, deep(225), sel) : CB.dim }}>{n}</div>)}
        </div>
        <div style={{ flex: 1, borderLeft: `1px solid ${CB.line}`, paddingLeft: 24, ...up(rv(lt, 1.3)) }}>
          <Lbl>Storage rooms</Lbl>
          {[['DC-1', 0], ['Storage room A', 1, 1], ['Storage room B', 1], ['DC-2', 0]].map(([l, d, k], i) => (
            <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '11px 12px', marginLeft: d * 28, marginTop: i ? 0 : 12, borderRadius: 10, background: k ? mix('#ffffff', tint(225), rv(lt, 2.2)) : 'transparent' }}>
              <Icon n={d ? 'box' : 'home'} s={22} c={k ? hc(225) : CB.dim} /><div style={{ font: `${k ? 600 : 500} 20px ${SANS}`, color: CB.text }}>{l}</div>
            </div>
          ))}
        </div>
      </div>
    </Win>
  );
}
function VBulk({ lt }) {
  const fly = tw(lt, 1.8, 2.8, M.move);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Win title="Command_Importsheet_example.xlsx" icon="sheet" h={330} style={{ width: 500, transform: `scale(${1 - 0.1 * fly})`, transformOrigin: 'left top' }}>
        {[['SW-48P', 'SN-100234'], ['SW-48P', 'SN-100235'], ['RTR-2000', 'SN-200871'], ['FW-3200', 'SN-300512']].map(([a, b], i) => (
          <div key={b} style={{ display: 'flex', gap: 20, padding: '12px 0', borderBottom: `1px solid ${CB.line}`, ...up(rv(lt, 0.2 + i * 0.3), 6) }}>
            <div style={{ width: 170, font: `500 19px ${MONO}`, color: CB.text }}>{a}</div><div style={{ font: `500 19px ${MONO}`, color: CB.dim }}>{b}</div>
          </div>
        ))}
      </Win>
      <div style={{ position: 'absolute', left: lerp(420, 560, fly), top: 130, opacity: fly > 0 && fly < 1 ? 1 : 0 }}><Icon n="mail" s={50} c={hc(225)} /></div>
      <Card style={{ left: 600, top: 90, width: 180, padding: '22px 18px', textAlign: 'center', ...up(rv(lt, 2.4)) }}>
        <div style={{ display: 'flex', justifyContent: 'center' }}><Icon n="people" s={40} c={hc(225)} /></div>
        <div style={{ font: `600 21px ${SANS}`, color: CB.text, marginTop: 10 }}>Command team</div>
      </Card>
      <div style={{ position: 'absolute', left: 0, top: 360, display: 'flex', alignItems: 'center', gap: 12, ...up(rv(lt, 0.4)) }}>
        <div style={{ padding: '6px 16px', borderRadius: 16, background: hc(225), font: `600 18px ${SANS}`, color: '#fff' }}>Preferred</div>
        <div style={{ font: `500 21px ${SANS}`, color: CB.dim }}>for multiple devices</div>
      </div>
    </div>
  );
}
function VManual({ lt }) {
  const f = [['Type', 'Switch'], ['Manufacturer', 'Vendor X'], ['Model', 'SW-48P'], ['Serial number', 'SN-100234'], ['Location', 'DC-1 · Storage room A']];
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Win title="FNT Command · New device" icon="db" h={400}>
        {f.map(([l, v], i) => <Field key={l} l={l} v={v} w={190} p={tw(lt, 0.3 + i * 0.45, 0.7 + i * 0.45, LIN0)} />)}
      </Win>
      <div style={{ position: 'absolute', left: 0, top: 425, display: 'flex', alignItems: 'center', gap: 12, ...up(rv(lt, 2.8)) }}>
        <Icon n="doc" s={30} c={hc(225)} /><div style={{ font: `500 21px ${SANS}`, color: CB.text }}>Training material: FNT Command Basics</div>
      </div>
    </div>
  );
}
function VStatusSet({ lt }) {
  const r = [['Registered, in stock or central warehouse', 'lager'], ['Reserved for an installation, still in stock', 'lager'], ['Moved to the installation location, initial installation and cabling', 'planning']];
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      {r.map(([l, k], i) => (
        <Card key={l} style={{ left: 0, top: i * 140, width: 780, height: 120, padding: '0 28px', display: 'flex', alignItems: 'center', gap: 20, ...up(rv(lt, 0.2 + i * 0.7)) }}>
          <div style={{ flex: 1, font: `500 23px ${SANS}`, color: CB.text, lineHeight: 1.3, textWrap: 'pretty' }}>{l}</div>
          <Chip k={k} s={1.1} />
        </Card>
      ))}
    </div>
  );
}

// ---------- 04 setup ----------
const PH = [
  { n: 'Install', k: 'planning', s: ['Record and data entry in FNT Command (location, cabling)', 'Transport to installation location', 'Physical installation in the rack', 'Physical cabling'], sn: ['Not monitored', GREY] },
  { n: 'Activate', k: 'planning', s: ['Initial OS and firmware setup', 'Security hardening', 'Monitoring onboarding and management config', 'Service Activation Checklist'], sn: ['Onboarding', 'oklch(0.6 0.1 205)'] },
  { n: 'Operate', k: 'operational', s: ['Device goes live', 'Running in production', 'Maintenance: set the device to Maintenance in StableNet', 'FNT Command status stays Operational'], sn: ['Monitored', OKG] },
  { n: 'Sunset', k: 'oos', s: ['End of production reached', 'Service deactivated', 'Service Deactivation Checklist', 'Still physically in the rack'], sn: ['Not monitored', GREY] },
];
function Setup({ T, K }) {
  const t = (T - K.Se) / SLOW, end = K.De;
  if (t < -0.1 || T > end + 0.1) return null;
  const o = tw(t, 0, 0.6, M.enter) * (1 - tw(T, end - 0.6, end));
  const pa = [1.0, 6.5, 12.5, 25.0];
  let cur = -1;
  pa.forEach((a, i) => { if (t >= a) cur = i; });
  const maint = tw(t, 17.5, 18.0, M.enter) * (1 - tw(t, 24.3, 24.8, M.enter));
  const pose = cur < 0 ? 'idle' : maint > 0.5 ? 'wrench' : ['wrench', 'laptop', 'point', 'clip'][cur];
  const pk = maint > 0.5 ? 'm' : cur;
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <Header st={3} title="Setup, Operation and Maintenance" o={tw(t, 0, 0.7, M.enter)} />
      {PH.map((ph, i) => {
        const ap = tw(t, 0.3 + i * 0.12, 0.8 + i * 0.12, M.enter);
        const act = i === cur, done = i < cur;
        const lt = t - pa[i];
        const isOp = i === 2;
        const snCol = isOp && maint > 0.5 ? AMBER : ph.sn[1];
        const snTxt = isOp && maint > 0.5 ? 'Maintenance mode' : ph.sn[0];
        return (
          <div key={ph.n} style={{ position: 'absolute', left: 420 + i * 342, top: 280, width: 330, height: 500, boxSizing: 'border-box', borderRadius: 20, padding: '22px 24px', background: act ? '#fff' : 'rgba(255,255,255,0.55)', boxShadow: act ? SHADOW : 'none', opacity: ap * (act ? 1 : done ? 0.8 : 0.5), transform: `translateY(${(1 - ap) * 20}px)` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ font: `600 18px ${MONO}`, color: hc(160) }}>{i + 1}</div>
              <div style={{ font: `600 28px ${SANS}`, color: CB.text, flex: 1 }}>{ph.n}</div>
            </div>
            <div style={{ marginTop: 14 }}><Chip k={ph.k} /></div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginTop: 22 }}>
              {ph.s.map((s, j) => {
                const p = cur > i ? 1 : act ? rv(lt, isOp && j >= 2 ? 5.0 + (j - 2) * 0.8 : 0.4 + j * 0.9) : 0;
                const hiM = isOp && j >= 2 ? maint : 0;
                return (
                  <div key={s} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', opacity: 0.35 + 0.65 * p, padding: hiM ? '6px 8px' : 0, margin: hiM ? '-6px -8px' : 0, borderRadius: 10, background: hiM ? mix('#ffffff', 'oklch(0.95 0.05 85)', hiM) : 'transparent' }}>
                    <div style={{ marginTop: 2, transform: `scale(${0.6 + 0.4 * p})` }}>{p >= 1 ? <Check size={24} /> : <div style={{ width: 24, height: 24, borderRadius: 12, border: `2px solid ${CB.line2}`, boxSizing: 'border-box' }}></div>}</div>
                    <div style={{ font: `500 19px ${SANS}`, color: CB.text, lineHeight: 1.3, textWrap: 'pretty' }}>{s}</div>
                  </div>
                );
              })}
            </div>
            <div style={{ position: 'absolute', left: 24, right: 24, bottom: 20, paddingTop: 14, borderTop: `1px solid ${CB.line}`, display: 'flex', alignItems: 'center', gap: 10 }}>
              <Icon n={isOp && maint > 0.5 ? 'pause' : 'pulse'} s={26} c={snCol} />
              <div style={{ minWidth: 0 }}>
                <div style={{ font: `500 14px ${MONO}`, color: CB.dim, letterSpacing: 1, textTransform: 'uppercase' }}>StableNet</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 2 }}><Dot col={snCol} size={10} /><div style={{ font: `600 18px ${SANS}`, color: CB.text }}>{snTxt}</div></div>
              </div>
            </div>
          </div>
        );
      })}
      <div style={{ position: 'absolute', left: 140, top: 430, ...up(tw(t, 0.4, 1.0, M.enter), 20) }}>
        <div key={pk} style={{ opacity: tw(t - (pk === 'm' ? 17.5 : pa[Math.max(0, cur)]), 0, 0.35, M.enter) }}><Actor T={T} a={{ p: pose }} x={0} y={0} s={1.1} /></div>
      </div>
      <Note style={{ left: 420, top: 806, width: 672, ...up(tw(t, 13.4, 14.0, M.enter) * (1 - tw(t, 18.0, 18.4))) }} icon="pulse" col={deep(150)} bg="oklch(0.95 0.04 150)">Set up correctly in Command, the device is monitored by StableNet automatically.</Note>
      <Note style={{ left: 1108, top: 806, width: 672, ...up(tw(t, 18.0, 18.6, M.enter) * (1 - tw(t, 24.6, 25.0))) }} icon="pause" col="oklch(0.5 0.12 75)" bg="oklch(0.95 0.05 85)">Maintenance: set the device to <b>Maintenance in StableNet</b>. Keep it <b>Operational in FNT Command</b>.</Note>
      <Note style={{ left: 420, top: 806, width: 672, ...up(tw(t, 20.4, 21.0, M.enter)) }}>Changing the status in FNT Command deletes the device and all of its history in StableNet.</Note>
    </div>
  );
}

// ---------- 05 decommissioning visuals ----------
function VSnow({ i, lt }) {
  const f1 = i > 1 ? 1 : i === 1 ? tw(lt, 0.4, 1.2, LIN0) : 0;
  const f2 = (k) => (i > 2 ? 1 : i === 2 ? tw(lt, 0.4 + k * 0.6, 0.9 + k * 0.6, LIN0) : 0);
  const sub = i === 2 ? tw(lt, 2.6, 3.0) : 0;
  const done = i === 2 ? rv(lt, 3.1) : 0;
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Win title="ServiceNow · Employee Center" icon="form" h={500}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, font: `500 18px ${SANS}`, color: CB.dim }}>
          <span>DCBI</span><span>›</span><span style={{ color: CB.text, fontWeight: 600 }}>De-Commission Hardware</span>
        </div>
        <div style={{ marginTop: 10 }}>
          <Field l="Service offering" v="01-54-58_Default" p={f1} w={200} />
          <Field l="Type" v="Switch · SW-48P" p={f2(0)} w={200} />
          <Field l="Serial number" v="SN-100234" p={f2(1)} w={200} />
          <Field l="Location" v="DC-1 · R04 · U35" p={f2(2)} w={200} />
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: 16, marginTop: 22 }}>
          {done > 0 && <div style={{ display: 'flex', alignItems: 'center', gap: 10, opacity: done }}><Check size={28} /><div style={{ font: `600 20px ${SANS}`, color: CB.text }}>Request submitted</div></div>}
          <div style={{ padding: '12px 30px', borderRadius: 12, background: i >= 2 ? hc(35) : CB.line, font: `600 21px ${SANS}`, color: i >= 2 ? '#fff' : CB.faint, transform: `scale(${1 - 0.08 * Math.sin(sub * Math.PI)})` }}>Submit</div>
        </div>
      </Win>
    </div>
  );
}
function VDcbi({ lt }) {
  const a = [['db', 'Cleanup in FNT Command', 'eng'], ['shield', 'Hard drives disposed of per company policy, referencing the ServiceNow request', 'dcbi'], ['pen', 'Requester confirms the disposal order with a signature', 'req']];
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <div style={{ position: 'absolute', left: 0, top: 0, ...up(rv(lt, 0.1)) }}><Lbl>Disposal activities</Lbl></div>
      {a.map(([ic, l, w], i) => (
        <Card key={l} style={{ left: 0, top: 40 + i * 140, width: 780, height: 120, padding: '0 28px', display: 'flex', alignItems: 'center', gap: 22, ...up(rv(lt, 0.3 + i * 0.8)) }}>
          <div style={{ width: 64, height: 64, borderRadius: 16, background: tint(35), display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none' }}><Icon n={ic} s={34} c={hc(35)} /></div>
          <div style={{ flex: 1, minWidth: 0, font: `500 23px ${SANS}`, color: CB.text, lineHeight: 1.3, textWrap: 'pretty' }}>{l}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 14px 6px 10px', borderRadius: 20, background: tint(ROLE[w][1]), flex: 'none' }}><Dot col={hc(ROLE[w][1])} size={10} /><div style={{ font: `600 17px ${SANS}`, color: deep(ROLE[w][1]), whiteSpace: 'nowrap' }}>{ROLE[w][0]}</div></div>
        </Card>
      ))}
    </div>
  );
}
function VOos({ lt }) {
  const sw = rv(lt, 1.8, 0.5);
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Note style={{ left: 0, top: 0, width: 780, ...up(rv(lt, 0.1)) }}>First export any StableNet evidence you still need. Leaving Operational deletes the measurement history.</Note>
      <Card style={{ left: 0, top: 150, width: 780, padding: '26px 30px', ...up(rv(lt, 0.8)) }}>
        <Lbl>FNT Command status</Lbl>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginTop: 16 }}>
          <div style={{ opacity: lerp(1, 0.45, sw) }}><Chip k="operational" s={1.15} /></div>
          <Arr w={50} col={sw > 0.5 ? hc(35) : CB.line2} />
          <div style={{ opacity: clampN(sw * 2), transform: `scale(${lerp(0.7, 1, sw)})`, transformOrigin: 'left center' }}><Chip k="oos" s={1.15} /></div>
        </div>
        <div style={{ height: 1, background: CB.line, margin: '24px 0 18px' }}></div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Icon n="pulse" s={28} c={sw > 0.5 ? GREY : OKG} />
          <div style={{ font: `500 17px ${MONO}`, color: CB.dim, letterSpacing: 1, textTransform: 'uppercase' }}>StableNet</div>
          <Dot col={mix(OKG, GREY, sw)} size={11} />
          <div style={{ font: `600 21px ${SANS}`, color: CB.text }}>{sw > 0.5 ? 'No longer monitored' : 'Monitored'}</div>
        </div>
      </Card>
    </div>
  );
}
function VDecomFlow({ lt }) {
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <Card style={{ left: 0, top: 0, width: 780, padding: '24px 30px', display: 'flex', alignItems: 'center', gap: 20, ...up(rv(lt, 0.2)) }}>
        <Chip k="decom" s={1.15} />
        <div style={{ flex: 1, minWidth: 0, font: `500 21px ${SANS}`, color: CB.dim, lineHeight: 1.35 }}>Shut down, cables removed, prepared for disposal or reuse</div>
      </Card>
      <svg width="780" height="420" style={{ position: 'absolute', left: 0, top: 0, opacity: rv(lt, 1.0) }}>
        <path d="M60 104 L60 240 Q60 262 82 262 L110 262 M60 240 L60 352 Q60 374 82 374 L110 374" fill="none" stroke={CB.line2} strokeWidth="3" strokeLinecap="round" />
      </svg>
      {[['lager', 'Kept or moved to stock for internal reuse', 262], ['disposal', 'Moved to the destruction warehouse or sold', 374]].map(([k, d, y], i) => (
        <Card key={k} style={{ left: 120, top: y - 44, width: 660, height: 88, padding: '0 26px', display: 'flex', alignItems: 'center', gap: 20, ...up(rv(lt, 1.2 + i * 0.5)) }}>
          <Chip k={k} s={1.05} />
          <div style={{ flex: 1, minWidth: 0, font: `500 20px ${SANS}`, color: CB.dim, lineHeight: 1.3 }}>{d}</div>
        </Card>
      ))}
    </div>
  );
}

// ---------- 06 sale ----------
const SALE = [['search', 'Evaluate', 'Offer unused hardware for sale. First check internal reuse.'], ['people', 'Coordinate', 'Corporate procurement, NSI CMO and NSI PO'], ['tools', 'Prepare', 'Factory reset. Remove configs, credentials, certificates, labels.'], ['shield', 'Verify', 'No company data may remain on the system'], ['hand', 'Complete', 'Hand over, update inventory and ownership records, keep the documentation']];
function Sale({ T, K }) {
  const t = (T - K.Sa) / SLOW, end = K.Su;
  if (t < -0.1 || T > end + 0.1) return null;
  const o = tw(t, 0, 0.6, M.enter) * (1 - tw(T, end - 0.6, end));
  const h = STAGES[5].h;
  const si = Math.max(0, Math.min(4, Math.floor((t - 1.0) / 3.4)));
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <Header st={5} title="Sale of Hardware" o={tw(t, 0, 0.7, M.enter)} />
      <div style={{ position: 'absolute', left: 140, top: 440, ...up(tw(t, 0.4, 1.0, M.enter), 20) }}>
        <div key={si} style={{ opacity: tw(t - 1.0 - si * 3.4, 0, 0.35, M.enter) }}><Actor T={T} a={{ p: ['clip', 'point', 'laptop', 'clip', 'box'][si] }} x={0} y={0} s={1.1} /></div>
      </div>
      <div style={{ position: 'absolute', left: 140, top: 226, font: `500 24px ${SANS}`, color: CB.dim, ...up(tw(t, 0.3, 0.9, M.enter)) }}>Alternative to disposal</div>
      {SALE.map(([ic, n, d], i) => {
        const a = 1.0 + i * 3.4;
        const p = tw(t, a, a + 0.6, M.pop);
        const act = t >= a && t < a + 3.4;
        return (
          <div key={n} style={{ position: 'absolute', left: 420 + i * 274, top: 300, width: 258, height: 380, boxSizing: 'border-box', borderRadius: 22, padding: '28px 26px', background: '#fff', boxShadow: act ? `0 0 0 3px ${hc(h)}, ${SHADOW}` : SHADOW, opacity: clampN(p * 2) * (act || t > a + 3.4 ? 1 : 0.4), transform: `translateY(${(1 - Math.min(1, p)) * 24}px)` }}>
            <div style={{ width: 80, height: 80, borderRadius: 40, background: act ? hc(h) : tint(h), display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon n={ic} s={40} c={act ? '#fff' : hc(h)} /></div>
            <div style={{ font: `600 17px ${MONO}`, color: hc(h), marginTop: 22 }}>{i + 1}</div>
            <div style={{ font: `600 30px ${SANS}`, color: CB.text, marginTop: 2 }}>{n}</div>
            <div style={{ font: `400 20px ${SANS}`, color: CB.dim, marginTop: 10, lineHeight: 1.4, textWrap: 'pretty' }}>{d}</div>
          </div>
        );
      })}
      <div style={{ position: 'absolute', left: 420, top: 730, display: 'flex', alignItems: 'center', gap: 16, ...up(tw(t, 17.6, 18.2, M.enter)) }}>
        <Lbl>Status for a sale</Lbl>
        <div style={{ width: 10 }}></div>
        <Chip k="oos" s={1.15} /><Arr /><Chip k="decom" s={1.15} /><Arr /><Chip k="disposal" s={1.15} />
        <div style={{ font: `500 19px ${SANS}`, color: CB.dim, marginLeft: 4, maxWidth: 260, lineHeight: 1.25 }}>after handover and documentation</div>
      </div>
    </div>
  );
}

// ---------- summary ----------
const SUM = [['Ordered, delivered, checked, not yet registered', 'none'], ['Registered and held in storage', 'lager'], ['Installation, cabling, setup, hardening, activation', 'planning'], ['Live in production, including planned maintenance', 'operational', 'Operational · monitored'], ['End of production and service deactivation', 'oos'], ['Cabling removed, decision pending (scrap, sale, store)', 'decom'], ['Kept in stock for internal reuse', 'lager'], ['Moved to the destruction warehouse or sold', 'disposal']];
function Summary({ T, K }) {
  const t = (T - K.Su) / SLOW, end = K.Re;
  if (t < -0.1 || T > end + 0.1) return null;
  const o = tw(t, 0, 0.6, M.enter) * (1 - tw(T, end - 0.6, end));
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{ position: 'absolute', left: 360, top: 110, ...up(tw(t, 0, 0.7, M.enter), -12) }}>
        <Lbl>Summary</Lbl>
        <div style={{ font: `600 48px ${SANS}`, color: CB.text, letterSpacing: -1, marginTop: 6 }}>FNT Command status across the lifecycle</div>
      </div>
      <Card style={{ left: 360, top: 250, width: 1200, padding: '10px 30px' }}>
        {SUM.map(([l, k, lab], i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', height: 76, borderBottom: i < SUM.length - 1 ? `1px solid ${CB.line}` : 'none', ...up(tw(t, 0.8 + i * 0.9, 1.2 + i * 0.9, M.enter), 8) }}>
            <div style={{ flex: 1, font: `500 24px ${SANS}`, color: CB.text }}>{l}</div>
            <Chip k={k} s={1.1} label={lab} />
          </div>
        ))}
      </Card>
    </div>
  );
}

// ---------- remember ----------
const TAKE = ['Check existing stock before you buy.', 'Align with cluster lead, CMO and corporate procurement before ordering.', 'Check every delivery within 5 working days, four-eyes principle.', 'Register delivered systems in FNT Command within 10 working days.', 'The device status in FNT Command must always match reality.', 'Use StableNet maintenance mode for planned maintenance, not a status change.', 'Request disposal through ServiceNow (service offering 01-54-58_Default).', 'Before a sale, make sure no company data remains on the system.'];
const CONT = [['NSI CMO', 'Orders, commercial inventory'], ['Corporate procurement', 'GM-OS, CP Sourcing Activities – Category'], ['Security centre', 'Delivery announcements'], ['SL-Datacenter (storage, DCBI)', 'Storage, disposal'], ['Command team', 'Bulk registration'], ['Mail services', 'Shipping'], ['NSI PO', 'Process coordination']];
function Remember({ T, K, end }) {
  const t = (T - K.Re) / SLOW;
  if (t < -0.1) return null;
  const o = tw(t, 0, 0.6, M.enter) * (1 - tw(T, end - 0.7, end - 0.05));
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{ position: 'absolute', left: 140, top: 110, font: `600 64px ${SANS}`, color: CB.text, letterSpacing: -2, ...up(tw(t, 0, 0.7, M.enter), -12) }}>Remember</div>
      <div style={{ position: 'absolute', left: 140, top: 230, width: 940, display: 'flex', flexDirection: 'column', gap: 12 }}>
        {TAKE.map((l, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 18, ...up(tw(t, 0.6 + i * 0.9, 1.0 + i * 0.9, M.enter), 8) }}>
            <Check size={36} />
            <div style={{ font: `500 25px ${SANS}`, color: CB.text, lineHeight: 1.3 }}>{l}</div>
          </div>
        ))}
      </div>
      <Card style={{ left: 1160, top: 210, width: 620, padding: '26px 32px', ...up(tw(t, 9.0, 9.6, M.enter)) }}>
        <Lbl>Who to contact</Lbl>
        {CONT.map(([r, d], i) => (
          <div key={r} style={{ display: 'flex', flexDirection: 'column', gap: 2, padding: '12px 0', borderBottom: i < CONT.length - 1 ? `1px solid ${CB.line}` : 'none', ...up(tw(t, 9.4 + i * 0.25, 9.8 + i * 0.25, M.enter), 6) }}>
            <div style={{ font: `600 22px ${SANS}`, color: CB.text }}>{r}</div>
            <div style={{ font: `400 19px ${SANS}`, color: CB.dim }}>{d}</div>
          </div>
        ))}
      </Card>
    </div>
  );
}

// ---------- piece ----------
const LIN0 = (x) => x;
const PROC = [
  { p: 'laptop', t: 'Create a BoM', s: 'In alignment with the cell and the vendor: devices, models, add-ons and quantities.' },
  { p: 'laptop', t: 'Check existing stock', s: 'Check the company warehouses in FNT Command. If the devices are in stock, use them: no further steps.' },
  { p: 'point', t: 'Align on budget and next steps', s: 'With the cluster lead, the CMO and corporate procurement.' },
  { p: 'phone', t: 'Request offers from resellers', s: 'Procurement and the CMO in copy. Choose the most economical offer.' },
  { p: 'mail', t: 'Start the procurement process', s: 'By mail to the CMO, corporate procurement in copy.' },
];
const DELIV = [
  { p: 'box', t: 'Receive the hardware', s: 'One or more NSI employees, depending on size and volume.' },
  { p: 'phone', t: 'Announce larger deliveries', s: 'Pallets arrive at the delivery area on the backside of the data centre. Announce them to the security centre.' },
  { p: 'clip', t: 'Check the delivery', s: 'Delivery note against serial number, model and manufacturer on the hardware.' },
  { p: 'phone', t: 'Report problems', s: 'Incomplete, wrong or defective: align with the vendor.' },
  { p: 'box', t: 'Store the hardware', s: 'In an NSI storage room registered in FNT Command.' },
];
const COMM = [
  { w: 'po', p: 'sign', t: 'Invoice approval', s: 'The NSI PO approves the invoice, then the CMO performs the commercial inventory.' },
  { w: 'po', p: 'point', t: 'Invoice held on problems', s: 'Incomplete, wrong or defective deliveries are not released.' },
  { p: 'box', t: 'Ship via mail service', s: 'For wrong deliveries or RMA, hand the parcel to the company mail service.' },
  { p: 'clip', t: 'Shipping form', s: 'Fill it in before handing over. A shipping checklist is available.' },
];
const INV = [
  { p: 'point', t: 'Register within 10 working days', s: 'By the NSI person who initiated the order. Until it is registered, the status is None.' },
  { p: 'laptop', t: 'Open Inventory Management', s: 'Locate the storage room or depot.' },
  { p: 'mail', t: 'Bulk registration', s: 'Fill in the Excel import template and mail it to the Command team.' },
  { p: 'laptop', t: 'Manual registration', s: 'Register single devices directly in the FNT Command GUI.' },
  { p: 'laptop', t: 'Set the status', s: 'Lager / Warehouse while in stock, Planning once at the installation location.' },
];
const DEC = [
  { p: 'laptop', t: 'Set Out of service first', s: 'Export StableNet evidence, then set the status. StableNet stops monitoring the device.' },
  { w: 'req', p: 'laptop', t: 'Open the DCBI request', s: 'ServiceNow Employee Center, DCBI "De-Commission Hardware".' },
  { w: 'req', p: 'laptop', t: 'Select the service offering', s: 'Use 01-54-58_Default.' },
  { w: 'req', p: 'laptop', t: 'Enter the hardware details', s: 'Type, serial number and location. Submit the request.' },
  { p: 'laptop', t: 'Cleanup and disposal', s: 'NSI engineer cleans up FNT Command, SL-Datacenter disposes of the drives, the requester signs.' },
  { p: 'laptop', t: 'Set the final status', s: 'Decommissioned, then Lager / Warehouse or Disposal.' },
];
const SLOW = 1.3;
const SD = { pr: 6.0, dl: 6.2, co: 5.2, in: 5.7, de: 6.2 };

const VD = [18,33.5,33,22.6,30.5,45,39.5,28.5,21,28.5];
const KV = (() => { const n = ['It', 'Pr', 'Dl', 'Co', 'In', 'Se', 'De', 'Sa', 'Su', 'Re'], o = {}; let a = 0; n.forEach((k, i) => { o[k] = a; a += VD[i]; }); o.end = a; return o; })();
const AUDIO_B = [0.05,4.47,12.83,19.03,28.13,34.31,40.09,48.85,55.99,60.27,67.17,72.93,79.99,85.03,90.85,95.81,101.15,106.69,111.69,119.45,123.83,131.41,135.85,142.15,147.57,154.77,161.49,169.65,176.13,182.55,185.65,192.97,198.35,203.57,207.71,218.75,223.63,231.63,235.49,241.35,245.19,250.83,255.57,262.09,267.11];
const AUDIO_HOLD = [255.4, 6];
const AUDIO_END = 286;
const tlOf = (b) => (b >= AUDIO_HOLD[0] ? b + AUDIO_HOLD[1] : b);
const audioPos = (t) => (t < AUDIO_HOLD[0] ? [t, false] : t < AUDIO_HOLD[0] + AUDIO_HOLD[1] ? [AUDIO_HOLD[0], true] : [t - AUDIO_HOLD[1], false]);
function AudioTrack({ src, on }) {
  const { T, playing } = useComposition();
  const ref = React.useRef(null);
  React.useEffect(() => {
    const a = ref.current;
    if (!a) return;
    a.muted = !on;
    const [p, hold] = audioPos(T);
    if (playing && !hold && p < a.duration - 0.05) {
      if (Math.abs(a.currentTime - p) > 0.3) a.currentTime = p;
      if (a.paused) a.play().catch(() => {});
    } else {
      if (!a.paused) a.pause();
      if (Math.abs(a.currentTime - p) > 0.05) a.currentTime = p;
    }
  });
  return <audio ref={ref} src={src} preload="auto"></audio>;
}
function Piece({ tweaks }) {
  const { T: TA } = useComposition();
  C = CB;
  const K = KV;
  const end = KV.end;
  const st = (K0, sd, i) => K0 + 1.0 + i * sd + 0.3;
  const capSteps = (K0, sd, lines) => lines.map((text, i) => ({ at: st(K0, sd, i), text }));
  const caps = [
    { at: K.It + 0.65, text: 'Every piece of network hardware at NSI goes through a controlled lifecycle.' },
    { at: K.It + 6.5, text: 'It is procured, delivered, stored, registered, put into operation, and finally decommissioned, disposed of or sold.' },
    { at: K.It + 13, text: 'The FNT Command status must match each stage. The NSI PO coordinates the process.' },
    ...capSteps(K.Pr, SD.pr, [
      'First, create a bill of materials with the cell and the vendor: the devices, models, add-ons and quantities needed.',
      'Check whether the devices are already in stock. If they are, use them: no procurement is needed.',
      'Align on budget and next steps with the cluster lead, the CMO and corporate procurement.',
      'Request offers from resellers, with procurement and the CMO in copy, and choose the most economical one.',
      'Start the procurement process by mail to the CMO, with corporate procurement in copy.',
    ]),
    { at: K.Dl - 2.4, text: 'Once the hardware is ordered, the next step is delivery.' },
    ...capSteps(K.Dl, SD.dl, [
      'Delivered hardware is received by one or more NSI employees, depending on size and volume.',
      'Larger deliveries, such as pallets, arrive behind the data centre and must be announced to the security centre.',
      'Two people check the delivery note against the hardware within five working days.',
      'If a delivery is incomplete, wrong or defective, align with the manufacturer or reseller.',
      'Store the hardware in an NSI storage room. Until it is registered, the status is None.',
    ]),
    ...capSteps(K.Co, SD.co, [
      'After the NSI PO approves the invoice, the CMO performs the commercial inventory.',
      'If anything is incomplete, wrong or defective, the NSI PO does not release the invoice.',
      'To send hardware back, for example a wrong delivery or RMA, use the company mail service.',
      'Fill in the shipping form in advance. A shipping checklist is available.',
    ]),
    ...capSteps(K.In, SD.in, [
      'Within ten working days of delivery, the person who ordered the systems registers them in FNT Command.',
      'Open Inventory Management and locate the storage room.',
      'For multiple devices, fill in the Excel import template and send it to the Command team.',
      'Single devices can be registered directly in the FNT Command GUI.',
      'In stock, even when reserved, the status is Lager / Warehouse. At the installation location, it becomes Planning.',
    ]),
    { at: K.Se + 1.56, text: 'Installation is Planning: record creation in Command, transport, racking and cabling.' },
    { at: K.Se + 8.71, text: 'Activation is Planning too: OS and firmware, hardening, monitoring onboarding and the activation checklist.' },
    { at: K.Se + 16.51, text: 'When the device goes live it becomes Operational, and StableNet starts monitoring it automatically.' },
    { at: K.Se + 23.01, text: 'Before maintenance, set the device to Maintenance in StableNet. In FNT Command it stays Operational.' },
    { at: K.Se + 26.52, text: 'Do not change the status in FNT Command: StableNet would delete the device and all of its history.' },
    { at: K.Se + 32.76, text: 'At end of production, after the deactivation checklist, the device is Out of service and no longer monitored.' },
    { at: K.Se + 37.96, text: 'Only Operational devices stay monitored in StableNet.' },
    ...capSteps(K.De, SD.de, [
      'First export any StableNet evidence, then set the device to Out of service. StableNet stops monitoring it.',
      'Then open the DCBI hardware decommissioning request in the ServiceNow Employee Center.',
      'Select the service offering 01-54-58_Default.',
      'Enter type, serial number and location, and submit the request.',
      'The NSI engineer cleans up FNT Command. SL-Datacenter disposes of the hard drives per company policy, and the requester signs the disposal order.',
      'Finally set Decommissioned, then Lager / Warehouse for reuse or Disposal.',
    ]),
    { at: K.Sa + 1.56, text: 'As an alternative to disposal, unused hardware can be sold. First check whether it can be reused internally.' },
    { at: K.Sa + 5.98, text: 'Align with corporate procurement, the CMO and the NSI PO.' },
    { at: K.Sa + 10.4, text: 'Factory reset the device and remove configurations, credentials, certificates and internal labels.' },
    { at: K.Sa + 14.82, text: 'NSI must make sure no company data remains on the system.' },
    { at: K.Sa + 19.24, text: 'Then hand it over, update inventory and ownership records, and set the status to Disposal.' },
    { at: K.Su + 0.65, text: 'Across the lifecycle, the FNT Command status must always match reality.' },
    { at: K.Re + 0.65, text: 'Check stock first. Check deliveries within five working days, and register them within ten.' },
    { at: K.Re + 8.45, text: 'Use maintenance mode, not a status change, and request disposal through ServiceNow.' },
    { at: K.Re + 15.6, until: end - 0.5, text: 'For each step, the responsible role is listed here.' },
  ];
  const PW = [[0, 0], ...caps.map((c, i) => [tlOf(AUDIO_B[i]), c.at]), [AUDIO_END, end]];
  const warp = (a) => { for (let i = 0; i < PW.length - 1; i++) { const [a0, v0] = PW[i], [a1, v1] = PW[i + 1]; if (a <= a1) return v0 + (v1 - v0) * (a - a0) / Math.max(1e-6, a1 - a0); } return end; };
  const T = warp(TA);
  const capsA = caps.map((c, i) => ({ text: c.text, at: tlOf(AUDIO_B[i]), until: i < caps.length - 1 ? tlOf(AUDIO_B[i + 1]) - 0.15 : AUDIO_END - 1.0 }));
  const keys = [[K.Pr, 'none'], [st(K.In, SD.in, 4) + 0.9, 'lager'], [st(K.In, SD.in, 4) + 2.3, 'planning'], [K.Se + 16.25, 'operational'], [K.Se + 32.5, 'oos'], [st(K.De, SD.de, 5) + 0.4, 'decom'], [K.Sa, 'oos'], [K.Sa + 22.88, 'decom'], [K.Sa + 24.18, 'disposal']];
  const hueAt = [[K.It, 285], [K.Pr, 285], [K.Dl, 255], [K.In, 225], [K.Se, 160], [K.De, 35], [K.Sa, 75], [K.Su, 255]];
  const gh = nh(kf(T, hueAt.map(([a, h]) => [a + 0.5, h]))[0]);
  const fade = 1 - tw(T, end - 0.7, end - 0.05);
  const SS = (p) => <StepScene T={T} {...p} />;
  return (
    <div data-screen-label={`t=${Math.floor(T)}s`} style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: CB.bg }}>
      <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(ellipse 65% 60% at 50% 50%, oklch(0.94 0.04 ${gh.toFixed(1)}), transparent 75%)` }}></div>
      <div style={{ position: 'absolute', inset: -40, backgroundImage: 'radial-gradient(circle, #DDD8CD 1.4px, transparent 1.8px)', backgroundSize: '40px 40px', transform: `translate(${(T * 3) % 40}px, ${(T * 1.5) % 40}px)` }}></div>
      <div style={{ position: 'absolute', inset: 0, opacity: fade }}>
        <Intro T={T} K={K} />
        {SS({ at: K.Pr, end: K.Dl, st: 0, title: 'Procurement of New Hardware', steps: PROC, sd: SD.pr, visual: (i, lt) => [<VBom lt={lt} />, <VStock lt={lt} />, <VAlign lt={lt} />, <VOffers lt={lt} />, <VMail lt={lt} />][i] })}
        {SS({ at: K.Dl, end: K.Co, st: 1, title: 'Delivery and Storage', steps: DELIV, sd: SD.dl, visual: (i, lt) => [<VTruck lt={lt} />, <VAnnounce lt={lt} />, <VCheck lt={lt} />, <VProblem lt={lt} />, <VStore lt={lt} />][i] })}
        {SS({ at: K.Co, end: K.In, st: 1, title: 'Commercial Inventory and Shipping', steps: COMM, sd: SD.co, visual: (i, lt) => [<VInvoice lt={lt} />, <VBlocked lt={lt} />, <VShip lt={lt} />, <VShipForm lt={lt} />][i] })}
        {SS({ at: K.In, end: K.Se, st: 2, title: 'Inventory in FNT Command', steps: INV, sd: SD.in, visual: (i, lt) => [<VDeadline lt={lt} />, <VWhView lt={lt} />, <VBulk lt={lt} />, <VManual lt={lt} />, <VStatusSet lt={lt} />][i] })}
        <Setup T={T} K={K} />
        {SS({ at: K.De, end: K.Sa, st: 4, title: 'Decommissioning and Disposal', steps: DEC, sd: SD.de, visual: (i, lt) => (i === 0 ? <VOos lt={lt} /> : i < 4 ? <VSnow i={i - 1} lt={lt} /> : i === 4 ? <VDcbi lt={lt} /> : <VDecomFlow lt={lt} />) })}
        <Sale T={T} K={K} />
        <Summary T={T} K={K} />
        <Remember T={T} K={K} end={end} />
        <Tracker T={T} K={K} />
        <StatusWidget T={T} K={K} keys={keys} />
      </div>
      <AudioTrack src="nsi-voiceover.mp3" on={tweaks.voiceover !== false} />
      {tweaks.captions !== false && (
        <Captions items={capsA} style={{ left: '50%', right: 'auto', bottom: 36, transform: 'translateX(-50%)', width: 'max-content', maxWidth: 1560, padding: '14px 30px', borderRadius: 14, background: 'rgba(24,33,58,0.94)', font: `500 32px ${SANS}`, color: '#F4F2EE', textShadow: 'none', lineHeight: 1.3, textAlign: 'center' }} />
      )}
    </div>
  );
}

function NSIVideo() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <>
      <CompositionStage width={1920} height={1080} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#F4F2EE">
        <Piece tweaks={t} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Playback" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        <TweakToggle label="Captions" value={t.captions} onChange={(v) => setTweak('captions', v)} />
        <TweakToggle label="Voiceover" value={t.voiceover !== false} onChange={(v) => setTweak('voiceover', v)} />
      </TweaksPanel>
    </>
  );
}
window.NSIVideo = NSIVideo;

# Infosim StableNet — monitoring the Command inventory (voiceover script, v1)

Total runtime: 75 s · 16:9 · sequel to the FNT Command video (same building, rack and device). Timecodes are when each line starts.

- 0:00.4 — FNT Command knows where every device is and what it is. It doesn't tell you whether it's working.
- 0:05.0 — Without monitoring, users report outages first, and new devices are added to monitoring by hand.
- 0:09.5 — Infosim StableNet monitors the network, using the inventory already documented in FNT Command.
- 0:16.3 — On a schedule, StableNet imports devices from a Command database view.
- 0:21.0 — Hostname, management IP, location and CORIA-ID come across, so nothing is entered twice.
- 0:26.3 — StableNet pings each management IP to check that the device is reachable.
- 0:30.0 — Every reply is recorded, building an availability history.
- 0:33.8 — Over SNMP it polls interface traffic and status, CPU and memory.
- 0:38.5 — Each value is stored as a measurement, with thresholds that raise warnings.
- 0:43.3 — Dashboards and topology maps show the status of every site at a glance.
- 0:50.3 — When RTR-1101 stops answering ping, StableNet raises a critical alarm.
- 0:54.2 — Devices behind it are marked unreachable, so the alarm points at the root cause.
- 0:58.3 — Because the data comes from Command, the alarm already carries the exact location.
- 1:03.0 — The engineer goes straight to rack R04, unit 39, and the cable on patch port 12.
- 1:08.4 — FNT Command documents where it is and what it is. StableNet shows whether it's working.

Placeholders to confirm: import interval (shown as "Scheduled import · via database view"), poll interval "5 min", 80 % CPU warning threshold, metric values, alarm time "14:32:10 · 3 missed polls", topology (RTR-2101 → RTR-1101 → FW-1102 → SW-1103 → SRV-1204/1205), StableNet mark (drawn placeholder, not the official logo).

# FNT Command — why, Navigator & Object Management (voiceover script, v6)

Total runtime: 73 s · 16:9 · captions match this script word for word. Timecodes are when each line starts.

- 0:00.4 — Without one system, network documentation ends up scattered across spreadsheets, old diagrams and people's memory.
- 0:06.0 — Finding a device or tracing a cable takes hours, and mistakes cause outages.
- 0:11.6 — FNT Command brings it all together in one model.
- 0:15.2 — The Navigator is for exploring locations. Object Management is for managing object properties. And there are many more modules.
- 0:20.4 — In the Navigator, every asset starts with a location.
- 0:23.6 — Cities are coded by region, country and city: WEU/DE/FFM is Frankfurt.
- 0:28.9 — Within a city, each site is a building, named by its street address.
- 0:33.8 — Each building is divided into floors…
- 0:37.8 — …and each floor into rooms.
- 0:42.3 — Racks sit inside rooms, and every device has a fixed position in its rack.
- 0:49.3 — In Object Management, each object carries its own properties: serial number, management IP, CORIA-ID and many more.
- 0:55.4 — They cover everything from network details to lifecycle and ownership.
- 0:59.8 — Cables run from device ports through patch panels, so every connection can be traced end to end.
- 1:06.9 — City, building, floor, room, rack: every asset has a precise address and documented properties.

Pronunciation: read city codes letter by letter ("W-E-U, D-E, F-F-M") or as "Western Europe, Germany, Frankfurt" — keep it consistent.

Placeholder data to replace: Mainzer Landstrasse 151, room 2.14, R04/R05, RTR-1101 and its property values (serial, IP, hostname, asset tag, contract, cost centre).
Map: Natural Earth 110m (public domain).

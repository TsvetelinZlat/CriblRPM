const { Easing, useComposition, CompositionStage, Captions } = window;

// ---- motion helpers (the only easings used) ----
const M = { enter: Easing.easeOutCubic, move: Easing.easeInOutCubic, pop: Easing.easeOutBack };
const tw = (T, a, b, e = M.move) => (T <= a ? 0 : T >= b ? 1 : e((T - a) / (b - a)));
const lerp = (a, b, p) => a + (b - a) * p;
const clampN = (v) => Math.max(0, Math.min(1, v));
const mix = (a, b, p) => `color-mix(in oklch, ${b} ${Math.round(clampN(p) * 100)}%, ${a})`;

const SANS = "'IBM Plex Sans', system-ui, sans-serif";
const MONO = "'IBM Plex Mono', ui-monospace, monospace";
let C = {};
const palette = (h) => ({
  bg: '#0C0F13', panel: '#151A21', panel2: '#1C222B', line: '#262D37', line2: '#3A4552',
  text: '#ECEAE5', dim: '#9AA1AB', faint: '#5A626D',
  acc: `oklch(0.80 0.13 ${h})`, accSoft: `oklch(0.80 0.13 ${h} / 0.14)`,
});

// ---- zoom-through: outgoing level scales into its focus, incoming grows out of it ----
const ZD = 1.3;
const HIDDEN = { display: 'none' };
function zoomXf(T, inAt, inF, Z1, outAt, outF, Z2) {
  if (inAt != null) {
    if (T < inAt) return HIDDEN;
    if (T < inAt + ZD) {
      const p = tw(T, inAt, inAt + ZD);
      return { transform: `translate(${(inF[0] - 960) * (1 - p)}px, ${(inF[1] - 540) * (1 - p)}px) scale(${Math.pow(Z1, p - 1)})`, transformOrigin: '960px 540px', opacity: tw(T, inAt + 0.15 * ZD, inAt + 0.55 * ZD, M.enter) };
    }
  }
  if (outAt != null && T >= outAt) {
    if (T > outAt + ZD) return HIDDEN;
    const p = tw(T, outAt, outAt + ZD);
    return { transform: `translate(${(960 - outF[0]) * p}px, ${(540 - outF[1]) * p}px) scale(${Math.pow(Z2, p)})`, transformOrigin: `${outF[0]}px ${outF[1]}px`, opacity: 1 - tw(T, outAt + 0.4 * ZD, outAt + 0.8 * ZD) };
  }
  return { opacity: 1 };
}
const Layer = ({ xf, children }) => (xf.display === 'none' ? null : <div style={{ position: 'absolute', inset: 0, ...xf }}>{children}</div>);
const sel = (T, at) => tw(T, at, at + 0.45, M.enter);
const ring = (T, at) => (T > at ? ((T - at) % 1.1) / 1.1 : -1);

// ---- 1. Locations ----
const CITIES = [
  { x: 380, y: 600, code: ['AME', 'US', 'NY'], name: 'New York' },
  { x: 860, y: 430, code: ['WEU', 'DE', 'FFM'], name: 'Frankfurt', key: 1 },
  { x: 1240, y: 520, code: ['EEU', 'BG', 'SOF'], name: 'Sofia' },
  { x: 1580, y: 640, code: ['ASI', 'JP', 'TOK'], name: 'Tokyo' },
];
const LINKS = [[0, 1], [1, 2], [2, 3], [1, 3], [0, 3]];
const CW = 20.4; // Plex Mono 34px advance
function Locations({ T, K }) {
  const xf = zoomXf(T, null, null, 1, K.B - 0.3, [860, 430], 6);
  const dec = (i) => tw(T, 2.7 + i * 0.35, 3.1 + i * 0.35, M.enter);
  const s = sel(T, 4.5);
  const rp = ring(T, 4.5);
  return (
    <Layer xf={xf}>
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0 }}>
        {LINKS.map(([a, b], k) => {
          const A = CITIES[a], B = CITIES[b];
          const mx = (A.x + B.x) / 2, my = Math.min(A.y, B.y) - 120 - Math.abs(A.x - B.x) * 0.12;
          return <path key={k} d={`M${A.x} ${A.y} Q${mx} ${my} ${B.x} ${B.y}`} fill="none" stroke={C.line2} strokeWidth="1.6" strokeDasharray="1 1" pathLength="1" strokeDashoffset={1 - tw(T, 1.2 + k * 0.15, 2.2 + k * 0.15, M.move)} />;
        })}
        {CITIES.map((c, i) => {
          const sc = tw(T, 0.3 + i * 0.25, 0.8 + i * 0.25, M.pop);
          const on = c.key ? s : 0;
          return (
            <g key={i} transform={`translate(${c.x} ${c.y}) scale(${Math.max(0, sc)})`}>
              {c.key && rp >= 0 && <circle r={18 + rp * 44} fill="none" stroke={C.acc} strokeWidth="2" opacity={1 - rp} />}
              <circle r="26" fill="none" stroke={C.acc} strokeOpacity={0.25 + 0.5 * on} />
              <circle r="11" fill={C.acc} />
            </g>
          );
        })}
      </svg>
      {CITIES.map((c, i) => {
        const o = tw(T, 0.6 + i * 0.25, 1.0 + i * 0.25, M.enter);
        return (
          <div key={i} style={{ position: 'absolute', left: c.x + 46, top: c.y - 26, opacity: o, transform: `translateX(${(1 - o) * -10}px)` }}>
            <div style={{ display: 'flex', font: `500 34px ${MONO}`, color: C.text, whiteSpace: 'pre' }}>
              {c.code.map((seg, k) => (
                <span key={k} style={{ color: c.key ? mix(C.text, C.acc, dec(k)) : C.text }}>{(k ? '/' : '') + seg}</span>
              ))}
            </div>
            <div style={{ font: `400 22px ${SANS}`, color: C.dim, marginTop: 4, opacity: c.key ? 1 - dec(0) : 1 }}>{c.name}</div>
            {c.key && ['Region', 'Country', 'City'].map((l, k) => {
              const start = [0, 4, 7][k] * CW, w = c.code[k].length * CW;
              return (
                <div key={l} style={{ position: 'absolute', left: start, top: 50, width: w, opacity: dec(k), transform: `translateY(${(1 - dec(k)) * 8}px)` }}>
                  <div style={{ height: 8, borderLeft: `2px solid ${C.acc}`, borderRight: `2px solid ${C.acc}`, borderBottom: `2px solid ${C.acc}`, boxSizing: 'border-box' }}></div>
                  <div style={{ position: 'absolute', left: '50%', top: 16, transform: 'translateX(-50%)', font: `500 19px ${SANS}`, color: C.acc, whiteSpace: 'nowrap' }}>{l}</div>
                </div>
              );
            })}
          </div>
        );
      })}
    </Layer>
  );
}

// ---- 2. Buildings in the city ----
const BLDG = [
  { x: 360, w: 260, h: 300, n: 'Musterstraße 8', f: 3 },
  { x: 810, w: 300, h: 460, n: 'Musterstraße 12', f: 4, key: 1 },
  { x: 1300, w: 240, h: 240, n: 'Musterstraße 20', f: 2 },
];
const GROUND = 780;
function Buildings({ T, K }) {
  const xf = zoomXf(T, K.B - 0.3, [860, 430], 6, K.Fl - 0.3, [960, 550], 2.6);
  const s = sel(T, K.Fl - 1.5);
  const rp = ring(T, K.Fl - 1.5);
  return (
    <Layer xf={xf}>
      <div style={{ position: 'absolute', left: 200, top: GROUND, width: 1520 * tw(T, K.B + 0.3, K.B + 1.1), height: 2, background: C.line2 }}></div>
      {BLDG.map((b, i) => {
        const rise = tw(T, K.B + 0.6 + i * 0.2, K.B + 1.3 + i * 0.2, M.pop);
        const on = b.key ? s : 0;
        const lo = tw(T, K.B + 1.0 + i * 0.2, K.B + 1.4 + i * 0.2, M.enter);
        return (
          <div key={i}>
            <div style={{ position: 'absolute', left: b.x, top: GROUND - b.h, width: b.w, height: b.h, transform: `scaleY(${Math.max(0, rise)})`, transformOrigin: 'bottom', background: on ? mix(C.panel, C.accSoft, on) : C.panel, border: `2px solid ${mix(C.line2, C.acc, on)}`, borderBottom: 'none', boxSizing: 'border-box', borderRadius: '4px 4px 0 0' }}>
              {Array.from({ length: b.f - 1 }).map((_, k) => <div key={k} style={{ position: 'absolute', left: 0, right: 0, top: ((k + 1) * b.h) / b.f, height: 1, background: mix(C.line2, C.acc, on * 0.6) }}></div>)}
              {Array.from({ length: b.f }).map((_, k) => (
                <div key={k} style={{ position: 'absolute', left: 22, right: 22, top: (k * b.h) / b.f + b.h / b.f / 2 - 8, display: 'flex', justifyContent: 'space-between' }}>
                  {Array.from({ length: Math.floor(b.w / 60) }).map((_, j) => <div key={j} style={{ width: 22, height: 16, borderRadius: 2, background: mix(C.line, C.acc, on * 0.5) }}></div>)}
                </div>
              ))}
            </div>
            {b.key && rp >= 0 && <div style={{ position: 'absolute', left: b.x - 10 - rp * 30, top: GROUND - b.h - 10 - rp * 30, width: b.w + 20 + rp * 60, height: b.h + 10 + rp * 30, border: `2px solid ${C.acc}`, borderBottom: 'none', borderRadius: 8, opacity: 1 - rp, boxSizing: 'border-box' }}></div>}
            <div style={{ position: 'absolute', left: b.x, width: b.w, top: GROUND + 18, textAlign: 'center', font: `500 24px ${MONO}`, color: on > 0.5 ? C.acc : C.text, opacity: lo, whiteSpace: 'nowrap' }}>{b.n}</div>
          </div>
        );
      })}
    </Layer>
  );
}

// ---- 3. Floors ----
const FLOORS = [['Floor 3', 'Offices'], ['Floor 2', 'Technical rooms', 1], ['Floor 1', 'Offices'], ['Floor 0', 'Reception · loading bay']];
function Floors({ T, K }) {
  const xf = zoomXf(T, K.Fl - 0.3, [960, 550], 2.6, K.Ro - 0.3, [960, 452], 3);
  const s = sel(T, K.Ro - 1.5);
  const rp = ring(T, K.Ro - 1.5);
  return (
    <Layer xf={xf}>
      {FLOORS.map(([n, u, key], i) => {
        const top = 190 + i * 175;
        const ii = 3 - i;
        const o = tw(T, K.Fl + 0.5 + ii * 0.2, K.Fl + 1.0 + ii * 0.2, M.enter);
        const on = key ? s : 0;
        return (
          <div key={n} style={{ position: 'absolute', left: 560, top, width: 800, height: 175, opacity: o, transform: `translateY(${(1 - o) * 30}px)`, background: on ? mix(C.panel, C.accSoft, on) : C.panel, border: `2px solid ${mix(C.line2, C.acc, on)}`, marginTop: -2 * i, boxSizing: 'border-box', zIndex: key ? 2 : 1 }}>
            <div style={{ position: 'absolute', left: 36, top: 62, font: `500 36px ${MONO}`, color: on > 0.5 ? C.acc : C.text }}>{n}</div>
            <div style={{ position: 'absolute', right: 36, top: 68, font: `400 26px ${SANS}`, color: on > 0.5 ? C.text : C.dim }}>{u}</div>
            {key && rp >= 0 && <div style={{ position: 'absolute', inset: -6 - rp * 24, border: `2px solid ${C.acc}`, borderRadius: 6, opacity: 1 - rp }}></div>}
          </div>
        );
      })}
    </Layer>
  );
}

// ---- 4. Floor plan ----
const ROOMS = [
  [360, 230, 320, 280, '2.10', 'Office'], [680, 230, 320, 280, '2.11', 'Office'], [1000, 230, 560, 280, '2.12', 'Meeting'],
  [360, 590, 400, 280, '2.13', 'Storage'], [760, 590, 440, 280, '2.14', 'Server room', 1], [1200, 590, 360, 280, '2.15', 'UPS / power'],
];
function FloorPlan({ T, K }) {
  const xf = zoomXf(T, K.Ro - 0.3, [960, 452], 3, K.Ra - 0.3, [980, 730], 2.7);
  const s = sel(T, K.Ra - 1.5);
  const rp = ring(T, K.Ra - 1.5);
  const co = tw(T, K.Ro + 0.5, K.Ro + 1.0, M.enter);
  return (
    <Layer xf={xf}>
      <div style={{ position: 'absolute', left: 360, top: 510, width: 1200, height: 80, opacity: co, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `400 20px ${MONO}`, color: C.faint, letterSpacing: 4, textTransform: 'uppercase' }}>Corridor</div>
      {ROOMS.map(([x, y, w, h, n, u, key], i) => {
        const o = tw(T, K.Ro + 0.4 + i * 0.12, K.Ro + 0.9 + i * 0.12, M.enter);
        const on = key ? s : 0;
        return (
          <div key={n} style={{ position: 'absolute', left: x, top: y, width: w, height: h, opacity: o, transform: `scale(${lerp(0.96, 1, o)})`, background: on ? mix(C.panel, C.accSoft, on) : C.panel, border: `2px solid ${mix(C.line2, C.acc, on)}`, boxSizing: 'border-box', marginLeft: -1, zIndex: key ? 2 : 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            <div style={{ font: `500 36px ${MONO}`, color: on > 0.5 ? C.acc : C.text }}>{n}</div>
            <div style={{ font: `400 22px ${SANS}`, color: C.dim }}>{u}</div>
            {key && rp >= 0 && <div style={{ position: 'absolute', inset: -6 - rp * 24, border: `2px solid ${C.acc}`, borderRadius: 6, opacity: 1 - rp }}></div>}
          </div>
        );
      })}
    </Layer>
  );
}

// ---- 5. Room (rack row, top-down) ----
function Room({ T, K }) {
  const xf = zoomXf(T, K.Ra - 0.3, [980, 730], 2.7, K.Ra + 2.2, [905, 500], 4.2);
  const s = sel(T, K.Ra + 1.2);
  const rp = ring(T, K.Ra + 1.2);
  const wo = tw(T, K.Ra + 0.3, K.Ra + 0.8, M.enter);
  return (
    <Layer xf={xf}>
      <div style={{ position: 'absolute', left: 360, top: 230, width: 1200, height: 640, border: `2px solid ${C.line2}`, boxSizing: 'border-box', opacity: wo, borderRadius: 4 }}></div>
      <div style={{ position: 'absolute', left: 460, top: 600, width: 1030, height: 70, opacity: wo, background: 'repeating-linear-gradient(135deg, transparent 0 14px, #161C23 14px 16px)', display: 'flex', alignItems: 'center', justifyContent: 'center', font: `400 20px ${MONO}`, color: C.faint, letterSpacing: 4, textTransform: 'uppercase' }}>Cold aisle</div>
      {Array.from({ length: 8 }).map((_, i) => {
        const o = tw(T, K.Ra + 0.4 + i * 0.08, K.Ra + 0.8 + i * 0.08, M.enter);
        const on = i === 3 ? s : 0;
        return (
          <div key={i} style={{ position: 'absolute', left: 460 + i * 130, top: 440, width: 110, height: 120, opacity: o, transform: `translateY(${(1 - o) * -16}px)`, background: on ? mix(C.panel2, C.accSoft, on) : C.panel2, border: `2px solid ${mix(C.line2, C.acc, on)}`, borderRadius: 4, boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center', font: `500 24px ${MONO}`, color: on > 0.5 ? C.acc : C.text }}>
            {'R0' + (i + 1)}
            {i === 3 && rp >= 0 && <div style={{ position: 'absolute', inset: -6 - rp * 22, border: `2px solid ${C.acc}`, borderRadius: 6, opacity: 1 - rp }}></div>}
          </div>
        );
      })}
    </Layer>
  );
}

// ---- 6. Rack elevation + cabling ----
const OX = 690, OY = 160;
const RACKS = [
  { x: 120, name: 'R04', slots: [[0, 1, 'FFM-PP-03', 'pp'], [2, 2, 'FFM-CORE-01', 'rtr', 1], [5, 2, 'FFM-FW-02', 'dev'], [7, 1, 'FFM-SW-11', 'sw'], [9, 1, 'FFM-SRV-31', 'dev'], [10, 1, 'FFM-SRV-32', 'dev'], [12, 2, 'FFM-UPS-01', 'dev']] },
  { x: 560, name: 'R05', slots: [[0, 1, 'FFM-PP-07', 'pp'], [2, 2, 'FFM-CORE-02', 'rtr'], [5, 1, 'FFM-SW-12', 'sw'], [7, 2, 'FFM-STO-01', 'dev'], [10, 1, 'FFM-SRV-40', 'dev']] },
];
const CABLE = 'M147 206 C147 168 265 168 265 130 C265 34 705 34 705 130 C705 168 587 168 587 206';
const TRACE = [
  ['FFM-CORE-01 · Gi0/1', 'Router · R04 / U3', 0.02],
  ['FFM-PP-03 · Port 12', 'Patch panel · R04 / U1', 0.27],
  ['Cable C-11873', 'Singlemode OS2 · 14 m', 0.5],
  ['FFM-PP-07 · Port 12', 'Patch panel · R05 / U1', 0.73],
  ['FFM-CORE-02 · Te1/1', 'Router · R05 / U3', 0.98],
];

function Device({ rx, s, k, T, K, cableP }) {
  const [i, u, name, kind, isSel] = s;
  const top = 113 + i * 40, h = u * 40 - 6;
  const pin = tw(T, K.Ra + 2.9 + k * 0.16, K.Ra + 3.3 + k * 0.16, M.pop);
  const on = isSel ? tw(T, K.Ca + 1.0, K.Ca + 1.4, M.enter) : 0;
  const ports = kind === 'rtr' ? 8 : kind === 'sw' ? 12 : kind === 'pp' ? 16 : 0;
  const step = kind === 'pp' ? 11 : 14;
  const left = rx < 300;
  return (
    <div style={{ position: 'absolute', left: rx + 22, top, width: 266, height: h, opacity: clampN(pin * 2), transform: `translateX(${(1 - pin) * 60}px)`, background: on ? mix(C.panel2, C.accSoft, on) : C.panel2, border: `1px solid ${mix(C.line2, C.acc, on)}`, borderRadius: 4, boxSizing: 'border-box' }}>
      {Array.from({ length: ports }).map((_, j) => {
        const lit = (kind === 'pp' && j === 11 && cableP > (left ? 0.27 : 0.73)) || (kind === 'rtr' && j === 0 && cableP > (left ? 0.01 : 0.97));
        return <div key={j} style={{ position: 'absolute', left: (kind === 'pp' ? -2 : 0) + j * step, top: kind === 'pp' ? 12 : 8, width: kind === 'pp' ? 8 : 10, height: kind === 'pp' ? 8 : 10, borderRadius: 2, background: lit ? C.acc : '#0B0E12', border: `1px solid ${lit ? C.acc : C.line2}`, boxShadow: lit ? `0 0 10px ${C.acc}` : 'none', marginLeft: 0 }}></div>;
      })}
      {kind === 'dev' && [0, 1, 2, 3].map((j) => <div key={j} style={{ position: 'absolute', left: 4 + j * 34, top: h / 2 - 4, width: 26, height: 8, borderRadius: 2, background: '#0B0E12', border: `1px solid ${C.line2}` }}></div>)}
      <div style={{ position: 'absolute', right: 8, top: h / 2 - 9, font: `500 15px ${MONO}`, color: on > 0.5 ? C.acc : C.dim }}>{name}</div>
    </div>
  );
}

function RackView({ T, K, end }) {
  const xf = zoomXf(T, K.Ra + 2.2, [905, 500], 4.2, null, null, 1);
  if (xf.display === 'none') return null;
  const pan = tw(T, K.Ca, K.Ca + 1.3);
  const pull = tw(T, K.Cl, K.Cl + 1.2);
  const cableP = tw(T, K.Ca + 1.6, K.Ca + 4.6, M.move);
  const cardO = tw(T, K.Ca + 1.0, K.Ca + 1.6, M.enter);
  const r5 = tw(T, K.Ra + 2.8, K.Ra + 3.4, M.enter);
  const portPulse = T > K.Ca + 1.3 && T < K.Ca + 2.1 ? (T - K.Ca - 1.3) / 0.8 : -1;
  const drift = lerp(1, 1.03, tw(T, K.Ra + 3.5, K.Ca));
  return (
    <Layer xf={xf}>
      <div style={{ position: 'absolute', inset: 0, opacity: lerp(1, 0.1, pull), transform: `translateX(${-450 * pan}px) scale(${drift * lerp(1, 0.94, pull)})`, transformOrigin: `${960 + 450 * pan}px 540px` }}>
        <div style={{ position: 'absolute', left: OX, top: OY, width: 1360, height: 744 }}>
          {RACKS.map((r, ri) => (
            <div key={r.name} style={{ opacity: ri ? r5 : 1 }}>
              <div style={{ position: 'absolute', left: r.x, top: 80, width: 300, height: 610, background: '#0E1216', border: `2px solid ${ri ? C.line2 : C.acc}`, borderRadius: 6, boxSizing: 'border-box' }}></div>
              {Array.from({ length: 14 }).map((_, k) => <div key={k} style={{ position: 'absolute', left: r.x + 6, top: 113 + k * 40 + 12, font: `400 12px ${MONO}`, color: C.faint }}>{14 - k}</div>)}
              {r.slots.map((s, k) => <Device key={s[2]} rx={r.x} s={s} k={k + ri * 2} T={T} K={K} cableP={cableP} />)}
              <div style={{ position: 'absolute', left: r.x, top: 708, width: 300, textAlign: 'center', font: `500 22px ${MONO}`, color: ri ? C.dim : C.acc }}>{r.name}</div>
            </div>
          ))}
          <svg width="1360" height="744" style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
            <path d={CABLE} fill="none" stroke={C.acc} strokeOpacity="0.18" strokeWidth="14" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - cableP} />
            <path d={CABLE} fill="none" stroke={C.acc} strokeWidth="4" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - cableP} />
            {portPulse >= 0 && <circle cx="147" cy="206" r={8 + portPulse * 30} fill="none" stroke={C.acc} strokeWidth="2" opacity={1 - portPulse} />}
          </svg>
          <div style={{ position: 'absolute', left: 950, top: 80, width: 390, opacity: cardO, transform: `translateY(${(1 - cardO) * 20}px)`, background: C.panel, border: `1px solid ${C.line2}`, borderRadius: 12, padding: '26px 28px 10px', boxSizing: 'border-box' }}>
            <div style={{ font: `500 16px ${MONO}`, color: C.dim, letterSpacing: 1.5, textTransform: 'uppercase' }}>Connection trace</div>
            <div style={{ position: 'relative', marginTop: 22 }}>
              <div style={{ position: 'absolute', left: 7, top: 10, width: 2, height: 4 * 88, background: C.line2 }}></div>
              <div style={{ position: 'absolute', left: 7, top: 10, width: 2, height: 4 * 88 * cableP, background: C.acc }}></div>
              {TRACE.map(([a, b, th], i) => {
                const lit = tw(T, K.Ca + 1.6 + th * 3, K.Ca + 1.9 + th * 3, M.enter);
                return (
                  <div key={i} style={{ position: 'relative', height: 88, paddingLeft: 36 }}>
                    <div style={{ position: 'absolute', left: 0, top: 4, width: 16, height: 16, borderRadius: 8, background: lit > 0.5 ? C.acc : C.panel, border: `2px solid ${lit > 0.5 ? C.acc : C.line2}`, boxSizing: 'border-box', transform: `scale(${1 + 0.35 * Math.sin(lit * Math.PI)})` }}></div>
                    <div style={{ font: `500 21px ${MONO}`, color: lit > 0.5 ? C.text : C.faint }}>{a}</div>
                    <div style={{ font: `400 18px ${SANS}`, color: C.dim, marginTop: 4, opacity: 0.4 + 0.6 * lit }}>{b}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </Layer>
  );
}

// ---- persistent location path ----
function PathBar({ T, K, end }) {
  const segs = [
    ['City', 'WEU/DE/FFM', 4.3],
    ['Building', 'Musterstraße 12', K.Fl + 0.2],
    ['Floor', '2', K.Ro + 0.2],
    ['Room', '2.14', K.Ra + 0.2],
    ['Rack', 'R04', K.Ra + 2.9],
  ];
  const c = tw(T, K.Cl + 0.3, K.Cl + 1.5);
  const fade = 1 - tw(T, end - 0.7, end - 0.05);
  const lastOn = segs.reduce((a, s, i) => (T >= s[2] ? i : a), -1);
  return (
    <div style={{ position: 'absolute', left: lerp(110, 960, c), top: lerp(64, 440, c), transform: `translateX(${lerp(0, -50, c)}%) scale(${lerp(1, 1.45, c)})`, transformOrigin: `${lerp(0, 50, c)}% 0`, display: 'flex', alignItems: 'flex-end', gap: 22, opacity: fade }}>
      {segs.map(([l, v, at], i) => {
        const o = tw(T, at, at + 0.5, M.enter);
        if (o <= 0) return null;
        const act = i === lastOn ? 1 - c : 0;
        return (
          <div key={l} style={{ display: 'flex', alignItems: 'flex-end', gap: 22, opacity: o, transform: `translateY(${(1 - o) * 12}px)` }}>
            {i > 0 && <div style={{ font: `400 30px ${MONO}`, color: C.faint, paddingBottom: 2 }}>›</div>}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <div style={{ font: `500 16px ${MONO}`, color: C.dim, letterSpacing: 1.5, textTransform: 'uppercase' }}>{l}</div>
              <div style={{ font: `500 32px ${MONO}`, color: mix(C.text, C.acc, act), whiteSpace: 'nowrap' }}>{v}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function Piece({ tweaks }) {
  const { T, CUES, authoredTotal } = useComposition();
  C = palette(tweaks.accentHue ?? 195);
  const K = { Lo: CUES.Locations, B: CUES.Building, Fl: CUES.Floor, Ro: CUES.Room, Ra: CUES.Rack, Ca: CUES.Cabling, Cl: CUES.Close };
  const end = authoredTotal;
  const caps = [
    { at: K.Lo + 0.4, text: 'In FNT Command, every asset starts with a location.' },
    { at: K.Lo + 2.6, text: 'Cities are coded by region, country and city: WEU/DE/FFM is Frankfurt.' },
    { at: K.B + 0.4, text: 'Within a city, each site is a building, named by its street address.' },
    { at: K.Fl + 0.3, text: 'Each building is divided into floors…' },
    { at: K.Ro + 0.3, text: '…and each floor into rooms.' },
    { at: K.Ra + 0.3, text: 'Racks sit inside rooms, and every device has a fixed position in its rack.' },
    { at: K.Ca + 0.3, text: 'Cables run from device ports through patch panels, so every connection can be traced end to end.' },
    { at: K.Cl + 0.4, until: end - 0.5, text: 'City, building, floor, room, rack: every asset has a precise address.' },
  ];
  const fade = 1 - tw(T, end - 0.7, end - 0.05);
  return (
    <div data-screen-label={`t=${Math.floor(T)}s`} style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: C.bg }}>
      <div style={{ position: 'absolute', inset: -40, backgroundImage: 'radial-gradient(circle, #1A2029 1.2px, transparent 1.6px)', backgroundSize: '40px 40px', transform: `translate(${(T * 3) % 40}px, ${(T * 1.5) % 40}px)` }}></div>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 45%, transparent 40%, rgba(5,7,9,0.75) 100%)' }}></div>
      <div style={{ position: 'absolute', inset: 0, opacity: fade }}>
        <Locations T={T} K={K} />
        <Buildings T={T} K={K} />
        <Floors T={T} K={K} />
        <FloorPlan T={T} K={K} />
        <Room T={T} K={K} />
        <RackView T={T} K={K} end={end} />
      </div>
      <PathBar T={T} K={K} end={end} />
      {tweaks.captions !== false && (
        <Captions items={caps} style={{ left: '50%', right: 'auto', bottom: 40, transform: 'translateX(-50%)', width: 'max-content', maxWidth: 1560, padding: '14px 30px', borderRadius: 12, background: 'rgba(10,13,17,0.88)', font: `500 34px ${SANS}`, color: C.text, textShadow: 'none', lineHeight: 1.3 }} />
      )}
    </div>
  );
}

function FNTVideo() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <>
      <CompositionStage width={1920} height={1080} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#0C0F13">
        <Piece tweaks={t} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Playback" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        <TweakToggle label="Captions" value={t.captions} onChange={(v) => setTweak('captions', v)} />
        <TweakSection label="Look" />
        <TweakRadio label="Accent hue" value={String(t.accentHue)} options={['195', '245', '290']} onChange={(v) => setTweak('accentHue', +v)} />
      </TweaksPanel>
    </>
  );
}

window.FNTVideo = FNTVideo;

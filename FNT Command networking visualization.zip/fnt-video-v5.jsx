const { Easing, useComposition, CompositionStage, Captions } = window;

const M = { enter: Easing.easeOutCubic, move: Easing.easeInOutCubic, pop: Easing.easeOutBack };
const tw = (T, a, b, e = M.move) => (T <= a ? 0 : T >= b ? 1 : e((T - a) / (b - a)));
const lerp = (a, b, p) => a + (b - a) * p;
function kf(T, fr, e = M.move) {
  if (T <= fr[0][0]) return fr[0].slice(1);
  for (let i = 0; i < fr.length - 1; i++) {
    const a = fr[i], b = fr[i + 1];
    if (T < b[0]) { const p = e((T - a[0]) / (b[0] - a[0])); return a.slice(1).map((v, k) => lerp(v, b[k + 1], p)); }
  }
  return fr[fr.length - 1].slice(1);
}
const clampN = (v) => Math.max(0, Math.min(1, v));
const mix = (a, b, p) => `color-mix(in oklch, ${b} ${Math.round(clampN(p) * 100)}%, ${a})`;

const SANS = "'IBM Plex Sans', system-ui, sans-serif";
const MONO = "'IBM Plex Mono', ui-monospace, monospace";
const LV = { city: 235, bldg: 295, floor: 350, room: 45, rack: 155, cable: 200 };
const hc = (h, a) => `oklch(0.64 0.16 ${h}${a ? ' / ' + a : ''})`;
const tint = (h) => `oklch(0.94 0.03 ${h})`;
const tint2 = (h) => `oklch(0.86 0.07 ${h})`;
const deep = (h) => `oklch(0.42 0.12 ${h})`;
const CB = { bg: '#F6F4EF', panel: '#FFFFFF', panel2: '#EFEDE7', line: '#E6E2DA', line2: '#CFCAC0', text: '#1E232A', dim: '#5E6570', faint: '#A0A5AC', metal: '#2E333B' };
let C = CB;
const useHue = (h) => { C = { ...CB, h, acc: hc(h), tint: tint(h), tint2: tint2(h), deep: deep(h) }; };
const SHADOW = '0 24px 60px rgba(60,50,30,0.14), 0 4px 12px rgba(60,50,30,0.08)';

const ZD = 1.3;
const HIDDEN = { display: 'none' };
function zoomXf(T, inAt, inF, Z1, outAt, outF, Z2) {
  if (inAt != null) {
    if (T < inAt) return HIDDEN;
    if (T < inAt + ZD) {
      const p = tw(T, inAt, inAt + ZD);
      return { transform: `translate(${(inF[0] - 960) * (1 - p)}px, ${(inF[1] - 540) * (1 - p)}px) scale(${Math.pow(Z1, p - 1)})`, transformOrigin: '960px 540px', opacity: tw(T, inAt + 0.15 * ZD, inAt + 0.55 * ZD, M.enter) };
    }
  }
  if (outAt != null && T >= outAt) {
    if (T > outAt + ZD) return HIDDEN;
    const p = tw(T, outAt, outAt + ZD);
    return { transform: `translate(${(960 - outF[0]) * p}px, ${(540 - outF[1]) * p}px) scale(${Math.pow(Z2, p)})`, transformOrigin: `${outF[0]}px ${outF[1]}px`, opacity: 1 - tw(T, outAt + 0.4 * ZD, outAt + 0.8 * ZD) };
  }
  return { opacity: 1 };
}
const Layer = ({ xf, children }) => (xf.display === 'none' ? null : <div style={{ position: 'absolute', inset: 0, ...xf }}>{children}</div>);
const sel = (T, at) => tw(T, at, at + 0.45, M.enter);
const ring = (T, at) => (T > at ? ((T - at) % 1.1) / 1.1 : -1);

// ---------- 1. World ----------
const RH = { AME: 25, WEU: 235, EEU: 155, ASI: 75 };
const RNAME = { AME: 'Americas', WEU: 'Western Europe', EEU: 'Eastern Europe', ASI: 'Asia' };
const DOTREST = '#D9D3C7';
const rcol = (h, l = 0.68, c = 0.15, al) => `oklch(${l} ${c} ${h}${al != null ? ' / ' + al : ''})`;
const CITY4 = [
  { id: 'NY', code: ['AME', 'US', 'NY'], name: 'New York', r: 'AME', c: 'US', side: 'r' },
  { id: 'FFM', code: ['WEU', 'DE', 'FFM'], name: 'Frankfurt', r: 'WEU', c: 'DE', side: 'l', key: 1 },
  { id: 'SOF', code: ['EEU', 'BG', 'SOF'], name: 'Sofia', r: 'EEU', c: 'BG', side: 'rb' },
  { id: 'TOK', code: ['ASI', 'JP', 'TOK'], name: 'Tokyo', r: 'ASI', c: 'JP', side: 'l' },
];
function World({ T, K }) {
  useHue(LV.city);
  const W = window.WORLD;
  const xf = zoomXf(T, null, null, 1, K.B - 0.3, [960, 540], 6);
  if (!W || xf.display === 'none') return null;
  const F = W.cities.FFM;
  const [fx, fy, s] = kf(T, [[0, 960, 540, 1.1], [2.0, 960, 540, 1], [4.0, 960, 540, 1], [5.2, F[0], F[1], 2.8]]);
  const scr = (p) => [(p[0] - fx) * s + 960, (p[1] - fy) * s + 540];
  const reveal = tw(T, 0, 2.0, M.move);
  const tintP = tw(T, 1.3, 2.3);
  const focus = tw(T, 4.0, 4.9);
  const dec = (i) => tw(T, 4.9 + i * 0.4, 5.3 + i * 0.4, M.enter);
  const ctry = tw(T, 2.0, 2.8);
  const rp = ring(T, 6.3);
  const dotCol = (r) => (r === 'rest' ? DOTREST : mix(DOTREST, rcol(RH[r], r === 'WEU' ? lerp(0.68, 0.58, dec(0)) : 0.68), tintP * (r === 'WEU' ? 1 : 1 - 0.8 * focus)));
  return (
    <Layer xf={xf}>
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0 }}>
        <defs>
          <radialGradient id="wrev"><stop offset="0.8" stopColor="#fff" /><stop offset="1" stopColor="#000" /></radialGradient>
          <mask id="wmask" maskUnits="userSpaceOnUse" x="-400" y="-400" width="2720" height="1880"><circle cx={F[0]} cy={F[1]} r={Math.max(1, reveal * 1700)} fill="url(#wrev)" /></mask>
        </defs>
        <g transform={`translate(${960 - fx * s} ${540 - fy * s}) scale(${s})`}>
          <g mask="url(#wmask)">
            <path d={W.land} fill="#ECE7DC" />
            {CITY4.map((c) => {
              const isDE = c.c === 'DE';
              const al = isDE ? lerp(0.32 * ctry, 0.92, dec(1)) : 0.32 * ctry * (1 - focus);
              return <path key={c.c} d={W.countries[c.c]} fill={rcol(RH[c.r], isDE ? lerp(0.8, 0.6, dec(1)) : 0.8, isDE ? lerp(0.1, 0.16, dec(1)) : 0.1, al)} stroke={isDE && dec(1) > 0 ? '#fff' : 'none'} strokeWidth={1.4 / s} />;
            })}
            {Object.keys(W.dots).map((r) => <path key={r} d={W.dots[r]} fill="none" stroke={dotCol(r)} strokeWidth={W.sp * 0.62} strokeLinecap="round" />)}
          </g>
          {W.arcs.map((d, k) => {
            const p = tw(T, 2.9 + k * 0.22, 3.9 + k * 0.22, M.move);
            return (
              <g key={k} opacity={1 - 0.75 * focus}>
                <path d={d} fill="none" stroke="oklch(0.38 0.06 250)" strokeWidth={2.6 / s} strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - p} />
                {p >= 1 && <path d={d} fill="none" stroke="oklch(0.38 0.06 250)" strokeWidth={8 / s} strokeLinecap="round" pathLength="1" strokeDasharray="0.001 0.999" strokeDashoffset={-((T * 0.3 + k * 0.27) % 1)} />}
              </g>
            );
          })}
        </g>
      </svg>
      {CITY4.map((c, i) => {
        const [x, y] = scr(W.cities[c.id]);
        const drop = tw(T, 2.2 + i * 0.18, 2.75 + i * 0.18, M.pop);
        if (drop <= 0) return null;
        const fo = c.key ? 1 : 1 - focus;
        return (
          <div key={c.id} style={{ position: 'absolute', left: x, top: y, opacity: clampN(drop * 3) * fo }}>
            {c.key && rp >= 0 && <div style={{ position: 'absolute', left: -(14 + rp * 50), top: -(7 + rp * 25), width: 2 * (14 + rp * 50), height: 14 + rp * 50, borderRadius: '50%', border: `3px solid ${rcol(RH[c.r], 0.55, 0.17)}`, boxSizing: 'border-box', opacity: 1 - rp }}></div>}
            <div style={{ position: 'absolute', left: -10, top: -4, width: 20, height: 8, borderRadius: '50%', background: 'rgba(40,35,25,0.28)', transform: `scale(${clampN(drop)})` }}></div>
            <div style={{ position: 'absolute', left: -17, top: -41, width: 34, height: 34, transform: `translateY(${(1 - drop) * -70}px)` }}>
              <div style={{ position: 'absolute', inset: 0, borderRadius: '50% 50% 50% 0', transform: 'rotate(-45deg)', background: rcol(RH[c.r], 0.6, 0.17), boxShadow: '0 4px 10px rgba(40,35,25,0.25)' }}></div>
              <div style={{ position: 'absolute', left: 10, top: 10, width: 14, height: 14, borderRadius: 7, background: '#fff' }}></div>
            </div>
          </div>
        );
      })}
      {CITY4.map((c, i) => {
        const [x, y] = scr(W.cities[c.id]);
        const o = tw(T, 2.5 + i * 0.18, 2.9 + i * 0.18, M.enter) * (c.key ? 1 : 1 - focus);
        if (o <= 0) return null;
        const big = c.key ? focus : 0;
        const fs = lerp(24, 46, big), cw = fs * 0.6;
        const left = c.side === 'l';
        const lx = left ? x - 30 - 16 * big : x + 28;
        const ly = c.side === 'rb' ? y + 6 : y - 62 - 52 * big;
        const d0 = c.key ? dec(0) : 0;
        return (
          <div key={c.id} style={{ position: 'absolute', left: lx, top: ly, transform: `translateX(${left ? '-100%' : '0px'}) translateY(${(1 - o) * 10}px)`, opacity: o, background: '#fff', borderRadius: 14, padding: `10px 16px ${lerp(10, 50, d0)}px`, boxShadow: '0 6px 20px rgba(60,50,30,0.14)' }}>
            <div style={{ position: 'relative', display: 'flex', font: `600 ${fs}px ${MONO}`, whiteSpace: 'pre', color: C.text }}>
              {c.code.map((seg, k) => <span key={k} style={{ color: c.key ? mix(C.text, C.deep, dec(k)) : C.text }}>{(k ? '/' : '') + seg}</span>)}
              {c.key && ['Region', 'Country', 'City'].map((l, k) => {
                const st = [0, 4, 7][k] * cw, w = c.code[k].length * cw, p = dec(k);
                return (
                  <div key={l} style={{ position: 'absolute', left: st, top: fs * 1.3, width: w, opacity: p, transform: `translateY(${(1 - p) * 8}px)` }}>
                    <div style={{ height: 8, borderLeft: `3px solid ${C.acc}`, borderRight: `3px solid ${C.acc}`, borderBottom: `3px solid ${C.acc}`, boxSizing: 'border-box' }}></div>
                    <div style={{ position: 'absolute', left: '50%', top: 14, transform: 'translateX(-50%)', padding: '3px 10px', borderRadius: 12, background: C.acc, font: `600 15px ${SANS}`, color: '#fff', whiteSpace: 'nowrap' }}>{l}</div>
                  </div>
                );
              })}
            </div>
            <div style={{ font: `500 18px ${SANS}`, color: C.dim, marginTop: lerp(2, 0, d0), height: lerp(24, 0, d0), overflow: 'hidden', opacity: 1 - d0 }}>{c.name}</div>
          </div>
        );
      })}
      <div style={{ position: 'absolute', right: 70, top: 50, display: 'flex', gap: 10, opacity: 1 - focus }}>
        {['AME', 'WEU', 'EEU', 'ASI'].map((r, i) => {
          const o = tw(T, 1.4 + i * 0.12, 1.8 + i * 0.12, M.enter);
          return (
            <div key={r} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 16px 8px 12px', borderRadius: 30, background: '#fff', boxShadow: '0 4px 14px rgba(60,50,30,0.10)', opacity: o, transform: `translateY(${(1 - o) * -10}px)` }}>
              <div style={{ width: 14, height: 14, borderRadius: 7, background: rcol(RH[r], 0.62, 0.16) }}></div>
              <div style={{ font: `600 18px ${MONO}`, color: C.text }}>{r}</div>
              <div style={{ font: `400 18px ${SANS}`, color: C.dim }}>{RNAME[r]}</div>
            </div>
          );
        })}
      </div>
    </Layer>
  );
}

// ---------- 2. Buildings ----------
const BLDG = [
  { x: 380, w: 250, h: 300, n: 'Mainzer Landstraße 8', f: 3 },
  { x: 810, w: 300, h: 460, n: 'Mainzer Landstraße 12', f: 4, key: 1 },
  { x: 1290, w: 250, h: 240, n: 'Mainzer Landstraße 20', f: 2 },
];
const TREES = [270, 700, 1190, 1640];
const SKY = [[220, 100, 210], [330, 70, 340], [520, 80, 170], [640, 120, 260], [1110, 90, 380], [1215, 70, 220], [1560, 110, 300], [1680, 80, 190]];
const GROUND = 780;
function Buildings({ T, K }) {
  useHue(LV.bldg);
  const xf = zoomXf(T, K.B - 0.3, [960, 540], 6, K.Fl - 0.3, [960, 550], 2.6);
  const s = sel(T, K.Fl - 1.5);
  const rp = ring(T, K.Fl - 1.5);
  const g = tw(T, K.B + 0.3, K.B + 1.1);
  return (
    <Layer xf={xf}>
      <div style={{ position: 'absolute', left: 960 - 800 * g, top: GROUND, width: 1600 * g, height: 70, borderRadius: '0 0 40px 40px', background: 'oklch(0.92 0.025 90)' }}></div>
      {SKY.map(([x, w, h], i) => {
        const p = tw(T, K.B + 0.3 + i * 0.05, K.B + 0.9 + i * 0.05, M.enter);
        return <div key={'s' + i} style={{ position: 'absolute', left: x, top: GROUND - h, width: w, height: h, transform: `scaleY(${p})`, transformOrigin: 'bottom', background: `oklch(0.91 0.03 ${LV.bldg})`, borderRadius: '6px 6px 0 0' }}></div>;
      })}
      {TREES.map((x, i) => {
        const p = tw(T, K.B + 1.0 + i * 0.12, K.B + 1.5 + i * 0.12, M.pop);
        return (
          <div key={i} style={{ position: 'absolute', left: x - 34, top: GROUND - 110, width: 68, height: 110, transform: `scale(${Math.max(0, p)})`, transformOrigin: 'bottom' }}>
            <div style={{ position: 'absolute', left: 30, top: 60, width: 8, height: 50, borderRadius: 3, background: 'oklch(0.55 0.06 60)' }}></div>
            <div style={{ position: 'absolute', left: 0, top: 0, width: 68, height: 68, borderRadius: 34, background: 'oklch(0.76 0.13 150)' }}></div>
          </div>
        );
      })}
      {BLDG.map((b, i) => {
        const rise = tw(T, K.B + 0.6 + i * 0.2, K.B + 1.3 + i * 0.2, M.pop);
        const on = b.key ? s : 0;
        const lo = tw(T, K.B + 1.0 + i * 0.2, K.B + 1.4 + i * 0.2, M.enter);
        return (
          <div key={i}>
            <div style={{ position: 'absolute', left: b.x, top: GROUND - b.h, width: b.w, height: b.h, transform: `scaleY(${Math.max(0, rise)})`, transformOrigin: 'bottom', background: mix(C.tint2, C.acc, on), borderRadius: '8px 8px 0 0', boxShadow: on ? `0 0 0 6px ${C.tint2}` : 'none' }}>
              {b.key && <div style={{ position: 'absolute', left: b.w / 2 - 3, top: -46, width: 6, height: 46, background: mix(C.tint2, C.acc, on) }}></div>}
              {b.key && <div style={{ position: 'absolute', left: b.w / 2 - 9, top: -58, width: 18, height: 18, borderRadius: 9, background: mix(C.tint2, C.acc, on) }}></div>}
              {Array.from({ length: b.f - 1 }).map((_, k) => <div key={k} style={{ position: 'absolute', left: 0, right: 0, top: ((k + 1) * b.h) / b.f - 2, height: 4, background: 'rgba(255,255,255,0.45)' }}></div>)}
              {Array.from({ length: b.f }).map((_, k) => (
                <div key={k} style={{ position: 'absolute', left: 26, right: 26, top: (k * b.h) / b.f + b.h / b.f / 2 - 14, display: 'flex', justifyContent: 'space-between' }}>
                  {Array.from({ length: Math.floor(b.w / 62) }).map((_, j) => <div key={j} style={{ width: 28, height: 28, borderRadius: 4, background: (j + k) % 3 === 0 && on > 0.5 ? 'oklch(0.92 0.12 90)' : 'rgba(255,255,255,0.7)' }}></div>)}
                </div>
              ))}
              {b.key && <div style={{ position: 'absolute', left: b.w / 2 - 30, bottom: 0, width: 60, height: 70, borderRadius: '30px 30px 0 0', background: 'rgba(255,255,255,0.75)' }}></div>}
            </div>
            {b.key && rp >= 0 && <div style={{ position: 'absolute', left: b.x - 14 - rp * 30, top: GROUND - b.h - 14 - rp * 30, width: b.w + 28 + rp * 60, height: b.h + 14 + rp * 30, border: `3px solid ${C.acc}`, borderBottom: 'none', borderRadius: 14, opacity: 1 - rp, boxSizing: 'border-box' }}></div>}
            <div style={{ position: 'absolute', left: b.x - 60, width: b.w + 120, top: GROUND + 20, display: 'flex', justifyContent: 'center', opacity: lo }}>
              <div style={{ padding: '6px 16px', borderRadius: 20, background: on > 0.5 ? C.acc : '#fff', font: `600 22px ${SANS}`, color: on > 0.5 ? '#fff' : C.text, whiteSpace: 'nowrap', boxShadow: '0 2px 8px rgba(60,50,30,0.1)' }}>{b.n}</div>
            </div>
          </div>
        );
      })}
    </Layer>
  );
}

// ---------- 3. Floors (isometric stack) ----------
const FL = [['Floor 0', 'Reception · loading bay'], ['Floor 1', 'Offices'], ['Floor 2', 'Technical rooms', 1], ['Floor 3', 'Offices']];
const FCX = 820, FY0 = 720, FGAP = 118, FSL = 170;
function Floors({ T, K }) {
  useHue(LV.floor);
  const xf = zoomXf(T, K.Fl - 0.3, [960, 550], 2.6, K.Ro - 0.3, [FCX + FSL, FY0 - 2 * FGAP], 3);
  const s = sel(T, K.Ro - 1.8);
  const slide = tw(T, K.Ro - 1.8, K.Ro - 1.0, M.move);
  return (
    <Layer xf={xf}>
      {FL.map(([n, u, key], b) => {
        const o = tw(T, K.Fl + 0.4 + b * 0.2, K.Fl + 0.9 + b * 0.2, M.enter);
        const on = key ? s : 0;
        const dx = key ? FSL * slide : 0;
        const dy = (1 - o) * -80;
        const cy = FY0 - b * FGAP;
        const fade = key ? 1 : 1 - 0.45 * slide;
        const plate = (off, bg, extra) => (
          <div style={{ position: 'absolute', left: FCX - 200, top: cy - 200 + off, width: 400, height: 400, transform: `translate(${dx}px, ${dy}px) rotateX(60deg) rotateZ(-45deg)`, borderRadius: 14, background: bg, ...extra }}></div>
        );
        return (
          <div key={n} style={{ opacity: o * fade }}>
            {plate(18, mix(`oklch(0.76 0.08 ${LV.floor})`, C.deep, on))}
            {plate(0, mix(`oklch(0.92 0.045 ${LV.floor})`, C.acc, on), { backgroundImage: 'linear-gradient(rgba(255,255,255,0.55) 3px, transparent 3px), linear-gradient(90deg, rgba(255,255,255,0.55) 3px, transparent 3px)', backgroundSize: '100px 100px, 133px 133px', backgroundPosition: '-1px -1px' })}
            <div style={{ position: 'absolute', left: FCX + 283 + dx, top: cy + dy - 1, width: 60, height: 3, background: on > 0.5 ? C.acc : C.line2 }}></div>
            <div style={{ position: 'absolute', left: FCX + 356 + dx, top: cy - 30 + dy, display: 'flex', flexDirection: 'column', gap: 2 }}>
              <div style={{ font: `600 32px ${MONO}`, color: on > 0.5 ? C.deep : C.text, whiteSpace: 'nowrap' }}>{n}</div>
              <div style={{ font: `400 22px ${SANS}`, color: C.dim, whiteSpace: 'nowrap' }}>{u}</div>
            </div>
          </div>
        );
      })}
    </Layer>
  );
}

// ---------- 4. Floor plan ----------
const ROOMS = [
  [360, 230, 320, 280, '2.10', 'Office', 'desk'], [680, 230, 320, 280, '2.11', 'Office', 'desk'], [1000, 230, 560, 280, '2.12', 'Meeting', 'table'],
  [360, 590, 400, 280, '2.13', 'Storage', 'shelf'], [760, 590, 440, 280, '2.14', 'Server room', 'rack', 1], [1200, 590, 360, 280, '2.15', 'UPS / power', 'ups'],
];
function Furniture({ kind, w, h, on }) {
  const c = on ? 'rgba(255,255,255,0.75)' : `oklch(0.84 0.07 ${LV.room})`;
  const box = (x, y, bw, bh, r = 4) => <div key={x + '-' + y} style={{ position: 'absolute', left: x, top: y, width: bw, height: bh, borderRadius: r, background: c }}></div>;
  if (kind === 'desk') return [box(24, h - 84, 110, 60), box(w - 134, h - 84, 110, 60)];
  if (kind === 'table') return [box(w / 2 - 150, h - 120, 300, 90, 45)];
  if (kind === 'shelf') return [box(24, h - 48, w - 48, 24), box(w - 48, 110, 24, h - 158)];
  if (kind === 'ups') return [box(24, h - 124, 60, 100), box(96, h - 124, 60, 100)];
  return Array.from({ length: 6 }).map((_, i) => box(24 + i * 66, h - 100, 48, 76, 3));
}
function FloorPlan({ T, K }) {
  useHue(LV.room);
  const xf = zoomXf(T, K.Ro - 0.3, [FCX + FSL, FY0 - 2 * FGAP], 3, K.Ra - 0.3, [980, 730], 2.7);
  const s = sel(T, K.Ra - 1.5);
  const rp = ring(T, K.Ra - 1.5);
  const co = tw(T, K.Ro + 0.5, K.Ro + 1.0, M.enter);
  return (
    <Layer xf={xf}>
      <div style={{ position: 'absolute', left: 340, top: 210, width: 1240, height: 680, borderRadius: 18, background: '#fff', boxShadow: SHADOW, opacity: co }}></div>
      <div style={{ position: 'absolute', left: 360, top: 510, width: 1200, height: 80, opacity: co, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `500 20px ${MONO}`, color: C.faint, letterSpacing: 6, textTransform: 'uppercase' }}>Corridor</div>
      {ROOMS.map(([x, y, w, h, n, u, f, key], i) => {
        const o = tw(T, K.Ro + 0.4 + i * 0.12, K.Ro + 0.9 + i * 0.12, M.enter);
        const on = key ? s : 0;
        return (
          <div key={n} style={{ position: 'absolute', left: x + 6, top: y + 6, width: w - 12, height: h - 12, opacity: o, transform: `scale(${lerp(0.94, 1, o)})`, background: mix(C.tint, C.acc, on), borderRadius: 10, zIndex: key ? 2 : 1 }}>
            <Furniture kind={f} w={w - 12} h={h - 12} on={on > 0.5} />
            <div style={{ position: 'absolute', left: 24, top: 20, display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 2 }}>
              <div style={{ font: `600 36px ${MONO}`, color: on > 0.5 ? '#fff' : C.text }}>{n}</div>
              <div style={{ font: `500 22px ${SANS}`, color: on > 0.5 ? '#fff' : C.dim }}>{u}</div>
            </div>
            {key && rp >= 0 && <div style={{ position: 'absolute', inset: -8 - rp * 24, border: `3px solid ${C.acc}`, borderRadius: 14, opacity: 1 - rp }}></div>}
          </div>
        );
      })}
    </Layer>
  );
}

// ---------- 5. Room ----------
function Room({ T, K }) {
  useHue(LV.rack);
  const xf = zoomXf(T, K.Ra - 0.3, [980, 730], 2.7, K.Ra + 2.2, [905, 500], 4.2);
  const s = sel(T, K.Ra + 1.2);
  const rp = ring(T, K.Ra + 1.2);
  const wo = tw(T, K.Ra + 0.3, K.Ra + 0.8, M.enter);
  return (
    <Layer xf={xf}>
      <div style={{ position: 'absolute', left: 360, top: 230, width: 1200, height: 640, borderRadius: 18, opacity: wo, background: '#fff', backgroundImage: `linear-gradient(${CB.line} 2px, transparent 2px), linear-gradient(90deg, ${CB.line} 2px, transparent 2px)`, backgroundSize: '60px 60px', boxShadow: SHADOW }}></div>
      <div style={{ position: 'absolute', left: 460, top: 590, width: 1030, height: 80, borderRadius: 10, opacity: wo, background: `repeating-linear-gradient(135deg, oklch(0.93 0.04 ${LV.cable}) 0 16px, oklch(0.89 0.06 ${LV.cable}) 16px 22px)`, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `600 20px ${MONO}`, color: deep(LV.cable), letterSpacing: 6, textTransform: 'uppercase' }}>Cold aisle</div>
      {Array.from({ length: 8 }).map((_, i) => {
        const o = tw(T, K.Ra + 0.4 + i * 0.08, K.Ra + 0.8 + i * 0.08, M.enter);
        const on = i === 3 ? s : 0;
        return (
          <div key={i} style={{ position: 'absolute', left: 460 + i * 130, top: 420, width: 110, height: 140, opacity: o, transform: `translateY(${(1 - o) * -20}px)`, background: mix(C.metal, C.acc, on), borderRadius: 8, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 14, font: `600 24px ${MONO}`, color: '#fff' }}>
            {'R0' + (i + 1)}
            <div style={{ display: 'flex', gap: 6 }}>{[0, 1, 2].map((k) => <div key={k} style={{ width: 10, height: 10, borderRadius: 5, background: k === 2 ? 'oklch(0.85 0.14 90)' : 'oklch(0.8 0.17 150)' }}></div>)}</div>
            {i === 3 && rp >= 0 && <div style={{ position: 'absolute', inset: -8 - rp * 22, border: `3px solid ${C.acc}`, borderRadius: 12, opacity: 1 - rp }}></div>}
          </div>
        );
      })}
    </Layer>
  );
}

// ---------- 6. Rack elevation ----------
const OX = 690, OY = 160;
const RACKS = [
  { x: 120, name: 'R04', slots: [[0, 1, 'PC5-1002', 'pp'], [2, 2, 'RTR-1101', 'rtr', 1], [5, 2, 'FW-1102', 'fw'], [7, 1, 'SW-1103', 'sw'], [9, 1, 'SRV-1204', 'dev'], [10, 1, 'SRV-1205', 'dev'], [12, 2, 'UPS-1301', 'ups']] },
  { x: 560, name: 'R05', slots: [[0, 1, 'PC5-2001', 'pp'], [2, 2, 'RTR-2101', 'rtr'], [5, 1, 'SW-2103', 'sw'], [7, 2, 'STO-2201', 'dev'], [10, 1, 'SRV-2207', 'dev']] },
];
const KCOL = { pp: `oklch(0.90 0.06 ${LV.cable})`, rtr: `oklch(0.88 0.07 295)`, fw: `oklch(0.89 0.07 20)`, sw: `oklch(0.89 0.07 235)`, dev: '#E8E6E1', ups: 'oklch(0.91 0.08 85)' };
const CABLE = 'M147 206 C147 168 265 168 265 130 C265 34 705 34 705 130 C705 168 587 168 587 206';
const TRACE = [
  ['RTR-1101 · Gi0/1', 'ASR1002-X · R04 / U12', 0.02],
  ['PC5-1002 · Port 12', 'PC5-16RJ45 · R04 / U14', 0.27],
  ['CBL-11873', 'Cat6A · 14 m', 0.5],
  ['PC5-2001 · Port 12', 'PC5-16RJ45 · R05 / U14', 0.73],
  ['RTR-2101 · Gi0/1', 'ASR1002-X · R05 / U12', 0.98],
];
function Device({ rx, s, k, T, K, cableP }) {
  const [i, u, name, kind, isSel] = s;
  const top = 113 + i * 40, h = u * 40 - 6;
  const pin = tw(T, K.Ra + 2.9 + k * 0.16, K.Ra + 3.3 + k * 0.16, M.pop);
  const on = isSel ? Math.max(tw(T, K.Pr + 0.3, K.Pr + 0.7, M.enter) * (1 - tw(T, K.Ca, K.Ca + 0.5)), tw(T, K.Ca + 1.0, K.Ca + 1.4, M.enter)) : 0;
  const ports = kind === 'rtr' ? 8 : kind === 'sw' ? 12 : kind === 'pp' ? 16 : 0;
  const step = kind === 'pp' ? 11 : 14;
  const left = rx < 300;
  const CAB = hc(LV.cable);
  return (
    <div style={{ position: 'absolute', left: rx + 22, top, width: 266, height: h, opacity: clampN(pin * 2), transform: `translateX(${(1 - pin) * 60}px)`, background: mix(KCOL[kind], C.acc, on), borderRadius: 4 }}>
      {Array.from({ length: ports }).map((_, j) => {
        const lit = (kind === 'pp' && j === 11 && cableP > (left ? 0.27 : 0.73)) || (kind === 'rtr' && j === 0 && cableP > (left ? 0.01 : 0.97));
        return <div key={j} style={{ position: 'absolute', left: 6 + j * step, top: kind === 'pp' ? 12 : 8, width: kind === 'pp' ? 8 : 10, height: kind === 'pp' ? 8 : 10, borderRadius: 2, background: lit ? CAB : '#3A4048', boxShadow: lit ? `0 0 0 3px ${hc(LV.cable, 0.3)}` : 'none' }}></div>;
      })}
      {(kind === 'dev' || kind === 'fw' || kind === 'ups') && [0, 1, 2, 3].map((j) => <div key={j} style={{ position: 'absolute', left: 8 + j * 30, top: h / 2 - 4, width: 22, height: 8, borderRadius: 4, background: 'rgba(40,45,52,0.35)' }}></div>)}
      <div style={{ position: 'absolute', right: 8, top: h / 2 - 9, font: `600 15px ${MONO}`, color: on > 0.5 ? '#fff' : '#3A4048' }}>{name}</div>
    </div>
  );
}

const PROPS = [
  ['Object type', 'ASR1002-X · Router, 2 U'],
  ['Position', 'R04 · U12'],
  ['Serial number', 'FOX2417P1AB', 1],
  ['Management IP', '10.48.12.21', 1],
  ['CORIA-ID', '41-17-06', 1],
];
function PropCard({ T, K }) {
  const o = tw(T, K.Pr + 0.4, K.Pr + 0.9, M.enter) * (1 - tw(T, K.Ca, K.Ca + 0.6));
  if (o <= 0) return null;
  const line = tw(T, K.Pr + 0.3, K.Pr + 0.9, M.move);
  return (
    <>
      <svg width="1" height="1" style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible', opacity: o }}>
        <line x1="142" y1="230" x2={lerp(142, -110, line)} y2="230" stroke={C.acc} strokeWidth="3" />
        <circle cx="142" cy="230" r="7" fill={C.acc} />
      </svg>
      <div style={{ position: 'absolute', left: -570, top: 80, width: 460, opacity: o, transform: `translateX(${(1 - o) * -24}px)`, background: '#fff', borderRadius: 18, overflow: 'hidden', boxShadow: SHADOW }}>
        <div style={{ background: C.acc, padding: '22px 30px 20px' }}>
          <div style={{ font: `600 15px ${MONO}`, color: '#fff', letterSpacing: 1.5, textTransform: 'uppercase', opacity: 0.9 }}>Object properties</div>
          <div style={{ font: `600 40px ${MONO}`, color: '#fff', marginTop: 6 }}>RTR-1101</div>
        </div>
        <div style={{ padding: '10px 18px 16px', display: 'flex', flexDirection: 'column', gap: 4 }}>
          {PROPS.map(([l, v, key], i) => {
            const ro = tw(T, K.Pr + 0.8 + i * 0.12, K.Pr + 1.2 + i * 0.12, M.enter);
            const hi = key ? tw(T, K.Pr + 1.8 + (i - 2) * 0.7, K.Pr + 2.1 + (i - 2) * 0.7, M.enter) : 0;
            return (
              <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '10px 12px', borderRadius: 10, background: hi ? mix('#ffffff', C.tint, hi) : 'transparent', opacity: ro, transform: `translateY(${(1 - ro) * 10}px)` }}>
                <div style={{ width: 14, height: 14, borderRadius: 7, flex: 'none', background: key ? mix(C.tint2, C.acc, hi) : C.line, transform: `scale(${1 + 0.4 * Math.sin(hi * Math.PI)})` }}></div>
                <div>
                  <div style={{ font: `500 14px ${SANS}`, color: C.dim, textTransform: 'uppercase', letterSpacing: 1 }}>{l}</div>
                  <div style={{ font: `600 ${key ? 26 : 21}px ${i === 0 ? SANS : MONO}`, color: mix(C.text, C.deep, hi), marginTop: 2, whiteSpace: 'nowrap' }}>{v}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

function RackView({ T, K }) {
  useHue(LV.rack);
  const CAB = hc(LV.cable);
  const xf = zoomXf(T, K.Ra + 2.2, [905, 500], 4.2, null, null, 1);
  if (xf.display === 'none') return null;
  const pan = tw(T, K.Ca, K.Ca + 1.3);
  const pull = tw(T, K.Cl, K.Cl + 1.2);
  const cableP = tw(T, K.Ca + 1.6, K.Ca + 4.6, M.move);
  const cardO = tw(T, K.Ca + 1.0, K.Ca + 1.6, M.enter);
  const r5 = tw(T, K.Ra + 2.8, K.Ra + 3.4, M.enter);
  const portPulse = T > K.Ca + 1.3 && T < K.Ca + 2.1 ? (T - K.Ca - 1.3) / 0.8 : -1;
  const drift = lerp(1, 1.03, tw(T, K.Ra + 3.5, K.Ca));
  return (
    <Layer xf={xf}>
      <div style={{ position: 'absolute', inset: 0, opacity: lerp(1, 0.1, pull), transform: `translateX(${-450 * pan}px) scale(${drift * lerp(1, 0.94, pull)})`, transformOrigin: `${960 + 450 * pan}px 540px` }}>
        <div style={{ position: 'absolute', left: OX, top: OY, width: 1360, height: 744 }}>
          {RACKS.map((r, ri) => (
            <div key={r.name} style={{ opacity: ri ? r5 : 1 }}>
              <div style={{ position: 'absolute', left: r.x, top: 80, width: 300, height: 610, background: C.metal, borderRadius: 10, boxShadow: ri ? SHADOW : `0 0 0 5px ${C.acc}, ${SHADOW}` }}></div>
              {Array.from({ length: 14 }).map((_, k) => <div key={k} style={{ position: 'absolute', left: r.x + 4, top: 113 + k * 40 + 12, width: 16, textAlign: 'center', font: `500 11px ${MONO}`, color: '#8B919A' }}>{14 - k}</div>)}
              {r.slots.map((s, k) => <Device key={s[2]} rx={r.x} s={s} k={k + ri * 2} T={T} K={K} cableP={cableP} />)}
              <div style={{ position: 'absolute', left: r.x, top: 712, width: 300, display: 'flex', justifyContent: 'center' }}>
                <div style={{ padding: '4px 16px', borderRadius: 16, background: ri ? '#fff' : C.acc, color: ri ? C.text : '#fff', font: `600 22px ${MONO}` }}>{r.name}</div>
              </div>
            </div>
          ))}
          <svg width="1360" height="744" style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
            <path d={CABLE} fill="none" stroke={CAB} strokeOpacity="0.25" strokeWidth="16" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - cableP} />
            <path d={CABLE} fill="none" stroke={CAB} strokeWidth="5" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - cableP} />
            {cableP >= 1 && <path d={CABLE} fill="none" stroke="#fff" strokeWidth="5" strokeLinecap="round" pathLength="1" strokeDasharray="0.03 0.97" strokeDashoffset={-((T * 0.4) % 1)} />}
            {portPulse >= 0 && <circle cx="147" cy="206" r={8 + portPulse * 30} fill="none" stroke={CAB} strokeWidth="3" opacity={1 - portPulse} />}
          </svg>
          <PropCard T={T} K={K} />
          <div style={{ position: 'absolute', left: 950, top: 80, width: 390, opacity: cardO, transform: `translateY(${(1 - cardO) * 20}px)`, background: '#fff', borderRadius: 18, padding: '26px 28px 10px', boxSizing: 'border-box', boxShadow: SHADOW }}>
            <div style={{ font: `600 15px ${MONO}`, color: deep(LV.cable), letterSpacing: 1.5, textTransform: 'uppercase' }}>Connection trace</div>
            <div style={{ position: 'relative', marginTop: 22 }}>
              <div style={{ position: 'absolute', left: 8, top: 10, width: 4, height: 4 * 88, borderRadius: 2, background: C.line }}></div>
              <div style={{ position: 'absolute', left: 8, top: 10, width: 4, height: 4 * 88 * cableP, borderRadius: 2, background: CAB }}></div>
              {TRACE.map(([a, b, th], i) => {
                const lit = tw(T, K.Ca + 1.6 + th * 3, K.Ca + 1.9 + th * 3, M.enter);
                return (
                  <div key={i} style={{ position: 'relative', height: 88, paddingLeft: 38 }}>
                    <div style={{ position: 'absolute', left: 0, top: 2, width: 20, height: 20, borderRadius: 10, background: lit > 0.5 ? CAB : '#fff', border: `3px solid ${lit > 0.5 ? CAB : C.line2}`, boxSizing: 'border-box', transform: `scale(${1 + 0.35 * Math.sin(lit * Math.PI)})` }}></div>
                    <div style={{ font: `600 21px ${MONO}`, color: lit > 0.5 ? C.text : C.faint }}>{a}</div>
                    <div style={{ font: `400 18px ${SANS}`, color: C.dim, marginTop: 4, opacity: 0.4 + 0.6 * lit }}>{b}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </Layer>
  );
}

// ---------- location path ----------
function PathBar({ T, K, end }) {
  C = CB;
  const segs = [
    ['City', 'WEU/DE/FFM', 6.0, LV.city],
    ['Building', 'Mainzer Landstraße 12', K.Fl + 0.2, LV.bldg],
    ['Floor', '2', K.Ro + 0.2, LV.floor],
    ['Room', '2.14', K.Ra + 0.2, LV.room],
    ['Rack', 'R04', K.Ra + 2.9, LV.rack],
  ];
  const c = tw(T, K.Cl + 0.3, K.Cl + 1.5);
  const fade = 1 - tw(T, end - 0.7, end - 0.05);
  const lastOn = segs.reduce((a, s, i) => (T >= s[2] ? i : a), -1);
  return (
    <div style={{ position: 'absolute', left: lerp(80, 960, c), top: lerp(48, 430, c), transform: `translateX(${lerp(0, -50, c)}%) scale(${lerp(1, 1.4, c)})`, transformOrigin: `${lerp(0, 50, c)}% 0`, display: 'flex', alignItems: 'center', gap: 14, opacity: fade }}>
      {segs.map(([l, v, at, h], i) => {
        const o = tw(T, at, at + 0.5, M.pop);
        if (o <= 0) return null;
        const act = Math.max(i === lastOn ? 1 : 0, c);
        return (
          <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 14, opacity: clampN(o), transform: `scale(${lerp(0.7, 1, o)})` }}>
            {i > 0 && <div style={{ width: 18, height: 3, borderRadius: 2, background: CB.line2 }}></div>}
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '9px 20px 9px 14px', borderRadius: 40, background: mix('#ffffff', hc(h), act), boxShadow: '0 4px 14px rgba(60,50,30,0.10)' }}>
              <div style={{ width: 14, height: 14, borderRadius: 7, background: act > 0.5 ? '#fff' : hc(h) }}></div>
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                <div style={{ font: `600 13px ${MONO}`, color: act > 0.5 ? '#fff' : CB.dim, letterSpacing: 1.5, textTransform: 'uppercase' }}>{l}</div>
                <div style={{ font: `600 24px ${MONO}`, color: act > 0.5 ? '#fff' : CB.text, whiteSpace: 'nowrap' }}>{v}</div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function Piece({ tweaks }) {
  const { T, CUES, authoredTotal } = useComposition();
  C = CB;
  const K = { Lo: CUES.Locations, B: CUES.Building, Fl: CUES.Floor, Ro: CUES.Room, Ra: CUES.Rack, Pr: CUES.Properties, Ca: CUES.Cabling, Cl: CUES.Close };
  const end = authoredTotal;
  const caps = [
    { at: K.Lo + 0.4, text: 'In FNT Command, every asset starts with a location.' },
    { at: K.Lo + 3.6, text: 'Cities are coded by region, country and city: WEU/DE/FFM is Frankfurt.' },
    { at: K.B + 0.4, text: 'Within a city, each site is a building, named by its street address.' },
    { at: K.Fl + 0.3, text: 'Each building is divided into floors…' },
    { at: K.Ro + 0.3, text: '…and each floor into rooms.' },
    { at: K.Ra + 0.3, text: 'Racks sit inside rooms, and every device has a fixed position in its rack.' },
    { at: K.Pr + 0.3, text: 'Each object carries its own properties: serial number, management IP and the CORIA-ID it belongs to.' },
    { at: K.Ca + 0.3, text: 'Cables run from device ports through patch panels, so every connection can be traced end to end.' },
    { at: K.Cl + 0.4, until: end - 0.5, text: 'City, building, floor, room, rack: every asset has a precise address.' },
  ];
  const fade = 1 - tw(T, end - 0.7, end - 0.05);
  const gh = kf(T, [[K.B, LV.city], [K.B + 1, LV.bldg], [K.Fl, LV.bldg], [K.Fl + 1, LV.floor], [K.Ro, LV.floor], [K.Ro + 1, LV.room], [K.Ra, LV.room], [K.Ra + 1, LV.rack], [K.Ca, LV.rack], [K.Ca + 1, LV.cable]])[0];
  return (
    <div data-screen-label={`t=${Math.floor(T)}s`} style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: CB.bg }}>
      <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(ellipse 65% 60% at 50% 50%, oklch(0.93 0.05 ${gh}), transparent 75%)` }}></div>
      <div style={{ position: 'absolute', inset: -40, backgroundImage: 'radial-gradient(circle, #DDD8CD 1.4px, transparent 1.8px)', backgroundSize: '40px 40px', transform: `translate(${(T * 3) % 40}px, ${(T * 1.5) % 40}px)` }}></div>
      <div style={{ position: 'absolute', inset: 0, opacity: fade }}>
        <World T={T} K={K} />
        <Buildings T={T} K={K} />
        <Floors T={T} K={K} />
        <FloorPlan T={T} K={K} />
        <Room T={T} K={K} />
        <RackView T={T} K={K} />
      </div>
      <PathBar T={T} K={K} end={end} />
      {tweaks.captions !== false && (
        <Captions items={caps} style={{ left: '50%', right: 'auto', bottom: 40, transform: 'translateX(-50%)', width: 'max-content', maxWidth: 1560, padding: '14px 30px', borderRadius: 14, background: 'rgba(30,35,42,0.92)', font: `500 34px ${SANS}`, color: '#F6F4EF', textShadow: 'none', lineHeight: 1.3 }} />
      )}
    </div>
  );
}

function FNTVideo() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <>
      <CompositionStage width={1920} height={1080} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#F6F4EF">
        <Piece tweaks={t} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Playback" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        <TweakToggle label="Captions" value={t.captions} onChange={(v) => setTweak('captions', v)} />
      </TweaksPanel>
    </>
  );
}

window.FNTVideo = FNTVideo;

const { Easing, useComposition, CompositionStage, Captions } = window;

const M = { enter: Easing.easeOutCubic, move: Easing.easeInOutCubic, pop: Easing.easeOutBack };
const tw = (T, a, b, e = M.move) => (T <= a ? 0 : T >= b ? 1 : e((T - a) / (b - a)));
const lerp = (a, b, p) => a + (b - a) * p;
function kf(T, fr, e = M.move) {
  if (T <= fr[0][0]) return fr[0].slice(1);
  for (let i = 0; i < fr.length - 1; i++) {
    const a = fr[i], b = fr[i + 1];
    if (T < b[0]) { const p = e((T - a[0]) / (b[0] - a[0])); return a.slice(1).map((v, k) => lerp(v, b[k + 1], p)); }
  }
  return fr[fr.length - 1].slice(1);
}
const clampN = (v) => Math.max(0, Math.min(1, v));
const mix = (a, b, p) => `color-mix(in oklch, ${b} ${Math.round(clampN(p) * 100)}%, ${a})`;
const nh = (h) => ((h % 360) + 360) % 360;

const SANS = "'IBM Plex Sans', system-ui, sans-serif";
const MONO = "'IBM Plex Mono', ui-monospace, monospace";
// Location levels share one cool analogous ramp (violet → green). Coral marks problems and the signal path.
const LV = { city: 290, bldg: 255, floor: 220, room: 185, rack: 150 };
const NAV_C = 'oklch(0.55 0.15 285)', OM_C = 'oklch(0.56 0.13 150)';
const CORAL = 'oklch(0.66 0.18 35)', CORAL_D = 'oklch(0.50 0.16 35)', CORAL_S = 'oklch(0.66 0.18 35 / 0.3)';
const LED = 'oklch(0.82 0.19 150)', AMBER = 'oklch(0.84 0.15 85)', OKG = 'oklch(0.62 0.15 150)';
const hc = (h, a) => `oklch(0.6 0.15 ${h}${a ? ' / ' + a : ''})`;
const tint = (h) => `oklch(0.95 0.025 ${h})`;
const tint2 = (h) => `oklch(0.86 0.065 ${h})`;
const deep = (h) => `oklch(0.40 0.12 ${h})`;
const shade = (h, l, c) => ({ top: `oklch(${(l + 0.07).toFixed(3)} ${c} ${h})`, sy: `oklch(${l} ${c} ${h})`, sx: `oklch(${(l - 0.09).toFixed(3)} ${c} ${h})` });
const CB = { bg: '#F4F2EE', line: '#E4E1DA', line2: '#CBC7BE', text: '#18213A', dim: '#566079', faint: '#9AA1B0', navy: '#1C2438', navy2: '#131A2A', navy3: '#2B3550', navyTop: '#3A4560' };
let C = CB;
const useHue = (h) => { C = { ...CB, h, acc: hc(h), tint: tint(h), tint2: tint2(h), deep: deep(h) }; };
const SHADOW = '0 24px 60px rgba(24,33,58,0.14), 0 4px 12px rgba(24,33,58,0.08)';
const blink = (T, seed) => (Math.sin(T * 5.3 + seed * 2.7) > -0.3 ? 1 : 0.25);

const ZD = 1.3;
const HIDDEN = { display: 'none' };
function zoomXf(T, inAt, inF, Z1, outAt, outF, Z2) {
  if (inAt != null) {
    if (T < inAt) return HIDDEN;
    if (T < inAt + ZD) {
      const p = tw(T, inAt, inAt + ZD);
      return { transform: `translate(${(inF[0] - 960) * (1 - p)}px, ${(inF[1] - 540) * (1 - p)}px) scale(${Math.pow(Z1, p - 1)})`, transformOrigin: '960px 540px', opacity: tw(T, inAt + 0.15 * ZD, inAt + 0.55 * ZD, M.enter) };
    }
  }
  if (outAt != null && T >= outAt) {
    if (T > outAt + ZD) return HIDDEN;
    const p = tw(T, outAt, outAt + ZD);
    return { transform: `translate(${(960 - outF[0]) * p}px, ${(540 - outF[1]) * p}px) scale(${Math.pow(Z2, p)})`, transformOrigin: `${outF[0]}px ${outF[1]}px`, opacity: 1 - tw(T, outAt + 0.4 * ZD, outAt + 0.8 * ZD) };
  }
  return { opacity: 1 };
}
const Layer = ({ xf, children }) => (xf.display === 'none' ? null : <div style={{ position: 'absolute', inset: 0, ...xf }}>{children}</div>);
const sel = (T, at) => tw(T, at, at + 0.45, M.enter);
const ring = (T, at) => (T > at ? ((T - at) % 1.1) / 1.1 : -1);

// ---------- isometric helpers (2:1) ----------
const IX = 0.7071, IY = 0.3536, IZ = 0.866;
const iso = (o, x, y, z = 0) => [o[0] + (x - y) * IX, o[1] + (x + y) * IY - z * IZ];
const pts = (a) => a.map((p) => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
const isoRect = (o, x, y, w, d, z = 0) => pts([iso(o, x, y, z), iso(o, x + w, y, z), iso(o, x + w, y + d, z), iso(o, x, y + d, z)]);
function IsoBox({ o, x, y, z = 0, w, d, h, top, sy, sx }) {
  const P = (a, b, c) => iso(o, a, b, c);
  const f = (fill, p) => <polygon points={pts(p)} fill={fill} stroke={fill} strokeWidth="0.8" strokeLinejoin="round" />;
  return (
    <g>
      {f(sy, [P(x, y + d, z), P(x + w, y + d, z), P(x + w, y + d, z + h), P(x, y + d, z + h)])}
      {f(sx, [P(x + w, y, z), P(x + w, y + d, z), P(x + w, y + d, z + h), P(x + w, y, z + h)])}
      {f(top, [P(x, y, z + h), P(x + w, y, z + h), P(x + w, y + d, z + h), P(x, y + d, z + h)])}
    </g>
  );
}

// ---------- icons ----------
function NavIcon({ size = 40, col = NAV_C, ring: rc }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size / 2, border: `${Math.round(size * 0.1)}px solid ${rc || col}`, boxSizing: 'border-box', position: 'relative', flex: 'none' }}>
      <div style={{ position: 'absolute', left: '50%', top: '50%', width: size * 0.24, height: size * 0.66, transform: 'translate(-50%, -50%) rotate(40deg)', clipPath: 'polygon(50% 0, 100% 50%, 50% 100%, 0 50%)', background: `linear-gradient(${rc || col} 50%, ${CORAL} 50%)` }}></div>
    </div>
  );
}
function OMIcon({ size = 40, col = OM_C }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size * 0.24, background: col, flex: 'none', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: size * 0.11, paddingLeft: size * 0.2, boxSizing: 'border-box' }}>
      {[0.5, 0.36, 0.44].map((w, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: size * 0.08 }}>
          <div style={{ width: size * 0.1, height: size * 0.1, borderRadius: size, background: '#fff' }}></div>
          <div style={{ height: size * 0.08, borderRadius: 2, background: '#fff', width: size * w }}></div>
        </div>
      ))}
    </div>
  );
}
function Check({ size = 30, col = OKG }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size / 2, background: col, position: 'relative', flex: 'none' }}>
      <div style={{ position: 'absolute', left: size * 0.37, top: size * 0.2, width: size * 0.22, height: size * 0.42, borderRight: `${size * 0.1}px solid #fff`, borderBottom: `${size * 0.1}px solid #fff`, transform: 'rotate(45deg)' }}></div>
    </div>
  );
}

function ClockIcon({ T }) {
  return (
    <div style={{ width: 44, height: 44, borderRadius: 22, border: `4px solid ${CB.navy}`, boxSizing: 'border-box', position: 'relative', flex: 'none' }}>
      <div style={{ position: 'absolute', left: 16, top: 6, width: 4, height: 14, borderRadius: 2, background: CORAL, transformOrigin: '2px 14px', transform: `rotate(${T * 300}deg)` }}></div>
      <div style={{ position: 'absolute', left: 16, top: 11, width: 4, height: 9, borderRadius: 2, background: CB.navy, transformOrigin: '2px 9px', transform: `rotate(${T * 25}deg)` }}></div>
    </div>
  );
}
function WarnIcon() {
  return (
    <div style={{ width: 48, height: 44, position: 'relative', flex: 'none' }}>
      <div style={{ position: 'absolute', inset: 0, background: CORAL, clipPath: 'polygon(50% 0, 100% 100%, 0 100%)', borderRadius: 4 }}></div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 12, textAlign: 'center', font: `700 24px ${SANS}`, color: '#fff' }}>!</div>
    </div>
  );
}
// ---------- 6. Rack elevation ----------
const OX = 690, OY = 160, UY = 113, UH = 40;
const RACKS = [
  { x: 120, name: 'R04', slots: [[0, 1, 'PC5-1002', 'pp'], [2, 2, 'RTR-1101', 'rtr', 1], [5, 2, 'FW-1102', 'fw'], [7, 1, 'SW-1103', 'sw'], [9, 1, 'SRV-1204', 'srv'], [10, 1, 'SRV-1205', 'srv'], [12, 2, 'UPS-1301', 'ups']] },
  { x: 560, name: 'R05', slots: [[0, 1, 'PC5-2001', 'pp'], [2, 2, 'RTR-2101', 'rtr'], [5, 1, 'SW-2103', 'sw'], [7, 2, 'STO-2201', 'sto'], [10, 1, 'SRV-2207', 'srv']] },
];
const FACE = {
  pp: { bg: '#E7EAF1', ink: '#1C2438', type: 'PC5-16RJ45' },
  rtr: { bg: 'oklch(0.48 0.14 275)', ink: '#fff', type: 'ASR1002-X' },
  fw: { bg: 'oklch(0.52 0.10 200)', ink: '#fff', type: 'FPR-2130' },
  sw: { bg: 'oklch(0.55 0.13 245)', ink: '#fff', type: 'C9300-48T' },
  srv: { bg: '#D7DCE6', ink: '#1C2438', type: 'DL380 G10' },
  sto: { bg: 'oklch(0.60 0.06 290)', ink: '#fff', type: 'MSA 2060' },
  ups: { bg: 'oklch(0.80 0.13 80)', ink: '#1C2438', type: 'SRT3000' },
};
const CABLE = 'M268 240 C268 196 327 186 327 135 C327 70 340 29 400 29 L700 29 C754 29 767 70 767 135 C767 186 708 196 708 240';
const PLUGS = [[268, 240, 0.01], [327, 135, 0.15], [767, 135, 0.85], [708, 240, 0.98]];
const TRACE = [
  ['RTR-1101 · Gi0/1', 'ASR1002-X · R04 / U39', 0.02],
  ['PC5-1002 · Port 12', 'PC5-16RJ45 · R04 / U42', 0.15],
  ['CBL-11873', 'Cat6A · 14 m', 0.5],
  ['PC5-2001 · Port 12', 'PC5-16RJ45 · R05 / U42', 0.85],
  ['RTR-2101 · Gi0/1', 'ASR1002-X · R05 / U39', 0.98],
];
function Device({ rx, s, k, T, K, cableP, dead }) {
  const [i, u, name, kind, isSel] = s;
  const top = UY + i * UH + 2, h = u * UH - 4, W = 256;
  const pin = tw(T, K.Ra + 3.5 + k * 0.14, K.Ra + 3.9 + k * 0.14, M.pop);
  const on = isSel ? Math.max(tw(T, K.Pr + 0.3, K.Pr + 0.7, M.enter) * (1 - tw(T, K.Ca, K.Ca + 0.5)), tw(T, K.Ca + 1.0, K.Ca + 1.4, M.enter)) : 0;
  const F = FACE[kind], left = rx < 300, dark = F.ink === '#fff';
  const hole = dark ? 'rgba(8,12,24,0.6)' : '#2A3248';
  const el = [];
  const port = (key, x, y, w, ph, lit) => el.push(<div key={key} style={{ position: 'absolute', left: x, top: y, width: w, height: ph, borderRadius: 2, background: lit ? CORAL : hole, boxShadow: lit ? `0 0 0 3px ${CORAL_S}` : 'none' }}></div>);
  const led = (key, x, y, seed, col = LED) => el.push(<div key={key} style={{ position: 'absolute', left: x, top: y, width: 6, height: 6, borderRadius: 3, background: dead && isSel ? CORAL : col, opacity: dead && isSel ? (Math.sin(T * 9) > 0 ? 1 : 0.25) : blink(T, seed + k) }}></div>);
  const bay = (key, x, y, w, bh) => el.push(<div key={key} style={{ position: 'absolute', left: x, top: y, width: w, height: bh, borderRadius: 3, background: dark ? 'rgba(255,255,255,0.18)' : '#B8C0CF', boxShadow: 'inset 0 -2px 0 rgba(0,0,0,0.12)' }}></div>);
  const label = (x, y, size) => el.push(<div key="nm" style={{ position: 'absolute', left: x, top: y, font: `600 ${size}px ${MONO}`, color: F.ink, whiteSpace: 'nowrap' }}>{name}</div>);
  const sub = (x, y) => el.push(<div key="tp" style={{ position: 'absolute', left: x, top: y, font: `500 11px ${SANS}`, color: F.ink, opacity: 0.75, whiteSpace: 'nowrap' }}>{F.type}</div>);
  if (kind === 'pp') {
    for (let j = 0; j < 16; j++) {
      el.push(<div key={'n' + j} style={{ position: 'absolute', left: 12 + j * 15, top: 1, width: 16, textAlign: 'center', font: `600 8px ${MONO}`, color: '#59627A' }}>{j + 1}</div>);
      port('p' + j, 14 + j * 15, 14, 12, 12, j === 11 && cableP > (left ? 0.15 : 0.85));
    }
  } else if (kind === 'rtr') {
    label(14, 10, 14); sub(14, 30);
    led('pw', 14, 56, 0.3); led('sy', 26, 56, 1.9, AMBER);
    for (let j = 0; j < 8; j++) { const px = 120 + j * 16 + (j > 3 ? 8 : 0); led('l' + j, px + 3, 28, j * 0.7); port('p' + j, px, 40, 12, 10, j === 0 && cableP > (left ? 0.01 : 0.97)); }
  } else if (kind === 'fw') {
    label(14, 10, 14); sub(14, 30); led('pw', 14, 56, 0.8);
    el.push(<div key="lcd" style={{ position: 'absolute', left: 130, top: 18, width: 66, height: 28, borderRadius: 4, background: '#0E1424', font: `600 12px ${MONO}`, color: LED, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>OK</div>);
    for (let j = 0; j < 5; j++) el.push(<div key={'v' + j} style={{ position: 'absolute', left: 210 + j * 8, top: 12, width: 4, height: 50, borderRadius: 2, background: 'rgba(8,12,24,0.35)' }}></div>);
  } else if (kind === 'sw') {
    label(8, 11, 10);
    for (let j = 0; j < 12; j++) { port('a' + j, 62 + j * 13, 6, 10, 8); port('b' + j, 62 + j * 13, 20, 10, 8); }
    for (let j = 0; j < 4; j++) port('s' + j, 222 + j * 8, 10, 6, 14);
  } else if (kind === 'srv') {
    label(8, 11, 10);
    for (let j = 0; j < 6; j++) { bay('b' + j, 66 + j * 28, 6, 24, 24); led('d' + j, 66 + j * 28 + 17, 9, j * 1.3, 'oklch(0.72 0.14 240)'); }
    el.push(<div key="pb" style={{ position: 'absolute', left: 238, top: 11, width: 12, height: 12, borderRadius: 6, border: `2px solid ${OKG}`, boxSizing: 'border-box' }}></div>);
  } else if (kind === 'sto') {
    label(14, 10, 14); sub(14, 30);
    for (let r2 = 0; r2 < 2; r2++) for (let j = 0; j < 6; j++) { bay(`b${r2}${j}`, 108 + j * 24, 6 + r2 * 34, 20, 28); led(`d${r2}${j}`, 108 + j * 24 + 7, 10 + r2 * 34, j + r2 * 3, 'oklch(0.85 0.12 240)'); }
  } else if (kind === 'ups') {
    label(14, 10, 14); sub(14, 30);
    el.push(<div key="lcd" style={{ position: 'absolute', left: 130, top: 16, width: 90, height: 36, borderRadius: 4, background: '#0E1424', padding: 7, boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: 5 }}><div style={{ font: `600 10px ${MONO}`, color: AMBER }}>100%</div><div style={{ height: 5, borderRadius: 3, background: AMBER }}></div></div>);
    led('a', 234, 20, 0.2); led('b', 234, 34, 1.1); led('c', 234, 48, 2.0, AMBER);
  }
  return (
    <div style={{ position: 'absolute', left: rx + 22, top, width: W, height: h, opacity: clampN(pin * 2), transform: `translateX(${(1 - pin) * 70}px)`, background: F.bg, borderRadius: 4, boxShadow: on ? `0 0 0 3px ${C.acc}, 0 0 26px ${C.glow || hc(LV.rack, 0.55)}` : 'inset 0 -3px 0 rgba(0,0,0,0.12), inset 0 1px 0 rgba(255,255,255,0.25)' }}>
      {el}
    </div>
  );
}
function Cabinet({ r, isKey, hiP, T }) {
  const rx = r.x;
  const holes = [];
  for (let k = 0; k < 14; k++) for (let q = 0; q < 3; q++) for (const hx of [rx + 11, rx + 283]) holes.push(<div key={k + '-' + q + '-' + hx} style={{ position: 'absolute', left: hx, top: UY + k * UH + 6 + q * 12, width: 5, height: 5, borderRadius: 1, background: CB.navy2 }}></div>);
  return (
    <>
      <svg width="1" height="1" style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible' }}>
        <polygon points={`${rx + 6},80 ${rx + 42},54 ${rx + 338},54 ${rx + 300},80`} fill={CB.navyTop} />
        <polygon points={`${rx + 300},80 ${rx + 338},54 ${rx + 338},680 ${rx + 300},706`} fill={CB.navy2} />
        {Array.from({ length: 9 }).map((_, k) => <line key={k} x1={rx + 310} y1={140 + k * 56} x2={rx + 328} y2={128 + k * 56} stroke={CB.navy3} strokeWidth="3" strokeLinecap="round" />)}
      </svg>
      <div style={{ position: 'absolute', left: rx, top: 80, width: 300, height: 626, background: CB.navy, borderRadius: '8px 0 6px 8px', boxShadow: isKey ? `0 0 0 ${lerp(0, 5, hiP)}px ${C.acc}` : 'none' }}></div>
      <div style={{ position: 'absolute', left: rx + 6, top: 110, width: 16, height: 566, borderRadius: 3, background: CB.navy3 }}></div>
      <div style={{ position: 'absolute', left: rx + 278, top: 110, width: 16, height: 566, borderRadius: 3, background: CB.navy3 }}></div>
      {holes}
      <div style={{ position: 'absolute', left: rx + 26, top: 92, width: 6, height: 6, borderRadius: 3, background: LED, opacity: blink(T, rx) }}></div>
      <div style={{ position: 'absolute', left: rx + 110, top: 86, width: 80, height: 20, borderRadius: 4, background: CB.navy3, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `600 13px ${MONO}`, color: '#fff' }}>{r.name}</div>
      {Array.from({ length: 14 }).map((_, k) => <div key={'u' + k} style={{ position: 'absolute', left: rx - 36, top: UY + k * UH + 11, width: 28, textAlign: 'right', font: `600 14px ${MONO}`, color: CB.dim }}>{42 - k}</div>)}
      <div style={{ position: 'absolute', left: rx + 30, top: 682, width: 240, height: 14, borderRadius: 3, background: `repeating-linear-gradient(90deg, ${CB.navy3} 0 6px, transparent 6px 11px)` }}></div>
      <div style={{ position: 'absolute', left: rx + 18, top: 706, width: 24, height: 10, borderRadius: '0 0 4px 4px', background: CB.navy2 }}></div>
      <div style={{ position: 'absolute', left: rx + 258, top: 706, width: 24, height: 10, borderRadius: '0 0 4px 4px', background: CB.navy2 }}></div>
    </>
  );
}


// ================= StableNet sequel =================
const SN_C = 'oklch(0.52 0.11 205)', SN_T = 'oklch(0.95 0.03 205)';
const GREY = '#A3A9B6';
const LIN = (x) => x;
function SNMark({ size = 52, col = SN_C }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size * 0.26, background: col, flex: 'none', position: 'relative' }}>
      <svg viewBox="0 0 52 52" width={size} height={size} style={{ position: 'absolute', inset: 0 }}>
        <polyline points="8,28 17,28 21,17 27,37 32,22 35,28 44,28" fill="none" stroke="#fff" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </div>
  );
}
function SNWordmark({ size = 96, mark = 70 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: size * 0.22 }}>
      <SNMark size={mark} />
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        <div style={{ font: `600 ${Math.round(size * 0.2)}px ${MONO}`, color: CB.dim, letterSpacing: 2, textTransform: 'uppercase' }}>Infosim</div>
        <div style={{ font: `600 ${size}px ${SANS}`, color: CB.text, letterSpacing: -size * 0.03, lineHeight: 1, whiteSpace: 'nowrap' }}>StableNet</div>
      </div>
    </div>
  );
}
function CmdMark({ size = 30 }) {
  return <div style={{ width: size, height: size, margin: size * 0.2, transform: 'rotate(45deg)', borderRadius: size * 0.16, background: `linear-gradient(135deg, ${hc(LV.city)}, ${hc(LV.rack)})`, flex: 'none' }}></div>;
}
function CmdWordmark({ size = 56, mark = 30 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: size * 0.3 }}>
      <CmdMark size={mark} />
      <div style={{ font: `600 ${size}px ${SANS}`, color: CB.text, letterSpacing: -size * 0.03, whiteSpace: 'nowrap' }}>FNT Command</div>
    </div>
  );
}
const Dot = ({ col, size = 14 }) => <div style={{ width: size, height: size, borderRadius: size / 2, background: col, flex: 'none' }}></div>;

const DEV = [
  { n: 'RTR-1101', t: 'Router', ip: '10.48.12.21', loc: 'R04 · U39–40' },
  { n: 'FW-1102', t: 'Firewall', ip: '10.48.12.22', loc: 'R04 · U36–37' },
  { n: 'SW-1103', t: 'Switch', ip: '10.48.12.23', loc: 'R04 · U35' },
  { n: 'SRV-1204', t: 'Server', ip: '10.48.12.34', loc: 'R04 · U33' },
  { n: 'SRV-1205', t: 'Server', ip: '10.48.12.35', loc: 'R04 · U32' },
  { n: 'RTR-2101', t: 'Router', ip: '10.48.12.41', loc: 'R05 · U39–40' },
];

// ---------- 1. Problem ----------
function Problem({ T, K }) {
  const t = T - K.Pb;
  if (T > K.So + 0.1) return null;
  const out = tw(T, K.So - 0.6, K.So);
  const card = tw(t, 0.3, 0.9, M.pop);
  const shift = tw(t, 4.8, 5.6);
  const rows = [['Where is it?', 'R04 · U39–40 · room 2.14', 1], ['What is it?', 'ASR1002-X · router', 1], ['Is it working?', 'Not known', 0]];
  const cons = [{ t: 'Outages reported by users first', icon: 'warn' }, { t: 'Devices added to monitoring by hand', icon: 'clock' }];
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: 1 - out }}>
      <div style={{ position: 'absolute', left: lerp(600, 200, shift), top: 250, width: 720, opacity: clampN(card * 2), transform: `scale(${lerp(0.8, 1, Math.min(1, card))})`, background: '#fff', borderRadius: 22, boxShadow: SHADOW, overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '22px 30px', borderBottom: `1px solid ${CB.line}` }}>
          <CmdMark size={28} />
          <div>
            <div style={{ font: `600 15px ${MONO}`, color: CB.dim, letterSpacing: 1.5, textTransform: 'uppercase' }}>FNT Command</div>
            <div style={{ font: `600 36px ${MONO}`, color: CB.text }}>RTR-1101</div>
          </div>
        </div>
        <div style={{ padding: '14px 18px 18px', display: 'flex', flexDirection: 'column', gap: 6 }}>
          {rows.map(([q, a, ok], i) => {
            const p = tw(t, 1.0 + i * 0.7, 1.4 + i * 0.7, M.enter);
            const bad = ok ? 0 : tw(t, 3.0, 3.4, M.enter);
            return (
              <div key={q} style={{ display: 'flex', alignItems: 'center', gap: 18, padding: '14px 16px', borderRadius: 14, background: mix('#ffffff', 'oklch(0.95 0.03 35)', bad), opacity: p, transform: `translateX(${(1 - p) * 16}px)` }}>
                {ok ? <Check size={34} /> : <div style={{ width: 34, height: 34, borderRadius: 17, background: CORAL, color: '#fff', font: `700 22px ${SANS}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 'none', transform: `scale(${1 + 0.3 * Math.sin(bad * Math.PI)})` }}>?</div>}
                <div style={{ font: `600 28px ${SANS}`, color: CB.text, flex: 1 }}>{q}</div>
                <div style={{ font: `500 22px ${ok ? MONO : SANS}`, color: ok ? CB.dim : CORAL_D, whiteSpace: 'nowrap' }}>{a}</div>
              </div>
            );
          })}
        </div>
      </div>
      {cons.map((c, i) => {
        const p = tw(t, 5.2 + i * 0.6, 5.7 + i * 0.6, M.pop);
        if (p <= 0) return null;
        return (
          <div key={c.t} style={{ position: 'absolute', left: 1010, top: 330 + i * 120, opacity: clampN(p * 2), transform: `scale(${lerp(0.6, 1, Math.min(1, p))})`, transformOrigin: 'left center', display: 'flex', alignItems: 'center', gap: 18, padding: '18px 30px 18px 20px', borderRadius: 18, background: '#fff', boxShadow: SHADOW }}>
            {c.icon === 'clock' ? <ClockIcon T={T} /> : <WarnIcon />}
            <div style={{ font: `600 30px ${SANS}`, color: CB.text, whiteSpace: 'nowrap' }}>{c.t}</div>
          </div>
        );
      })}
    </div>
  );
}

// ---------- 2. Solution ----------
const SN_BEN = ['Devices imported from Command', 'Monitored by ping and SNMP', 'Alarms with the exact location'];
function Solution({ T, K }) {
  const t = T - K.So;
  if (t < 0.2 || T > K.Im + 0.2) return null;
  const out = tw(T, K.Im - 0.7, K.Im);
  const logo = tw(t, 0.5, 1.2, M.pop);
  const burst = t > 0.6 && t < 1.7 ? (t - 0.6) / 1.1 : -1;
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: 1 - out, transform: `scale(${lerp(1, 0.94, out)})`, transformOrigin: '960px 540px' }}>
      {burst >= 0 && <div style={{ position: 'absolute', left: 960 - 80 - burst * 500, top: 400 - 80 - burst * 500, width: 160 + burst * 1000, height: 160 + burst * 1000, borderRadius: '50%', border: `4px solid ${SN_C}`, opacity: 1 - burst, boxSizing: 'border-box' }}></div>}
      <div style={{ position: 'absolute', left: 0, right: 0, top: 320, display: 'flex', justifyContent: 'center', opacity: clampN(logo * 2), transform: `scale(${lerp(0.6, 1, logo)})` }}><SNWordmark /></div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 580, display: 'flex', justifyContent: 'center', gap: 18 }}>
        {SN_BEN.map((b, i) => {
          const p = tw(t, 2.0 + i * 0.45, 2.4 + i * 0.45, M.pop);
          return (
            <div key={b} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 26px 14px 16px', borderRadius: 40, background: '#fff', boxShadow: SHADOW, opacity: clampN(p * 2), transform: `translateY(${(1 - Math.min(1, p)) * 20}px)` }}>
              <Check size={32} />
              <div style={{ font: `600 26px ${SANS}`, color: CB.text, whiteSpace: 'nowrap' }}>{b}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ---------- 3. Import ----------
const LP = 150, RP = 1130, PY = 170, PW = 640, HDR = 92, RHH = 56;
const rowY = (i) => PY + HDR + 12 + i * RHH + RHH / 2;
const HUB = [960, 400];
const bez = (a, c, b, p) => [(1 - p) * (1 - p) * a[0] + 2 * (1 - p) * p * c[0] + p * p * b[0], (1 - p) * (1 - p) * a[1] + 2 * (1 - p) * p * c[1] + p * p * b[1]];
const flyPath = (i) => { const a = [LP + PW, rowY(i)], b = [RP, rowY(i)]; return [a, [2 * HUB[0] - (a[0] + b[0]) / 2, 2 * HUB[1] - (a[1] + b[1]) / 2], b]; };
const MAPF = [['Hostname', 'ffm-rtr-1101'], ['Management IP', '10.48.12.21'], ['Location', 'WEU/DE/FFM · R04'], ['CORIA-ID', '41-17-06']];
function Panel({ x, o, head, children }) {
  return (
    <div style={{ position: 'absolute', left: x, top: PY, width: PW, opacity: o, transform: `translateY(${(1 - o) * 20}px)`, background: '#fff', borderRadius: 20, boxShadow: SHADOW, overflow: 'hidden', paddingBottom: 12 }}>
      <div style={{ height: HDR, boxSizing: 'border-box', display: 'flex', alignItems: 'center', gap: 16, padding: '0 26px', borderBottom: `1px solid ${CB.line}` }}>{head}</div>
      <div style={{ position: 'relative', height: DEV.length * RHH + 12 }}>{children}</div>
    </div>
  );
}
function Import({ T, K }) {
  const t = T - K.Im;
  if (t < -0.2 || T > K.Pi + 0.3) return null;
  const out = tw(T, K.Pi - 0.6, K.Pi);
  const po = tw(t, 0, 0.6, M.enter);
  const hub = tw(t, 0.6, 1.1, M.pop);
  const fs = (i) => 1.6 + i * 0.42;
  const map = tw(t, 5.0, 5.6, M.enter);
  const hubSpin = t * 120;
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: 1 - out }}>
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0 }}>
        {DEV.map((d, i) => { const [a, c, b] = flyPath(i); const p = tw(t, 0.8 + i * 0.06, 1.6 + i * 0.06); return <path key={d.n} d={`M${a[0]} ${a[1]} Q${c[0]} ${c[1]} ${b[0]} ${b[1]}`} fill="none" stroke={SN_C} strokeOpacity={0.22 * (1 - 0.6 * map)} strokeWidth="2.5" strokeDasharray="1 1" pathLength="1" strokeDashoffset={1 - p} />; })}
      </svg>
      <Panel x={LP} o={po} head={<><CmdMark size={28} /><div><div style={{ font: `600 14px ${MONO}`, color: CB.dim, letterSpacing: 1.5, textTransform: 'uppercase' }}>FNT Command</div><div style={{ font: `600 26px ${SANS}`, color: CB.text }}>Objects · Mainzer Landstrasse 151</div></div></>}>
        {DEV.map((d, i) => {
          const ro = tw(t, 0.3 + i * 0.08, 0.7 + i * 0.08, M.enter);
          const hi = i === 0 ? map : 0;
          return (
            <div key={d.n} style={{ position: 'absolute', left: 12, right: 12, top: 12 + i * RHH, height: RHH - 6, borderRadius: 10, padding: '0 16px', boxSizing: 'border-box', display: 'flex', alignItems: 'center', gap: 16, background: mix('#ffffff', tint(LV.rack), hi), opacity: ro * (1 - 0.55 * map * (i ? 1 : 0)) }}>
              <div style={{ font: `600 21px ${MONO}`, color: CB.text, width: 140 }}>{d.n}</div>
              <div style={{ font: `400 19px ${SANS}`, color: CB.dim, width: 110 }}>{d.t}</div>
              <div style={{ font: `500 19px ${MONO}`, color: CB.dim, flex: 1 }}>{d.ip}</div>
              <div style={{ font: `500 17px ${MONO}`, color: CB.faint, whiteSpace: 'nowrap' }}>{d.loc}</div>
            </div>
          );
        })}
      </Panel>
      <Panel x={RP} o={po} head={<><SNMark size={44} /><div><div style={{ font: `600 14px ${MONO}`, color: CB.dim, letterSpacing: 1.5, textTransform: 'uppercase' }}>StableNet</div><div style={{ font: `600 26px ${SANS}`, color: CB.text }}>Monitored devices</div></div></>}>
        {DEV.map((d, i) => {
          const arr = fs(i) + 0.8;
          const ro = tw(t, arr - 0.1, arr + 0.25, M.enter);
          const live = tw(t, arr + 0.9, arr + 1.2, M.enter);
          const hi = i === 0 ? map : 0;
          if (ro <= 0) return <div key={d.n} style={{ position: 'absolute', left: 12, right: 12, top: 12 + i * RHH, height: RHH - 6, borderRadius: 10, border: `2px dashed ${CB.line}`, boxSizing: 'border-box', opacity: po }}></div>;
          return (
            <div key={d.n} style={{ position: 'absolute', left: 12, right: 12, top: 12 + i * RHH, height: RHH - 6, borderRadius: 10, padding: '0 16px', boxSizing: 'border-box', display: 'flex', alignItems: 'center', gap: 16, background: mix('#ffffff', SN_T, Math.max(hi, (1 - live) * ro * 0.8)), opacity: ro * (1 - 0.55 * map * (i ? 1 : 0)) }}>
              <div style={{ font: `600 21px ${MONO}`, color: CB.text, width: 140 }}>{d.n}</div>
              <div style={{ font: `500 19px ${MONO}`, color: CB.dim, flex: 1 }}>{d.ip}</div>
              <Dot col={mix(GREY, OKG, live)} size={12} />
              <div style={{ font: `500 18px ${SANS}`, color: live > 0.5 ? deep(150) : CB.dim, width: 104 }}>{live > 0.5 ? 'Monitored' : 'Imported'}</div>
            </div>
          );
        })}
      </Panel>
      <div style={{ position: 'absolute', left: HUB[0] - 62, top: HUB[1] - 62, width: 124, height: 124, borderRadius: 62, background: '#fff', boxShadow: SHADOW, opacity: clampN(hub * 2), transform: `scale(${lerp(0.5, 1, Math.min(1, hub))})`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ position: 'absolute', inset: 10, borderRadius: '50%', border: `4px solid ${SN_T}`, borderTopColor: SN_C, transform: `rotate(${hubSpin}deg)`, boxSizing: 'border-box' }}></div>
        <ClockIcon T={T} />
      </div>
      <div style={{ position: 'absolute', left: HUB[0] - 150, width: 300, top: HUB[1] + 76, textAlign: 'center', opacity: clampN(hub * 2) * (1 - map) }}>
        <div style={{ font: `600 22px ${SANS}`, color: CB.text }}>Scheduled import</div>
        <div style={{ font: `500 17px ${MONO}`, color: CB.dim, marginTop: 4 }}>via database view</div>
      </div>
      {DEV.map((d, i) => {
        const p = tw(t, fs(i), fs(i) + 0.8, M.move);
        if (p <= 0 || p >= 1) return null;
        const [x, y] = bez(...flyPath(i), p);
        return <div key={d.n} style={{ position: 'absolute', left: x, top: y, transform: `translate(-50%, -50%) scale(${1 - 0.25 * Math.sin(p * Math.PI)})`, padding: '6px 14px', borderRadius: 20, background: SN_C, font: `600 18px ${MONO}`, color: '#fff', whiteSpace: 'nowrap', boxShadow: '0 6px 16px rgba(24,33,58,0.2)' }}>{d.n}</div>;
      })}
      {map > 0 && (
        <div style={{ position: 'absolute', left: 150, right: 150, top: 660, opacity: map, transform: `translateY(${(1 - map) * 20}px)`, background: '#fff', borderRadius: 20, boxShadow: SHADOW, padding: '22px 30px', display: 'flex', alignItems: 'center', gap: 30 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, flex: 'none' }}>
            <CmdMark size={22} />
            <div style={{ width: 46, height: 3, borderRadius: 2, background: `linear-gradient(90deg, ${hc(LV.rack)}, ${SN_C})` }}></div>
            <SNMark size={36} />
          </div>
          {MAPF.map(([l, v], i) => {
            const p = tw(t, 5.4 + i * 0.35, 5.8 + i * 0.35, M.enter);
            return (
              <div key={l} style={{ flex: 1, minWidth: 0, opacity: p, transform: `translateY(${(1 - p) * 10}px)` }}>
                <div style={{ font: `500 17px ${SANS}`, color: CB.dim }}>{l}</div>
                <div style={{ font: `600 23px ${MONO}`, color: CB.text, marginTop: 4, whiteSpace: 'nowrap' }}>{v}</div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ---------- 4–5. Ping & SNMP ----------
const SRVC = [470, 330], DEVC = [1450, 330], LX0 = 640, LX1 = 1280;
const series = (n, seed, base, amp) => Array.from({ length: n }, (_, i) => base + amp * (0.5 * Math.sin(i * 0.42 + seed) + 0.3 * Math.sin(i * 1.27 + seed * 2) + 0.2 * Math.sin(i * 2.9 + seed * 3)));
const S_IN = series(48, 1, 0.55, 0.3), S_OUT = series(48, 4, 0.3, 0.18), S_CPU = series(30, 2, 0.25, 0.12), S_MEM = series(30, 7, 0.42, 0.04);
const linePts = (s, w, h) => s.map((v, i) => `${((i / (s.length - 1)) * w).toFixed(1)},${(h - v * h).toFixed(1)}`).join(' ');
function NodeCard({ cx, cy, o, children }) {
  return <div style={{ position: 'absolute', left: cx - 170, top: cy - 62, width: 340, height: 124, boxSizing: 'border-box', opacity: o, transform: `scale(${lerp(0.8, 1, o)})`, background: '#fff', borderRadius: 20, boxShadow: SHADOW, display: 'flex', alignItems: 'center', gap: 18, padding: '0 24px' }}>{children}</div>;
}
function MiniRouter({ T, dead }) {
  return (
    <div style={{ width: 70, height: 46, borderRadius: 6, background: FACE.rtr.bg, position: 'relative', flex: 'none' }}>
      {[0, 1, 2, 3].map((k) => <div key={k} style={{ position: 'absolute', left: 30 + k * 9, top: 26, width: 6, height: 7, borderRadius: 1, background: 'rgba(8,12,24,0.6)' }}></div>)}
      <div style={{ position: 'absolute', left: 8, top: 10, width: 6, height: 6, borderRadius: 3, background: dead ? CORAL : LED, opacity: dead ? 1 : blink(T, 1) }}></div>
      <div style={{ position: 'absolute', left: 18, top: 10, width: 6, height: 6, borderRadius: 3, background: dead ? CORAL : AMBER, opacity: dead ? 0.4 : blink(T, 3) }}></div>
    </div>
  );
}
function Tile({ x, w, o, label, value, children }) {
  return (
    <div style={{ position: 'absolute', left: x, top: 490, width: w, height: 300, boxSizing: 'border-box', opacity: o, transform: `translateY(${(1 - o) * 24}px)`, background: '#fff', borderRadius: 20, boxShadow: SHADOW, padding: '22px 26px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 12 }}>
        <div style={{ font: `500 19px ${SANS}`, color: CB.dim, whiteSpace: 'nowrap' }}>{label}</div>
        <div style={{ font: `600 26px ${MONO}`, color: CB.text, whiteSpace: 'nowrap' }}>{value}</div>
      </div>
      <div style={{ position: 'absolute', left: 26, right: 26, bottom: 26, height: 170 }}>{children}</div>
    </div>
  );
}
const SNMP_Q = [['GET ifHCInOctets · Gi0/1', '412 Mbit/s'], ['GET CPU load', '23 %'], ['GET memory used', '41 %'], ['GET ifOperStatus · Gi0/1', 'up']];
function Monitor({ T, K }) {
  const t = T - K.Pi, t2 = T - K.Sn;
  if (t < -0.2 || T > K.To + 0.3) return null;
  const out = tw(T, K.To - 0.6, K.To);
  const nodes = tw(t, 0, 0.6, M.enter);
  const link = tw(t, 0.4, 1.0);
  const snmp = tw(t2, 0, 0.6);
  const avail = tw(t, 0.9, 1.4, M.enter) * (1 - snmp);
  const fill = tw(t, 1.3, 6.2, LIN);
  const pk = [];
  if (t2 < 0) {
    for (let k = 0; k < 6; k++) {
      const s = 1.0 + k * 1.0, p = tw(t, s, s + 0.45, LIN), q = tw(t, s + 0.5, s + 0.95, LIN);
      if (p > 0 && p < 1) pk.push({ k: 'e' + k, x: lerp(LX0, LX1, p), y: 312, col: SN_C, lab: k === 0 ? 'ICMP echo' : null });
      if (q > 0 && q < 1) pk.push({ k: 'r' + k, x: lerp(LX1, LX0, q), y: 348, col: OKG, lab: k === 0 ? 'reply · 2 ms' : null, below: 1 });
    }
  } else {
    for (let k = 0; k < 5; k++) {
      const s = 0.6 + k * 1.6, p = tw(t2, s, s + 0.6, LIN), q = tw(t2, s + 0.7, s + 1.3, LIN);
      const [qq, a] = SNMP_Q[k % SNMP_Q.length];
      if (p > 0 && p < 1) pk.push({ k: 'g' + k, x: lerp(LX0, LX1, p), y: 312, col: SN_C, lab: qq, sq: 1 });
      if (q > 0 && q < 1) pk.push({ k: 'v' + k, x: lerp(LX1, LX0, q), y: 348, col: OKG, lab: a, below: 1, sq: 1 });
    }
  }
  const bars = 72, filled = Math.floor(bars * fill);
  const chart = (i) => tw(t2, 1.2 + i * 0.4, 4.4 + i * 0.4, M.move);
  const thr = tw(t2, 5.4, 5.9, M.enter);
  const chip = tw(t2, 0.8, 1.3, M.enter);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: 1 - out }}>
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0 }}>
        <line x1={LX0} y1="330" x2={lerp(LX0, LX1, link)} y2="330" stroke={CB.line2} strokeWidth="4" strokeLinecap="round" strokeDasharray="2 12" />
      </svg>
      <NodeCard cx={SRVC[0]} cy={SRVC[1]} o={nodes}>
        <SNMark size={64} />
        <div><div style={{ font: `600 26px ${SANS}`, color: CB.text }}>StableNet</div><div style={{ font: `500 18px ${SANS}`, color: CB.dim }}>Monitoring server</div></div>
      </NodeCard>
      <NodeCard cx={DEVC[0]} cy={DEVC[1]} o={nodes}>
        <MiniRouter T={T} />
        <div><div style={{ font: `600 26px ${MONO}`, color: CB.text }}>RTR-1101</div><div style={{ font: `500 18px ${MONO}`, color: CB.dim }}>10.48.12.21</div></div>
      </NodeCard>
      {pk.map((p) => (
        <div key={p.k} style={{ position: 'absolute', left: p.x, top: p.y }}>
          <div style={{ position: 'absolute', left: -9, top: -9, width: 18, height: 18, borderRadius: p.sq ? 4 : 9, background: p.col, boxShadow: `0 0 0 6px ${p.col.replace(')', ' / 0.2)')}` }}></div>
          {p.lab && <div style={{ position: 'absolute', left: 0, top: p.below ? 22 : -22, transform: `translate(-50%, ${p.below ? 0 : -100}%)`, padding: '4px 12px', borderRadius: 14, background: '#fff', font: `600 17px ${MONO}`, color: CB.text, whiteSpace: 'nowrap', boxShadow: '0 2px 8px rgba(24,33,58,0.12)' }}>{p.lab}</div>}
        </div>
      ))}
      {chip > 0 && <div style={{ position: 'absolute', left: 960, top: 196, transform: 'translateX(-50%)', opacity: chip, display: 'flex', alignItems: 'center', gap: 10, padding: '8px 18px 8px 12px', borderRadius: 30, background: SN_T, font: `600 19px ${SANS}`, color: deep(205), whiteSpace: 'nowrap' }}><Dot col={SN_C} size={10} />Polled every 5 min</div>}
      {avail > 0 && (
        <div style={{ position: 'absolute', left: 300, top: 490, width: 1320, boxSizing: 'border-box', opacity: avail, transform: `translateY(${(1 - avail) * 24}px)`, background: '#fff', borderRadius: 20, boxShadow: SHADOW, padding: '26px 32px' }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 40 }}>
            <div style={{ font: `500 20px ${SANS}`, color: CB.dim, flex: 1 }}>Availability · RTR-1101 · last 24 h</div>
            <div style={{ font: `500 20px ${SANS}`, color: CB.dim }}>Round trip <span style={{ font: `600 26px ${MONO}`, color: CB.text }}>2 ms</span></div>
            <div style={{ font: `600 40px ${MONO}`, color: deep(150) }}>{(fill > 0 ? 100 : 0).toFixed(2)} %</div>
          </div>
          <div style={{ display: 'flex', gap: 4, marginTop: 22, height: 70, alignItems: 'flex-end' }}>
            {Array.from({ length: bars }).map((_, i) => <div key={i} style={{ flex: 1, height: i < filled ? 70 : 20, borderRadius: 3, background: i < filled ? OKG : CB.line }}></div>)}
          </div>
        </div>
      )}
      {snmp > 0 && (
        <>
          <Tile x={300} w={700} o={tw(t2, 0.4, 1.0, M.enter)} label="Traffic · Gi0/1" value="412 / 188 Mbit/s">
            <svg width="648" height="170" style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
              {[0, 1, 2].map((k) => <line key={k} x1="0" x2="648" y1={k * 85} y2={k * 85} stroke={CB.line} strokeWidth="1.5" />)}
              <polyline points={linePts(S_IN, 648, 170)} fill="none" stroke={SN_C} strokeWidth="4" strokeLinejoin="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - chart(0)} />
              <polyline points={linePts(S_OUT, 648, 170)} fill="none" stroke={hc(LV.city)} strokeWidth="4" strokeLinejoin="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - chart(0)} />
            </svg>
          </Tile>
          {[['CPU', '23 %', S_CPU, 1030], ['Memory', '41 %', S_MEM, 1340]].map(([l, v, s, x], i) => (
            <Tile key={l} x={x} w={280} o={tw(t2, 0.6 + i * 0.2, 1.2 + i * 0.2, M.enter)} label={l} value={v}>
              <svg width="228" height="170" style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
                {i === 0 && thr > 0 && <g opacity={thr}><line x1="0" x2="228" y1={170 * 0.2} y2={170 * 0.2} stroke={AMBER} strokeWidth="3" strokeDasharray="8 6" /><text x="228" y={170 * 0.2 - 10} textAnchor="end" style={{ font: `600 15px ${MONO}`, fill: 'oklch(0.55 0.12 75)' }}>warning · 80 %</text></g>}
                <polyline points={linePts(s, 228, 170)} fill="none" stroke={SN_C} strokeWidth="4" strokeLinejoin="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - chart(i + 1)} />
              </svg>
            </Tile>
          ))}
        </>
      )}
    </div>
  );
}

// ---------- 6–7. Topology & fault ----------
const TOPO = [
  { n: 'RTR-2101', t: 'Router · R05', x: 330, y: 470 },
  { n: 'RTR-1101', t: 'Router · R04', x: 700, y: 470, root: 1 },
  { n: 'FW-1102', t: 'Firewall · R04', x: 1040, y: 470, dep: 1 },
  { n: 'SW-1103', t: 'Switch · R04', x: 1360, y: 470, dep: 1 },
  { n: 'SRV-1204', t: 'Server · R04', x: 1650, y: 330, dep: 1 },
  { n: 'SRV-1205', t: 'Server · R04', x: 1650, y: 610, dep: 1 },
];
const TLINKS = [[0, 1], [1, 2], [2, 3], [3, 4], [3, 5]];
function Topology({ T, K }) {
  const t = T - K.To, tf = T - K.Fa;
  if (t < -0.2 || T > K.Lo + 1.0) return null;
  const out = tw(T, K.Lo, K.Lo + 0.8);
  const down = tw(tf, 2.0, 2.4, M.enter);
  const dep = tw(tf, 4.2, 4.7, M.enter);
  const hd = tw(t, 0.2, 0.7, M.enter);
  const cnt = [['Up', Math.round(lerp(lerp(6, 5, down), 1, dep)), OKG], ['Critical', down > 0.5 ? 1 : 0, CORAL], ['Unreachable', dep > 0.5 ? 4 : 0, GREY]];
  const fails = [0.4, 1.0, 1.6].map((s) => tw(tf, s, s + 0.35, M.pop) * (1 - tw(tf, s + 0.5, s + 0.8)));
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: 1 - out, transform: `scale(${lerp(1, 0.94, out)})`, transformOrigin: '960px 500px' }}>
      <div style={{ position: 'absolute', left: 140, right: 140, top: 150, display: 'flex', alignItems: 'center', gap: 16, opacity: hd, transform: `translateY(${(1 - hd) * -12}px)` }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: `600 15px ${MONO}`, color: CB.dim, letterSpacing: 1.5, textTransform: 'uppercase' }}>WEU/DE/FFM · Room 2.14</div>
          <div style={{ font: `600 34px ${SANS}`, color: CB.text, whiteSpace: 'nowrap' }}>Mainzer Landstrasse 151</div>
        </div>
        {cnt.map(([l, v, c]) => (
          <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 22px 10px 16px', borderRadius: 40, background: '#fff', boxShadow: '0 4px 14px rgba(24,33,58,0.10)', opacity: l === 'Up' || v > 0 ? 1 : 0.55 }}>
            <Dot col={c} />
            <div style={{ font: `500 20px ${SANS}`, color: CB.dim }}>{l}</div>
            <div style={{ font: `600 26px ${MONO}`, color: CB.text, minWidth: 18, textAlign: 'right' }}>{v}</div>
          </div>
        ))}
      </div>
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0 }}>
        {TLINKS.map(([a, b], k) => {
          const A = TOPO[a], B = TOPO[b];
          const p = tw(t, 0.6 + k * 0.15, 1.2 + k * 0.15);
          const bad = a === 0 ? down : dep;
          const d = `M${A.x} ${A.y} C${(A.x + B.x) / 2} ${A.y} ${(A.x + B.x) / 2} ${B.y} ${B.x} ${B.y}`;
          return (
            <g key={k}>
              <path d={d} fill="none" stroke={mix(SN_C, a === 0 ? CORAL : GREY, bad)} strokeOpacity={lerp(0.55, 0.8, bad)} strokeWidth="4" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - p} />
              {p >= 1 && bad < 0.5 && b !== 1 && <path d={d} fill="none" stroke={SN_C} strokeWidth="10" strokeLinecap="round" pathLength="1" strokeDasharray="0.001 0.999" strokeDashoffset={-((T * 0.4 + k * 0.3) % 1)} />}
              {p >= 1 && a === 0 && down < 0.5 && <path d={d} fill="none" stroke={SN_C} strokeWidth="10" strokeLinecap="round" pathLength="1" strokeDasharray="0.001 0.999" strokeDashoffset={-((T * 0.4) % 1)} />}
            </g>
          );
        })}
      </svg>
      {TOPO.map((n, i) => {
        const o = tw(t, 0.3 + i * 0.12, 0.8 + i * 0.12, M.pop);
        const st = n.root ? down : n.dep ? dep : 0;
        const col = n.root ? mix(OKG, CORAL, down) : n.dep ? mix(OKG, GREY, dep) : OKG;
        const pulse = n.root && down > 0 ? ((tf - 2.0) % 1.1) / 1.1 : -1;
        return (
          <div key={n.n} style={{ position: 'absolute', left: n.x, top: n.y, opacity: clampN(o * 2) * (n.dep ? lerp(1, 0.75, dep) : 1), transform: `translate(-50%, -50%) scale(${lerp(0.7, 1, Math.min(1, o))})` }}>
            {pulse >= 0 && <div style={{ position: 'absolute', left: -10 - pulse * 40, top: -10 - pulse * 40, right: -10 - pulse * 40, bottom: -10 - pulse * 40, borderRadius: 24 + pulse * 20, border: `3px solid ${CORAL}`, opacity: 1 - pulse }}></div>}
            <div style={{ width: 240, height: 88, boxSizing: 'border-box', borderRadius: 18, background: n.root ? mix('#ffffff', 'oklch(0.95 0.035 35)', down) : '#fff', boxShadow: n.root && down > 0 ? `0 0 0 3px ${CORAL}, ${SHADOW}` : SHADOW, display: 'flex', alignItems: 'center', gap: 14, padding: '0 20px' }}>
              <Dot col={col} size={16} />
              <div style={{ minWidth: 0 }}>
                <div style={{ font: `600 23px ${MONO}`, color: st > 0.5 && n.dep ? CB.dim : CB.text }}>{n.n}</div>
                <div style={{ font: `500 16px ${SANS}`, color: st > 0.5 ? (n.root ? CORAL_D : CB.dim) : CB.dim, whiteSpace: 'nowrap' }}>{st > 0.5 ? (n.root ? 'Down · no ping reply' : 'Unreachable') : n.t}</div>
              </div>
            </div>
            {n.root && fails.map((f, k) => (f > 0 ? <div key={k} style={{ position: 'absolute', left: 120 + (k - 1) * 46, top: -40, transform: `translate(-50%, -50%) scale(${f})`, width: 34, height: 34, borderRadius: 17, background: CORAL, color: '#fff', font: `700 22px ${SANS}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>×</div> : null))}
          </div>
        );
      })}
    </div>
  );
}

// ---------- Alarm card (fault → locate) ----------
const LOCP = [['City', 'WEU/DE/FFM', LV.city], ['Building', 'Mainzer Landstrasse 151', LV.bldg], ['Floor', '2', LV.floor], ['Room', '2.14', LV.room], ['Rack', 'R04 · U39–40', LV.rack]];
function AlarmCard({ T, K, end }) {
  const tf = T - K.Fa, tl = T - K.Lo;
  const o = tw(tf, 2.6, 3.1, M.pop);
  if (o <= 0 || T > K.Cl + 0.6) return null;
  const out = tw(T, K.Cl, K.Cl + 0.6);
  const up = tw(tl, 0, 1.0, M.move);
  const dep = tw(tf, 4.4, 4.9, M.enter) * (1 - tw(tl, 0.6, 1.0));
  const loc = tw(tl, 1.0, 1.4, M.enter);
  return (
    <div style={{ position: 'absolute', left: 160, right: 160, top: lerp(700, 110, up), opacity: clampN(o * 2) * (1 - out), transform: `scale(${lerp(0.85, 1, Math.min(1, o))})`, background: '#fff', borderRadius: 22, boxShadow: SHADOW, overflow: 'hidden' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 20, padding: '20px 28px', borderLeft: `0 solid ${CORAL}` }}>
        <div style={{ padding: '6px 14px', borderRadius: 10, background: CORAL, font: `700 18px ${MONO}`, color: '#fff', letterSpacing: 1.5 }}>CRITICAL</div>
        <div style={{ font: `600 30px ${SANS}`, color: CB.text, flex: 1, whiteSpace: 'nowrap' }}><span style={{ fontFamily: MONO }}>RTR-1101</span> not responding to ping</div>
        <div style={{ font: `500 20px ${MONO}`, color: CB.dim, whiteSpace: 'nowrap' }}>since 14:32:10 · 3 missed polls</div>
      </div>
      <div style={{ position: 'relative', height: lerp(0, 64, Math.max(dep, loc)), borderTop: `1px solid ${CB.line}`, overflow: 'hidden' }}>
        <div style={{ position: 'absolute', left: 28, top: 16, display: 'flex', alignItems: 'center', gap: 12, opacity: dep, font: `500 22px ${SANS}`, color: CB.dim, whiteSpace: 'nowrap' }}>
          <Dot col={GREY} size={12} />4 dependent devices marked unreachable · root cause <span style={{ font: `600 22px ${MONO}`, color: CB.text }}>RTR-1101</span>
        </div>
        <div style={{ position: 'absolute', left: 28, top: 10, display: 'flex', alignItems: 'center', gap: 10, opacity: loc }}>
          <CmdMark size={18} />
          <div style={{ font: `500 18px ${SANS}`, color: CB.dim, marginRight: 8, whiteSpace: 'nowrap' }}>Location from FNT Command</div>
          {LOCP.map(([l, v, h], i) => {
            const p = tw(tl, 1.2 + i * 0.22, 1.6 + i * 0.22, M.pop);
            return (
              <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 10, opacity: clampN(p * 2), transform: `scale(${lerp(0.7, 1, Math.min(1, p))})` }}>
                {i > 0 && <div style={{ width: 12, height: 3, borderRadius: 2, background: CB.line2 }}></div>}
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 14px 6px 10px', borderRadius: 30, background: tint(h) }}>
                  <Dot col={hc(h)} size={10} />
                  <div style={{ font: `600 19px ${MONO}`, color: deep(h), whiteSpace: 'nowrap' }}>{v}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ---------- 8. Locate in rack ----------
const FAULT_TRACE = [['RTR-1101 · Gi0/1', 'Down · R04 / U39–40'], ['PC5-1002 · Port 12', 'Patch panel · R04 / U42'], ['CBL-11873', 'Cat6A · 14 m'], ['RTR-2101 · Gi0/1', 'Far end · R05 / U39–40']];
function Locate({ T, K }) {
  const tl = T - K.Lo;
  if (tl < 1.4 || T > K.Cl + 0.8) return null;
  useHue(LV.rack);
  C = { ...C, acc: CORAL, glow: 'oklch(0.66 0.18 35 / 0.55)' };
  const o = tw(tl, 1.6, 2.4, M.enter) * (1 - tw(T, K.Cl, K.Cl + 0.7));
  const K2 = { Ra: K.Lo + 2.0 - 3.5, Pr: K.Lo + 2.6, Ca: 1e9 };
  const cableP = tw(tl, 5.0, 7.6, M.move);
  const r5 = tw(tl, 4.2, 4.8, M.enter);
  const card = tw(tl, 4.6, 5.2, M.enter);
  const tray = tw(tl, 4.6, 5.0, M.enter);
  const ths = [0.02, 0.15, 0.5, 0.98];
  return (
    <div style={{ position: 'absolute', left: 420, top: 300, width: 1360, height: 744, transform: `scale(${lerp(0.74, 0.8, o)})`, transformOrigin: '0 0', opacity: o }}>
      <div style={{ position: 'absolute', left: 290, top: 20, width: 540, height: 18, borderRadius: 9, background: 'repeating-linear-gradient(90deg, #C3C9D6 0 4px, #DDE1E9 4px 22px)', border: '2px solid #B4BBCA', boxSizing: 'border-box', opacity: tray, transform: `scaleX(${tray})`, transformOrigin: 'left' }}></div>
      {RACKS.map((r, ri) => (
        <div key={r.name} style={{ opacity: ri ? r5 : 1 }}>
          <Cabinet r={r} isKey={!ri} hiP={1} T={T} />
          {r.slots.map((s, k) => <Device key={s[2]} rx={r.x} s={s} k={k + ri * 2} T={T} K={K2} cableP={cableP} dead />)}
          <div style={{ position: 'absolute', left: r.x, top: 726, width: 300, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 10 }}>
            <div style={{ padding: '4px 16px', borderRadius: 16, background: ri ? '#fff' : CORAL, color: ri ? CB.text : '#fff', font: `600 22px ${MONO}`, boxShadow: '0 2px 8px rgba(24,33,58,0.1)' }}>{r.name}</div>
            <div style={{ font: `500 17px ${SANS}`, color: CB.dim }}>RITTAL-42 · 42 U</div>
          </div>
        </div>
      ))}
      <svg width="1360" height="744" style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
        <path d={CABLE} fill="none" stroke={CORAL_S} strokeWidth="18" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - cableP} />
        <path d={CABLE} fill="none" stroke={CORAL_D} strokeWidth="8" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - cableP} />
        <path d={CABLE} fill="none" stroke={CORAL} strokeWidth="5" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - cableP} />
        {PLUGS.map(([x, y, th], i) => (cableP > th ? <rect key={i} x={x - 7} y={y - 8} width="14" height="16" rx="3" fill={CORAL_D} stroke="#fff" strokeWidth="1.5" /> : null))}
      </svg>
      <div style={{ position: 'absolute', left: 950, top: 80, width: 420, opacity: card, transform: `translateY(${(1 - card) * 20}px)`, background: '#fff', borderRadius: 18, padding: '26px 28px 10px', boxSizing: 'border-box', boxShadow: SHADOW }}>
        <div style={{ font: `600 17px ${MONO}`, color: CORAL_D, letterSpacing: 1.5, textTransform: 'uppercase' }}>Check on site</div>
        <div style={{ position: 'relative', marginTop: 22 }}>
          <div style={{ position: 'absolute', left: 8, top: 10, width: 4, height: 3 * 92, borderRadius: 2, background: CB.line }}></div>
          <div style={{ position: 'absolute', left: 8, top: 10, width: 4, height: 3 * 92 * cableP, borderRadius: 2, background: CORAL }}></div>
          {FAULT_TRACE.map(([a, b], i) => {
            const lit = tw(tl, 5.0 + ths[i] * 2.6, 5.3 + ths[i] * 2.6, M.enter);
            return (
              <div key={i} style={{ position: 'relative', height: 92, paddingLeft: 38 }}>
                <div style={{ position: 'absolute', left: 0, top: 2, width: 20, height: 20, borderRadius: 10, background: lit > 0.5 ? CORAL : '#fff', border: `3px solid ${lit > 0.5 ? CORAL : CB.line2}`, boxSizing: 'border-box', transform: `scale(${1 + 0.35 * Math.sin(lit * Math.PI)})` }}></div>
                <div style={{ font: `600 23px ${MONO}`, color: lit > 0.5 ? CB.text : CB.faint }}>{a}</div>
                <div style={{ font: `400 19px ${SANS}`, color: CB.dim, marginTop: 4, opacity: 0.4 + 0.6 * lit }}>{b}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ---------- 9. Close ----------
function Close({ T, K, end }) {
  const t = T - K.Cl;
  if (t < 0.4) return null;
  const fade = 1 - tw(T, end - 0.7, end - 0.05);
  const cards = [[<CmdWordmark size={50} mark={28} />, 'Where it is · What it is', 560], [<SNWordmark size={50} mark={52} />, "Whether it's working", 1360]];
  const ar = tw(t, 1.6, 2.4, M.move);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: fade }}>
      {cards.map(([mark, d, cx], i) => {
        const p = tw(t, 0.6 + i * 0.5, 1.2 + i * 0.5, M.pop);
        return (
          <div key={d} style={{ position: 'absolute', left: cx - 280, top: 330, width: 560, height: 250, boxSizing: 'border-box', background: '#fff', borderRadius: 26, boxShadow: SHADOW, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 26, opacity: clampN(p * 2), transform: `translateY(${(1 - Math.min(1, p)) * 30}px)` }}>
            {mark}
            <div style={{ font: `500 28px ${SANS}`, color: CB.dim }}>{d}</div>
          </div>
        );
      })}
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0 }}>
        <line x1="870" y1="455" x2={lerp(870, 1030, ar)} y2="455" stroke={SN_C} strokeWidth="5" strokeLinecap="round" />
        {ar >= 1 && <polygon points="1030,443 1050,455 1030,467" fill={SN_C} />}
        {ar >= 1 && [0, 0.5].map((ph) => <circle key={ph} cx={870 + ((T * 0.6 + ph) % 1) * 160} cy="455" r="6" fill="#fff" />)}
      </svg>
      <div style={{ position: 'absolute', left: 860, width: 200, top: 490, textAlign: 'center', font: `500 19px ${SANS}`, color: CB.dim, opacity: ar }}>Scheduled import</div>
    </div>
  );
}

// ---------- overlays ----------
function SceneTag({ T, K }) {
  const tags = [[K.Im, K.Pi, 'Inventory import'], [K.Pi, K.Sn, 'Availability · ping'], [K.Sn, K.To, 'Performance · SNMP'], [K.To, K.Fa, 'Topology & dashboards'], [K.Fa, K.Lo, 'Alarms']];
  return (
    <>
      {tags.map(([a, b, l]) => {
        const o = tw(T, a + 0.2, a + 0.6, M.enter) * (1 - tw(T, b - 0.3, b));
        if (o <= 0) return null;
        return (
          <div key={l} style={{ position: 'absolute', right: 60, top: 46, opacity: o, transform: `translateY(${(1 - o) * -12}px)`, display: 'flex', alignItems: 'center', gap: 14, padding: '10px 22px 10px 12px', borderRadius: 40, background: '#fff', boxShadow: '0 4px 14px rgba(24,33,58,0.10)' }}>
            <SNMark size={40} />
            <div style={{ display: 'flex', flexDirection: 'column' }}>
              <div style={{ font: `600 13px ${MONO}`, color: CB.dim, letterSpacing: 1.5, textTransform: 'uppercase' }}>StableNet</div>
              <div style={{ font: `600 21px ${SANS}`, color: CB.text, whiteSpace: 'nowrap' }}>{l}</div>
            </div>
          </div>
        );
      })}
    </>
  );
}

function Piece({ tweaks }) {
  const { T, CUES, authoredTotal } = useComposition();
  C = CB;
  const K = { Pb: CUES.Problem, So: CUES.Solution, Im: CUES.Import, Pi: CUES.Ping, Sn: CUES.SNMP, To: CUES.Topology, Fa: CUES.Fault, Lo: CUES.Locate, Cl: CUES.Close };
  const end = authoredTotal;
  const caps = [
    { at: K.Pb + 0.4, text: "FNT Command knows where every device is and what it is. It doesn't tell you whether it's working." },
    { at: K.Pb + 5.0, text: 'Without monitoring, users report outages first, and new devices are added to monitoring by hand.' },
    { at: K.So + 0.5, text: 'Infosim StableNet monitors the network, using the inventory already documented in FNT Command.' },
    { at: K.Im + 0.3, text: 'On a schedule, StableNet imports devices from a Command database view.' },
    { at: K.Im + 5.0, text: 'Hostname, management IP, location and CORIA-ID come across, so nothing is entered twice.' },
    { at: K.Pi + 0.3, text: 'StableNet pings each management IP to check that the device is reachable.' },
    { at: K.Pi + 4.0, text: 'Every reply is recorded, building an availability history.' },
    { at: K.Sn + 0.3, text: 'Over SNMP it polls interface traffic and status, CPU and memory.' },
    { at: K.Sn + 5.0, text: 'Each value is stored as a measurement, with thresholds that raise warnings.' },
    { at: K.To + 0.3, text: 'Dashboards and topology maps show the status of every site at a glance.' },
    { at: K.Fa + 0.3, text: 'When RTR-1101 stops answering ping, StableNet raises a critical alarm.' },
    { at: K.Fa + 4.2, text: 'Devices behind it are marked unreachable, so the alarm points at the root cause.' },
    { at: K.Lo + 0.3, text: 'Because the data comes from Command, the alarm already carries the exact location.' },
    { at: K.Lo + 5.0, text: 'The engineer goes straight to rack R04, unit 39, and the cable on patch port 12.' },
    { at: K.Cl + 0.4, until: end - 0.5, text: "FNT Command documents where it is and what it is. StableNet shows whether it's working." },
  ];
  const fade = 1 - tw(T, end - 0.7, end - 0.05);
  const gh = nh(kf(T, [[K.So, 290], [K.So + 1, 205], [K.Fa + 1.5, 205], [K.Fa + 2.5, 395], [K.Cl, 395], [K.Cl + 1, 565]])[0]);
  return (
    <div data-screen-label={`t=${Math.floor(T)}s`} style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: CB.bg }}>
      <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(ellipse 65% 60% at 50% 50%, oklch(0.93 0.05 ${gh.toFixed(1)}), transparent 75%)` }}></div>
      <div style={{ position: 'absolute', inset: -40, backgroundImage: 'radial-gradient(circle, #DDD8CD 1.4px, transparent 1.8px)', backgroundSize: '40px 40px', transform: `translate(${(T * 3) % 40}px, ${(T * 1.5) % 40}px)` }}></div>
      <div style={{ position: 'absolute', inset: 0, opacity: fade }}>
        <Problem T={T} K={K} />
        <Solution T={T} K={K} />
        <Import T={T} K={K} />
        <Monitor T={T} K={K} />
        <Topology T={T} K={K} />
        <Locate T={T} K={K} />
        <AlarmCard T={T} K={K} end={end} />
      </div>
      <SceneTag T={T} K={K} />
      <Close T={T} K={K} end={end} />
      {tweaks.captions !== false && (
        <Captions items={caps} style={{ left: '50%', right: 'auto', bottom: 40, transform: 'translateX(-50%)', width: 'max-content', maxWidth: 1560, padding: '14px 30px', borderRadius: 14, background: 'rgba(24,33,58,0.94)', font: `500 34px ${SANS}`, color: '#F4F2EE', textShadow: 'none', lineHeight: 1.3, textAlign: 'center' }} />
      )}
    </div>
  );
}

function SNVideo() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <>
      <CompositionStage width={1920} height={1080} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#F4F2EE">
        <Piece tweaks={t} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Playback" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        <TweakToggle label="Captions" value={t.captions} onChange={(v) => setTweak('captions', v)} />
      </TweaksPanel>
    </>
  );
}

window.SNVideo = SNVideo;

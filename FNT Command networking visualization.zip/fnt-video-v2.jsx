const { Easing, useComposition, CompositionStage, Captions } = window;

const M = { enter: Easing.easeOutCubic, move: Easing.easeInOutCubic, pop: Easing.easeOutBack };
const tw = (T, a, b, e = M.move) => (T <= a ? 0 : T >= b ? 1 : e((T - a) / (b - a)));
const lerp = (a, b, p) => a + (b - a) * p;
const clampN = (v) => Math.max(0, Math.min(1, v));
const mix = (a, b, p) => `color-mix(in oklch, ${b} ${Math.round(clampN(p) * 100)}%, ${a})`;
function kf(T, fr, e = M.move) {
  if (T <= fr[0][0]) return fr[0].slice(1);
  for (let i = 0; i < fr.length - 1; i++) {
    const a = fr[i], b = fr[i + 1];
    if (T < b[0]) { const p = e((T - a[0]) / (b[0] - a[0])); return a.slice(1).map((v, k) => lerp(v, b[k + 1], p)); }
  }
  return fr[fr.length - 1].slice(1);
}

const SANS = "'IBM Plex Sans', system-ui, sans-serif";
const MONO = "'IBM Plex Mono', ui-monospace, monospace";
let U = {};
const palette = (h) => ({
  stage: '#0C0F13', win: '#EEF0F2', bar: '#E2E5E9', pane: '#FFFFFF', border: '#D3D8DD', line: '#E7EAED',
  text: '#1D242B', dim: '#66707A', faint: '#A1A9B1',
  acc: `oklch(0.56 0.11 ${h})`, sel: `oklch(0.62 0.11 ${h} / 0.15)`,
  link: 'oklch(0.66 0.17 150)', linkSoft: 'oklch(0.66 0.17 150 / 0.18)',
  frame: '#49515A', face: '#CDD2D8', faceDark: '#B9BFC6', port: '#2A3036',
});

// window geometry (stage coords)
const WX = 80, WY = 60, WW = 1760, WH = 860, BODY = 128, TREE_W = 460;
const CX = WX + TREE_W, CY = WY + BODY; // content origin on stage

// ---------- zone tree ----------
const ROW_H = 34;
const treeRows = (K) => [
  ['root', 'Locations', '', 0, 0.9, 'globe'],
  ['ny', 'AME/US/NY', 'New York', 1, 1.1, 'city'],
  ['tok', 'ASI/JP/TOK', 'Tokyo', 1, 1.2, 'city'],
  ['sof', 'EEU/BG/SOF', 'Sofia', 1, 1.3, 'city'],
  ['ffm', 'WEU/DE/FFM', 'Frankfurt', 1, 1.4, 'city'],
  ['m12', 'Musterstraße 12', 'building', 2, K.B + 0.1, 'bldg'],
  ['bas', 'Basement', '', 3, K.Fl + 0.1, 'floor'],
  ['gf', 'Ground floor', '', 3, K.Fl + 0.15, 'floor'],
  ['f1', 'Floor 1', '', 3, K.Fl + 0.2, 'floor'],
  ['f2', 'Floor 2', '', 3, K.Fl + 0.25, 'floor'],
  ['r210', '2.10', 'office', 4, K.Ro + 0.1, 'room'],
  ['r214', '2.14', 'server room', 4, K.Ro + 0.15, 'room'],
  ['rk4', 'R04', 'RITTAL-42', 5, K.Ra + 2.3, 'rack'],
  ['rk5', 'R05', 'RITTAL-42', 5, K.Ra + 2.35, 'rack'],
  ['r215', '2.15', 'UPS', 4, K.Ro + 0.2, 'room'],
  ['f3', 'Floor 3', '', 3, K.Fl + 0.3, 'floor'],
  ['m20', 'Musterstraße 20', 'building', 2, K.B + 0.15, 'bldg'],
  ['hf7', 'Am Hafen 7', 'building', 2, K.B + 0.2, 'bldg'],
];
const PARENTS = { root: 1, ffm: 1, m12: 1, f2: 1, r214: 1 };
function treeLayout(rows, t) {
  let y = 0; const out = {};
  rows.forEach((r) => { const h = ROW_H * tw(t, r[4], r[4] + 0.35, M.move); out[r[0]] = { y, h }; y += h; });
  return out;
}
const rowPos = (rows, id, t) => { const L = treeLayout(rows, t); const r = rows.find((x) => x[0] === id); return [16 + r[3] * 26 + 90, BODY + 12 + L[id].y + ROW_H / 2]; };

function Icon({ kind, on }) {
  const c = on ? U.acc : '#8A949E';
  const base = { flex: 'none', boxSizing: 'border-box' };
  if (kind === 'globe' || kind === 'city') return <div style={{ ...base, width: 16, height: 16, borderRadius: 8, border: `2px solid ${c}`, background: kind === 'city' ? mix('#fff', c, 0.35) : 'transparent' }}></div>;
  if (kind === 'bldg') return <div style={{ ...base, width: 16, height: 16, borderRadius: 2, background: c }}></div>;
  if (kind === 'floor') return <div style={{ ...base, width: 18, height: 7, borderRadius: 2, background: c }}></div>;
  if (kind === 'room') return <div style={{ ...base, width: 16, height: 16, borderRadius: 2, border: `2px solid ${c}` }}></div>;
  return <div style={{ ...base, width: 10, height: 18, borderRadius: 2, background: on ? U.acc : U.frame }}></div>;
}

function Tree({ T, K, rows, selId, pathHi }) {
  const L = treeLayout(rows, T);
  return (
    <div style={{ position: 'absolute', left: 0, top: BODY, width: TREE_W, bottom: 0, background: U.pane, borderRight: `1px solid ${U.border}`, overflow: 'hidden' }}>
      {rows.map((r) => {
        const [id, label, sub, lvl, at, kind] = r;
        const { y, h } = L[id];
        if (h <= 0.5) return null;
        const o = clampN(h / ROW_H);
        const on = id === selId;
        const hi = pathHi && ['ffm', 'm12', 'f2', 'r214', 'rk4'].includes(id) ? pathHi : 0;
        const kids = rows.filter((x) => x[3] === lvl + 1);
        const isParent = PARENTS[id] || kind === 'city' || kind === 'bldg' || kind === 'floor' || kind === 'room';
        const open = id === 'root' ? 1 : id === 'ffm' ? tw(T, K.B, K.B + 0.2) : id === 'm12' ? tw(T, K.Fl, K.Fl + 0.2) : id === 'f2' ? tw(T, K.Ro, K.Ro + 0.2) : id === 'r214' ? tw(T, K.Ra + 2.2, K.Ra + 2.4) : 0;
        return (
          <div key={id} style={{ position: 'absolute', left: 8, right: 8, top: 12 + y, height: ROW_H, opacity: o, borderRadius: 6, background: on ? U.sel : 'transparent', display: 'flex', alignItems: 'center', gap: 10, paddingLeft: 8 + lvl * 26, boxSizing: 'border-box' }}>
            <div style={{ width: 12, height: 12, flex: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {isParent && kind !== 'rack' && <div style={{ width: 6, height: 6, borderRight: `2px solid ${U.dim}`, borderBottom: `2px solid ${U.dim}`, transform: `rotate(${lerp(-45, 45, open)}deg)` }}></div>}
            </div>
            <Icon kind={kind} on={on || hi > 0.5} />
            <div style={{ font: `${on ? 600 : 500} 19px ${kind === 'city' || kind === 'rack' ? MONO : SANS}`, color: on || hi > 0.5 ? U.acc : U.text, whiteSpace: 'nowrap' }}>{label}</div>
            {sub && <div style={{ font: `400 17px ${SANS}`, color: U.dim, whiteSpace: 'nowrap' }}>{sub}</div>}
          </div>
        );
      })}
    </div>
  );
}

// ---------- zone content tables ----------
const ZCOLS = [30, 440, 900];
const STATES = (K) => [
  { at: 0.9, path: 'Locations', head: ['Visible-ID', 'Zone type', 'Objects'], rows: [['AME/US/NY', 'City · New York', '1,248'], ['ASI/JP/TOK', 'City · Tokyo', '862'], ['EEU/BG/SOF', 'City · Sofia', '517'], ['WEU/DE/FFM', 'City · Frankfurt', '2,904']] },
  { at: 2.4, path: 'Locations / WEU/DE/FFM', banner: 1, head: ['Visible-ID', 'Zone type', 'Objects'], rows: [['Musterstraße 12', 'Building', '1,736'], ['Musterstraße 20', 'Building', '822'], ['Am Hafen 7', 'Building', '346']] },
  { at: K.B + 2.4, path: 'WEU/DE/FFM / Musterstraße 12', head: ['Visible-ID', 'Zone type', 'Objects'], rows: [['Basement', 'Floor', '214'], ['Ground floor', 'Floor', '96'], ['Floor 1', 'Floor', '188'], ['Floor 2', 'Floor', '1,047'], ['Floor 3', 'Floor', '191']] },
  { at: K.Fl + 2.3, path: 'WEU/DE/FFM / Musterstraße 12 / Floor 2', head: ['Visible-ID', 'Zone type', 'Objects'], rows: [['2.10', 'Room · office', '12'], ['2.14', 'Room · server room', '986'], ['2.15', 'Room · UPS', '49']] },
  { at: K.Ro + 2.1, path: 'WEU/DE/FFM / Musterstraße 12 / Floor 2 / 2.14', objects: 1, head: ['Position', 'Visible-ID', 'Object type'], rows: [
    ['', 'R04', 'RITTAL-42 · Switch cabinet, 42 U', 0], ['42.0', 'PC5-1002', 'PC5-16RJ45 · Patch panel Cat5, 16x RJ45, 1 U', 1], ['41.0', 'PFO-1003', 'PFO-24LC · Patch panel fibre, 24x LC, 1 U', 1],
    ['38.0', 'SW-1101', 'C9300-48T · Access switch, 48x RJ45, 1 U', 1], ['35.0', 'SRV-1204', 'DL380 G10 · Server 19", 2 U', 1], ['31.0', 'SRV-1205', 'DL380 G10 · Server 19", 2 U', 1],
    ['', 'R05', 'RITTAL-42 · Switch cabinet, 42 U', 0], ['42.0', 'PC5-2001', 'PC5-16RJ45 · Patch panel Cat5, 16x RJ45, 1 U', 1], ['37.0', 'SRV-2207', 'DL380 G10 · Server 19", 2 U', 1], ['34.0', 'SRV-2208', 'DL380 G10 · Server 19", 2 U', 1]] },
];
const OCOLS = [30, 160, 440];
const CW52 = 31.2;

function ZoneTable({ T, K, st, o, r04sel }) {
  if (o <= 0) return null;
  const top = st.banner ? 250 : 100;
  const cols = st.objects ? OCOLS : ZCOLS;
  const dec = (i) => tw(T, 2.8 + i * 0.35, 3.2 + i * 0.35, M.enter);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{ position: 'absolute', left: 30, top: 22, font: `600 24px ${SANS}`, color: U.text }}>Zone content</div>
      <div style={{ position: 'absolute', left: 30, top: 58, font: `400 18px ${MONO}`, color: U.dim, whiteSpace: 'nowrap' }}>{st.path}</div>
      {st.banner && (
        <div style={{ position: 'absolute', left: 30, top: 104, width: 1240, height: 120, borderRadius: 10, background: '#F6F7F8', border: `1px solid ${U.line}` }}>
          <div style={{ position: 'absolute', left: 28, top: 14, display: 'flex', font: `500 52px ${MONO}`, color: U.text, whiteSpace: 'pre' }}>
            {['WEU', 'DE', 'FFM'].map((s, k) => <span key={k} style={{ color: mix(U.text, U.acc, dec(k)) }}>{(k ? '/' : '') + s}</span>)}
          </div>
          {['Region', 'Country', 'City'].map((l, k) => {
            const x = 28 + [0, 4, 7][k] * CW52, w = [3, 2, 3][k] * CW52;
            return (
              <div key={l} style={{ position: 'absolute', left: x, top: 82, width: w, opacity: dec(k), transform: `translateY(${(1 - dec(k)) * 6}px)` }}>
                <div style={{ height: 7, borderLeft: `2px solid ${U.acc}`, borderRight: `2px solid ${U.acc}`, borderBottom: `2px solid ${U.acc}`, boxSizing: 'border-box' }}></div>
                <div style={{ position: 'absolute', left: '50%', top: 10, transform: 'translateX(-50%)', font: `600 15px ${SANS}`, color: U.acc, whiteSpace: 'nowrap', textTransform: 'uppercase', letterSpacing: 1 }}>{l}</div>
              </div>
            );
          })}
          <div style={{ position: 'absolute', left: 420, top: 32, font: `400 30px ${SANS}`, color: U.dim, opacity: dec(2) }}>= Western Europe · Germany · Frankfurt</div>
        </div>
      )}
      <div style={{ position: 'absolute', left: 20, right: 20, top, height: 40, background: '#F3F5F6', borderTop: `1px solid ${U.border}`, borderBottom: `1px solid ${U.border}`, font: `600 16px ${SANS}`, color: U.dim }}>
        {st.head.map((h, i) => <div key={h} style={{ position: 'absolute', left: cols[i] - 10, top: 10 }}>{h}</div>)}
      </div>
      {st.rows.map((r, i) => {
        const ri = tw(T, st.at + 0.1 + i * 0.06, st.at + 0.45 + i * 0.06, M.enter);
        const lvl = st.objects ? r[3] : 0;
        const hi = st.objects && i === 0 ? r04sel : 0;
        return (
          <div key={i} style={{ position: 'absolute', left: 20, right: 20, top: top + 40 + i * 44, height: 44, opacity: ri, transform: `translateY(${(1 - ri) * 10}px)`, borderBottom: `1px solid ${U.line}`, background: hi ? mix('#ffffff', U.sel, hi) : 'transparent', font: `400 18px ${SANS}`, color: U.text }}>
            <div style={{ position: 'absolute', left: cols[0] - 10, top: 11, font: `${st.objects ? 400 : 500} 18px ${MONO}`, color: st.objects ? U.dim : U.text }}>{r[0]}</div>
            <div style={{ position: 'absolute', left: cols[1] - 10 + (st.objects ? lvl * 24 : 0), top: 11, display: 'flex', alignItems: 'center', gap: 10, font: `${st.objects && !lvl ? 600 : 400} 18px ${st.objects ? MONO : SANS}`, color: st.objects ? U.text : U.dim }}>
              {st.objects && <Icon kind={lvl ? 'room' : 'rack'} on={hi > 0.5} />}{r[1]}
            </div>
            <div style={{ position: 'absolute', left: cols[2] - 10, top: 11, color: st.objects ? U.dim : U.text, fontFamily: st.objects ? SANS : MONO, whiteSpace: 'nowrap' }}>{r[2]}</div>
          </div>
        );
      })}
    </div>
  );
}

// ---------- rack elevation ----------
const RU = 30, UTOP = 80;
const ut = (u) => UTOP + (42 - u) * RU;
const RACKS = [
  { x: 70, name: 'R04', devs: [[42, 1, 'pp16', 'PC5-1002'], [41, 1, 'fo24', 'PFO-1003'], [40, 1, 'mgr', ''], [38, 1, 'sw48', 'SW-1101'], [35, 2, 'srv', 'SRV-1204'], [31, 2, 'srv', 'SRV-1205']] },
  { x: 700, name: 'R05', devs: [[42, 1, 'pp16', 'PC5-2001'], [40, 1, 'mgr', ''], [37, 2, 'srv', 'SRV-2207'], [34, 2, 'srv', 'SRV-2208']] },
];
const PA = [372.5, 210], PB = [430, 99], PC = [1060, 99], PD = [1082, 273];
const CABLE = `M${PA[0]} ${PA[1]} C${PA[0]} 170 ${PB[0]} 150 ${PB[0]} ${PB[1]} C${PB[0]} 50 ${PC[0]} 50 ${PC[0]} ${PC[1]} C1112 140 1104 230 ${PD[0]} ${PD[1]}`;
const HOPS = [['SW-1101', 'Port 12', 0.01], ['PC5-1002', 'Port 12', 0.13], ['CBL-11873', 'Cat6A · 9 m', 0.45], ['PC5-2001', 'Port 12', 0.81], ['SRV-2207', 'NIC 1', 0.985]];

function Port({ x, y, w, h, lit }) {
  return <div style={{ position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: 1.5, background: lit ? U.link : U.port, boxShadow: lit ? `0 0 0 2px ${U.linkSoft}` : 'none' }}></div>;
}

function Device({ d, rk, T, K, p, k, focusOn }) {
  const [u, size, kind, name] = d;
  const top = ut(u) + 1, h = size * RU - 2, dx = 36;
  const pin = tw(T, K.Ra + 2.6 + k * 0.1, K.Ra + 3.0 + k * 0.1, M.pop);
  const isR04 = rk === 0;
  const swSel = name === 'SW-1101' ? tw(T, K.Ra + 4.4, K.Ra + 4.7, M.enter) * (1 - tw(T, K.Ca - 0.4, K.Ca)) : 0;
  const on = Math.max(swSel, focusOn && (name === 'SW-1101' || name === 'PC5-1002' || name === 'PC5-2001' || name === 'SRV-2207') ? focusOn : 0);
  const els = [];
  if (kind === 'pp16') {
    for (let j = 0; j < 16; j++) {
      const lit = j === 11 && p > (isR04 ? 0.13 : 0.81);
      els.push(<div key={'n' + j} style={{ position: 'absolute', left: 120 + j * 18, top: 1, width: 12, textAlign: 'center', font: `500 9px ${MONO}`, color: '#3B434B' }}>{j + 1}</div>);
      els.push(<Port key={j} x={120 + j * 18} y={13} w={12} h={10} lit={lit} />);
    }
  } else if (kind === 'fo24') {
    for (let j = 0; j < 12; j++) { els.push(<Port key={j + 'a'} x={120 + j * 24} y={10} w={7} h={9} />); els.push(<Port key={j + 'b'} x={128 + j * 24} y={10} w={7} h={9} />); }
  } else if (kind === 'mgr') {
    for (let j = 0; j < 6; j++) els.push(<div key={j} style={{ position: 'absolute', left: 20 + j * 70, top: 6, width: 40, height: 16, borderRadius: 8, border: '2px solid #8E979F', boxSizing: 'border-box' }}></div>);
  } else if (kind === 'sw48') {
    for (let j = 0; j < 24; j++) {
      els.push(<Port key={j + 'a'} x={130 + j * 12} y={6} w={9} h={8} lit={j === 11 && p > 0.005} />);
      els.push(<Port key={j + 'b'} x={130 + j * 12} y={17} w={9} h={8} />);
    }
    for (let j = 0; j < 4; j++) els.push(<Port key={'u' + j} x={430 - 4 * 14 + j * 14 - 10} y={10} w={10} h={10} />);
  } else if (kind === 'srv') {
    for (let j = 0; j < 8; j++) els.push(<div key={j} style={{ position: 'absolute', left: 10 + j * 22, top: 8, width: 16, height: h - 16, borderRadius: 2, background: U.faceDark, border: '1px solid #9EA6AE', boxSizing: 'border-box' }}></div>);
    for (let j = 0; j < 4; j++) els.push(<Port key={'n' + j} x={340 + j * 16} y={38} w={12} h={10} lit={!isR04 && name === 'SRV-2207' && j === 0 && p > 0.985} />);
    els.push(<div key="nl" style={{ position: 'absolute', left: 340, top: 22, font: `500 10px ${MONO}`, color: '#3B434B' }}>NIC 1–4</div>);
  }
  return (
    <div style={{ position: 'absolute', left: dx, top, width: 428, height: h, opacity: clampN(pin * 1.6), transform: `translateX(${(1 - pin) * 40}px)`, background: U.face, borderRadius: 2, boxShadow: on ? `0 0 0 2px ${U.acc}` : 'inset 0 0 0 1px #A9B1B9' }}>
      {els}
      {name && <div style={{ position: 'absolute', left: kind === 'srv' ? 196 : 8, top: kind === 'srv' ? h / 2 - 16 : 3, font: `600 12px ${MONO}`, color: '#222A31', whiteSpace: 'nowrap' }}>{name}</div>}
      {name && <div style={{ position: 'absolute', left: kind === 'srv' ? 196 : 8, top: kind === 'srv' ? h / 2 + 2 : 16, font: `400 10px ${SANS}`, color: '#4C555E', whiteSpace: 'nowrap' }}>{kind === 'pp16' ? 'PC5-16RJ45' : kind === 'fo24' ? 'PFO-24LC' : kind === 'sw48' ? 'C9300-48T' : 'DL380 G10'}</div>}
    </div>
  );
}

function RackView({ T, K, o }) {
  if (o <= 0) return null;
  const p = tw(T, K.Ca + 1.2, K.Ca + 4.4, M.move);
  const focusOn = tw(T, K.Ca + 4.6, K.Ca + 5.0, M.enter);
  const pulse = T > K.Ca + 0.6 && T < K.Ca + 1.4 ? (T - K.Ca - 0.6) / 0.8 : -1;
  const strip = tw(T, K.Ca + 1.0, K.Ca + 1.5, M.enter);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o, background: '#F7F8F9' }}>
      {RACKS.map((r, ri) => (
        <div key={r.name} style={{ position: 'absolute', left: r.x, top: 0, width: 500, height: 640, opacity: tw(T, K.Ra + 2.3 + ri * 0.2, K.Ra + 2.8 + ri * 0.2, M.enter) }}>
          <div style={{ position: 'absolute', left: 0, top: 18, font: `600 18px ${SANS}`, color: U.text }}>Front view · <span style={{ fontFamily: MONO }}>{r.name}</span></div>
          <div style={{ position: 'absolute', right: 0, top: 21, font: `400 15px ${SANS}`, color: U.dim }}>RITTAL-42 · Switch cabinet, 42 U</div>
          <div style={{ position: 'absolute', left: 0, top: UTOP - 10, width: 500, height: 18 * RU + 20, background: U.frame, borderRadius: 4 }}></div>
          <div style={{ position: 'absolute', left: 36, top: UTOP, width: 428, height: 18 * RU, background: '#FFFFFF' }}>
            {Array.from({ length: 18 }).map((_, k) => <div key={k} style={{ position: 'absolute', left: 0, right: 0, top: k * RU, height: RU, borderBottom: '1px dashed #DCE0E4', boxSizing: 'border-box' }}></div>)}
          </div>
          {Array.from({ length: 18 }).map((_, k) => [0, 464].map((x) => <div key={k + '-' + x} style={{ position: 'absolute', left: x, top: UTOP + k * RU + 7, width: 36, textAlign: 'center', font: `500 12px ${MONO}`, color: '#DCE0E4' }}>{42 - k}</div>))}
          {r.devs.map((d, k) => <Device key={k} d={d} rk={ri} T={T} K={K} p={p} k={k + ri * 3} focusOn={focusOn} />)}
        </div>
      ))}
      <svg width="1300" height="732" style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
        <path d={CABLE} fill="none" stroke={U.link} strokeOpacity="0.25" strokeWidth="12" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - p} />
        <path d={CABLE} fill="none" stroke={U.link} strokeWidth="4" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - p} />
        {pulse >= 0 && <circle cx={PA[0]} cy={PA[1]} r={6 + pulse * 26} fill="none" stroke={U.link} strokeWidth="2.5" opacity={1 - pulse} />}
      </svg>
      <div style={{ position: 'absolute', left: 700, top: 40, padding: '3px 10px', borderRadius: 12, background: U.link, color: '#fff', font: `600 14px ${MONO}`, opacity: tw(T, K.Ca + 2.4, K.Ca + 2.8, M.enter), transform: 'translateX(20px)' }}>CBL-11873</div>
      <PropsPanel T={T} K={K} />
      <div style={{ position: 'absolute', left: 20, right: 20, top: 650, height: 66, display: 'flex', alignItems: 'center', gap: 12, opacity: strip, transform: `translateY(${(1 - strip) * 14}px)` }}>
        <div style={{ font: `600 15px ${SANS}`, color: U.dim, textTransform: 'uppercase', letterSpacing: 1, width: 110, flex: 'none' }}>Signal trace</div>
        {HOPS.map(([a, b, th], i) => {
          const lit = tw(T, K.Ca + 1.2 + th * 3.2, K.Ca + 1.5 + th * 3.2, M.enter);
          return (
            <React.Fragment key={a}>
              {i > 0 && <div style={{ width: 18, height: 2, flex: 'none', background: lit > 0.5 ? U.link : U.border }}></div>}
              <div style={{ flex: 1, minWidth: 0, height: 56, borderRadius: 8, border: `1.5px solid ${lit > 0.5 ? U.link : U.border}`, background: lit > 0.5 ? U.linkSoft : '#fff', padding: '7px 12px', boxSizing: 'border-box', transform: `scale(${1 + 0.05 * Math.sin(lit * Math.PI)})` }}>
                <div style={{ font: `600 17px ${MONO}`, color: lit > 0.5 ? U.text : U.faint }}>{a}</div>
                <div style={{ font: `400 14px ${SANS}`, color: U.dim }}>{b}</div>
              </div>
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

const PROPS = [
  ['Visible-ID', 'SW-1101'], ['Object type', 'C9300-48T · Access switch, 48x RJ45'], ['Serial number', 'FOC2417X1AB', 1],
  ['Management IP', '10.48.12.21', 1], ['CORIA-ID', 'CORIA-004512', 1], ['Rack position', 'R04 · U38'], ['Status', 'In service'],
];
function PropsPanel({ T, K }) {
  const pin = tw(T, K.Ra + 4.6, K.Ra + 5.1) * (1 - tw(T, K.Ca - 0.5, K.Ca));
  if (pin <= 0) return null;
  return (
    <div style={{ position: 'absolute', left: 860, top: 0, width: 440, height: 640, background: '#fff', borderLeft: `1px solid ${U.border}`, boxShadow: '-20px 0 40px rgba(20,30,40,0.10)', transform: `translateX(${(1 - pin) * 460}px)`, padding: '22px 28px', boxSizing: 'border-box' }}>
      <div style={{ font: `600 15px ${SANS}`, color: U.dim, textTransform: 'uppercase', letterSpacing: 1 }}>Properties</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 10 }}>
        <Icon kind="room" on={1} />
        <div style={{ font: `600 28px ${MONO}`, color: U.text }}>SW-1101</div>
      </div>
      <div style={{ marginTop: 18, borderTop: `1px solid ${U.line}` }}>
        {PROPS.map(([l, v, key], i) => {
          const ro = tw(T, K.Ra + 4.9 + i * 0.08, K.Ra + 5.3 + i * 0.08, M.enter);
          const hi = key ? tw(T, K.Ra + 5.6 + (i - 2) * 0.7, K.Ra + 5.9 + (i - 2) * 0.7, M.enter) : 0;
          return (
            <div key={l} style={{ padding: '10px 12px', margin: '0 -12px', borderBottom: `1px solid ${U.line}`, borderRadius: 6, background: hi ? mix('#ffffff', U.sel, hi) : 'transparent', opacity: ro, transform: `translateY(${(1 - ro) * 8}px)` }}>
              <div style={{ font: `500 14px ${SANS}`, color: U.dim, textTransform: 'uppercase', letterSpacing: 0.8 }}>{l}</div>
              <div style={{ font: `500 20px ${i === 1 ? SANS : MONO}`, color: hi > 0.5 ? U.acc : U.text, marginTop: 3, whiteSpace: 'nowrap' }}>{v}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ---------- cursor ----------
function Cursor({ T, K, rows, end }) {
  const P = (id, t) => rowPos(rows, id, t);
  const ffm = P('ffm', 2.2), m12 = P('m12', K.B + 1.9), f2 = P('f2', K.Fl + 1.9), r214 = P('r214', K.Ro + 1.7);
  const r04 = [TREE_W + 200, BODY + 290 + 22 - 128 + 128 - 128 + 128];
  const r04row = [TREE_W + 200, BODY + 162];
  const port = [TREE_W + PA[0], BODY + PA[1]];
  const sw = [TREE_W + 166, BODY + ut(38) + 15];
  const fr = [
    [1.3, 1100, 640], [2.2, ...ffm], [K.B + 1.2, ...ffm], [K.B + 1.9, ...m12], [K.Fl + 1.3, ...m12], [K.Fl + 1.9, ...f2],
    [K.Ro + 1.1, ...f2], [K.Ro + 1.7, ...r214], [K.Ra + 0.6, ...r214], [K.Ra + 1.5, ...r04row], [K.Ra + 2.4, ...r04row], [K.Ra + 4.0, ...sw], [K.Ra + 4.8, ...sw], [K.Ra + 6.0, ...sw.map((v, i) => v + (i ? 260 : 600))],
    [K.Ca + 0.2, ...port], [K.Ca + 1.0, ...port], [K.Ca + 2.4, 1300, 600],
  ];
  const clicks = [2.3, K.B - 0.15, K.B + 2.3, K.Fl - 0.15, K.Fl + 2.2, K.Ro - 0.15, K.Ro + 2.0, K.Ra + 1.7, K.Ra + 1.9, K.Ra + 4.4, K.Ca + 0.6];
  const o = tw(T, 1.1, 1.4) * (1 - tw(T, K.Cl - 0.4, K.Cl + 0.1));
  if (o <= 0) return null;
  const [x, y] = kf(T, fr);
  const near = clicks.some((c) => Math.abs(T - c) < 0.08);
  return (
    <>
      {clicks.map((c, i) => {
        const q = (T - c) / 0.45;
        if (q < 0 || q > 1) return null;
        const [cx, cy] = kf(c, fr);
        return <div key={i} style={{ position: 'absolute', left: cx - 24, top: cy - 24, width: 48, height: 48, borderRadius: 24, border: `2.5px solid ${U.acc}`, opacity: 1 - q, transform: `scale(${0.3 + q * 0.8})`, boxSizing: 'border-box' }}></div>;
      })}
      <svg width="30" height="36" viewBox="0 0 22 28" style={{ position: 'absolute', left: x - 2, top: y - 2, opacity: o, transform: `scale(${near ? 0.85 : 1})`, transformOrigin: '2px 2px', filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.35))', overflow: 'visible' }}>
        <polygon points="1,1 1,22 6.5,17 10.5,26 14,24.5 10,15.5 17,15.5" fill="#111" stroke="#fff" strokeWidth="1.4" strokeLinejoin="round" />
      </svg>
    </>
  );
}

// ---------- app window ----------
function AppWindow({ T, K, end }) {
  const rows = treeRows(K);
  const states = STATES(K);
  let ai = 0; states.forEach((s, i) => { if (T >= s.at) ai = i; });
  const rackTab = tw(T, K.Ra + 2.2, K.Ra + 2.6);
  const sel = T < 2.3 ? 'root' : T < K.B + 2.3 ? 'ffm' : T < K.Fl + 2.2 ? 'm12' : T < K.Ro + 2.0 ? 'f2' : T < K.Ra + 2.2 ? 'r214' : 'rk4';
  const pathHi = tw(T, K.Cl + 0.6, K.Cl + 1.2, M.enter);
  const r04sel = tw(T, K.Ra + 1.7, K.Ra + 1.9, M.enter);
  const pathText = rackTab > 0.5 ? 'Rack: WEU/DE/FFM / Musterstraße 12 / Floor 2 / 2.14 / R04' : 'Zone: ' + states[ai].path;
  const enter = tw(T, 0, 0.9, M.enter);
  return (
    <div style={{ position: 'absolute', left: WX, top: WY, width: WW, height: WH, opacity: enter, transform: `scale(${lerp(0.97, 1, enter)})`, transformOrigin: '50% 50%', background: U.win, borderRadius: 12, overflow: 'hidden', boxShadow: '0 40px 120px rgba(0,0,0,0.55)' }}>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 0, height: 48, background: U.bar, display: 'flex', alignItems: 'flex-end', gap: 4, paddingLeft: 16 }}>
        <div style={{ height: 48, display: 'flex', alignItems: 'center', gap: 6, marginRight: 14 }}>
          {[0, 1, 2].map((r) => <div key={r} style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>{[0, 1, 2].map((c) => <div key={c} style={{ width: 5, height: 5, borderRadius: 1, background: (r + c) % 2 ? '#7F8993' : U.acc }}></div>)}</div>)}
        </div>
        {[['Navigator', 1], ['Rack: R04', rackTab]].map(([t, v], i) => {
          if (i === 1 && v <= 0) return null;
          const active = i === 0 ? 1 - rackTab : rackTab;
          return <div key={t} style={{ height: 40, padding: '0 22px', display: 'flex', alignItems: 'center', borderRadius: '8px 8px 0 0', background: active > 0.5 ? U.win : 'transparent', font: `500 18px ${SANS}`, color: active > 0.5 ? U.text : U.dim, opacity: i === 1 ? clampN(v * 2) : 1 }}>{t}</div>;
        })}
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 48, height: 36, display: 'flex', alignItems: 'center', gap: 34, paddingLeft: 26, font: `400 17px ${SANS}`, color: U.text }}>
        {['File', 'Edit', 'Objects', 'Port', 'View', 'Extras', 'Help'].map((m) => <div key={m}>{m}</div>)}
      </div>
      <div style={{ position: 'absolute', left: 16, right: 16, top: 86, height: 34, borderRadius: 6, background: pathHi ? mix('#fff', U.sel, pathHi) : '#fff', border: `1px solid ${pathHi > 0.5 ? U.acc : U.border}`, display: 'flex', alignItems: 'center', padding: '0 14px', font: `500 17px ${MONO}`, color: pathHi > 0.5 ? U.acc : U.text, whiteSpace: 'nowrap', boxSizing: 'border-box' }}>{pathText}</div>
      <Tree T={T} K={K} rows={rows} selId={sel} pathHi={pathHi} />
      <div style={{ position: 'absolute', left: TREE_W, top: BODY, right: 0, bottom: 0, background: U.pane, overflow: 'hidden' }}>
        {states.map((s, i) => {
          const next = states[i + 1];
          const o = tw(T, s.at + 0.12, s.at + 0.35) * (next ? 1 - tw(T, next.at, next.at + 0.12) : 1) * (1 - rackTab);
          return <ZoneTable key={i} T={T} K={K} st={s} o={o} r04sel={r04sel} />;
        })}
        <RackView T={T} K={K} o={rackTab} />
      </div>
      <Cursor T={T} K={K} rows={rows} end={end} />
    </div>
  );
}

function Piece({ tweaks }) {
  const { T, CUES, authoredTotal } = useComposition();
  U = palette(tweaks.accentHue ?? 195);
  const K = { Lo: CUES.Locations, B: CUES.Building, Fl: CUES.Floor, Ro: CUES.Room, Ra: CUES.Rack, Ca: CUES.Cabling, Cl: CUES.Close };
  const end = authoredTotal;
  const rows = treeRows(K);
  const ty = (id, t) => WY + rowPos(rows, id, t)[1];
  const cam = kf(T, [
    [0, 960, 540, 1], [1.8, 960, 540, 1], [2.7, 860, 400, 1.3], [K.B + 1.0, 860, 400, 1.3], [K.B + 2.0, 860, Math.max(400, ty('m12', K.B + 2)), 1.3],
    [K.Fl + 1.6, 860, Math.max(400, ty('f2', K.Fl + 2)), 1.3], [K.Ro + 1.6, 860, Math.max(400, ty('r214', K.Ro + 2)), 1.3],
    [K.Ra + 0.6, 960, 520, 1.05], [K.Ra + 2.6, 960, 520, 1.05], [K.Ra + 3.6, CX + 330, CY + 200, 1.5], [K.Ra + 4.4, CX + 330, CY + 200, 1.5], [K.Ra + 5.3, 1215, 440, 1.2], [K.Ra + 8.3, 1215, 440, 1.2], [K.Ca + 0.2, CX + 330, CY + 200, 1.5], [K.Ca + 1.3, CX + 330, CY + 200, 1.5],
    [K.Ca + 2.6, 960, 520, 1.03], [K.Ca + 6.6, 960, 520, 1.03], [K.Cl + 0.3, 960, 540, 1], [K.Cl + 1.3, 820, 330, 1.3], [end, 820, 330, 1.33],
  ]);
  const [fx, fy, s] = cam;
  const caps = [
    { at: K.Lo + 0.4, text: 'In FNT Command, every asset starts with a location.' },
    { at: K.Lo + 2.6, text: 'Cities are coded by region, country and city: WEU/DE/FFM is Frankfurt.' },
    { at: K.B + 0.4, text: 'Within a city, each site is a building, named by its street address.' },
    { at: K.Fl + 0.3, text: 'Each building is divided into floors…' },
    { at: K.Ro + 0.3, text: '…and each floor into rooms.' },
    { at: K.Ra + 0.3, text: 'Open a rack to see every device in its exact rack position.' },
    { at: K.Ra + 4.7, text: 'Each object carries its own properties: serial number, management IP and CORIA-ID.' },
    { at: K.Ca + 0.3, text: 'Trace a connection from the switch port, through both patch panels, to the server.' },
    { at: K.Cl + 0.4, until: end - 0.5, text: 'City, building, floor, room, rack: every asset has a precise address.' },
  ];
  const fade = tw(T, 0, 0.6) * (1 - tw(T, end - 0.7, end - 0.05));
  return (
    <div data-screen-label={`t=${Math.floor(T)}s`} style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: U.stage }}>
      <div style={{ position: 'absolute', inset: -40, backgroundImage: 'radial-gradient(circle, #1A2029 1.2px, transparent 1.6px)', backgroundSize: '40px 40px', transform: `translate(${(T * 3) % 40}px, ${(T * 1.5) % 40}px)` }}></div>
      <div style={{ position: 'absolute', inset: 0, opacity: fade, transform: `translate(${960 - fx * s}px, ${540 - fy * s}px) scale(${s})`, transformOrigin: '0 0' }}>
        <AppWindow T={T} K={K} end={end} />
      </div>
      {tweaks.captions !== false && (
        <Captions items={caps} style={{ left: '50%', right: 'auto', bottom: 36, transform: 'translateX(-50%)', width: 'max-content', maxWidth: 1560, padding: '14px 30px', borderRadius: 12, background: 'rgba(10,13,17,0.9)', font: `500 34px ${SANS}`, color: '#ECEAE5', textShadow: 'none', lineHeight: 1.3 }} />
      )}
    </div>
  );
}

function FNTVideo() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <>
      <CompositionStage width={1920} height={1080} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#0C0F13">
        <Piece tweaks={t} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Playback" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        <TweakToggle label="Captions" value={t.captions} onChange={(v) => setTweak('captions', v)} />
        <TweakSection label="Look" />
        <TweakRadio label="Accent hue" value={String(t.accentHue)} options={['195', '245', '150']} onChange={(v) => setTweak('accentHue', +v)} />
      </TweaksPanel>
    </>
  );
}

window.FNTVideo = FNTVideo;

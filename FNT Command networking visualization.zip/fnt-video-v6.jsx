const { Easing, useComposition, CompositionStage, Captions } = window;

const M = { enter: Easing.easeOutCubic, move: Easing.easeInOutCubic, pop: Easing.easeOutBack };
const tw = (T, a, b, e = M.move) => (T <= a ? 0 : T >= b ? 1 : e((T - a) / (b - a)));
const lerp = (a, b, p) => a + (b - a) * p;
function kf(T, fr, e = M.move) {
  if (T <= fr[0][0]) return fr[0].slice(1);
  for (let i = 0; i < fr.length - 1; i++) {
    const a = fr[i], b = fr[i + 1];
    if (T < b[0]) { const p = e((T - a[0]) / (b[0] - a[0])); return a.slice(1).map((v, k) => lerp(v, b[k + 1], p)); }
  }
  return fr[fr.length - 1].slice(1);
}
const clampN = (v) => Math.max(0, Math.min(1, v));
const mix = (a, b, p) => `color-mix(in oklch, ${b} ${Math.round(clampN(p) * 100)}%, ${a})`;
const nh = (h) => ((h % 360) + 360) % 360;

const SANS = "'IBM Plex Sans', system-ui, sans-serif";
const MONO = "'IBM Plex Mono', ui-monospace, monospace";
// Location levels share one cool analogous ramp (violet → green). Coral marks problems and the signal path.
const LV = { city: 290, bldg: 255, floor: 220, room: 185, rack: 150 };
const NAV_C = 'oklch(0.55 0.15 285)', OM_C = 'oklch(0.56 0.13 150)';
const CORAL = 'oklch(0.66 0.18 35)', CORAL_D = 'oklch(0.50 0.16 35)', CORAL_S = 'oklch(0.66 0.18 35 / 0.3)';
const LED = 'oklch(0.82 0.19 150)', AMBER = 'oklch(0.84 0.15 85)', OKG = 'oklch(0.62 0.15 150)';
const hc = (h, a) => `oklch(0.6 0.15 ${h}${a ? ' / ' + a : ''})`;
const tint = (h) => `oklch(0.95 0.025 ${h})`;
const tint2 = (h) => `oklch(0.86 0.065 ${h})`;
const deep = (h) => `oklch(0.40 0.12 ${h})`;
const shade = (h, l, c) => ({ top: `oklch(${(l + 0.07).toFixed(3)} ${c} ${h})`, sy: `oklch(${l} ${c} ${h})`, sx: `oklch(${(l - 0.09).toFixed(3)} ${c} ${h})` });
const CB = { bg: '#F4F2EE', line: '#E4E1DA', line2: '#CBC7BE', text: '#18213A', dim: '#566079', faint: '#9AA1B0', navy: '#1C2438', navy2: '#131A2A', navy3: '#2B3550', navyTop: '#3A4560' };
let C = CB;
const useHue = (h) => { C = { ...CB, h, acc: hc(h), tint: tint(h), tint2: tint2(h), deep: deep(h) }; };
const SHADOW = '0 24px 60px rgba(24,33,58,0.14), 0 4px 12px rgba(24,33,58,0.08)';
const blink = (T, seed) => (Math.sin(T * 5.3 + seed * 2.7) > -0.3 ? 1 : 0.25);

const ZD = 1.3;
const HIDDEN = { display: 'none' };
function zoomXf(T, inAt, inF, Z1, outAt, outF, Z2) {
  if (inAt != null) {
    if (T < inAt) return HIDDEN;
    if (T < inAt + ZD) {
      const p = tw(T, inAt, inAt + ZD);
      return { transform: `translate(${(inF[0] - 960) * (1 - p)}px, ${(inF[1] - 540) * (1 - p)}px) scale(${Math.pow(Z1, p - 1)})`, transformOrigin: '960px 540px', opacity: tw(T, inAt + 0.15 * ZD, inAt + 0.55 * ZD, M.enter) };
    }
  }
  if (outAt != null && T >= outAt) {
    if (T > outAt + ZD) return HIDDEN;
    const p = tw(T, outAt, outAt + ZD);
    return { transform: `translate(${(960 - outF[0]) * p}px, ${(540 - outF[1]) * p}px) scale(${Math.pow(Z2, p)})`, transformOrigin: `${outF[0]}px ${outF[1]}px`, opacity: 1 - tw(T, outAt + 0.4 * ZD, outAt + 0.8 * ZD) };
  }
  return { opacity: 1 };
}
const Layer = ({ xf, children }) => (xf.display === 'none' ? null : <div style={{ position: 'absolute', inset: 0, ...xf }}>{children}</div>);
const sel = (T, at) => tw(T, at, at + 0.45, M.enter);
const ring = (T, at) => (T > at ? ((T - at) % 1.1) / 1.1 : -1);

// ---------- isometric helpers (2:1) ----------
const IX = 0.7071, IY = 0.3536, IZ = 0.866;
const iso = (o, x, y, z = 0) => [o[0] + (x - y) * IX, o[1] + (x + y) * IY - z * IZ];
const pts = (a) => a.map((p) => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
const isoRect = (o, x, y, w, d, z = 0) => pts([iso(o, x, y, z), iso(o, x + w, y, z), iso(o, x + w, y + d, z), iso(o, x, y + d, z)]);
function IsoBox({ o, x, y, z = 0, w, d, h, top, sy, sx }) {
  const P = (a, b, c) => iso(o, a, b, c);
  const f = (fill, p) => <polygon points={pts(p)} fill={fill} stroke={fill} strokeWidth="0.8" strokeLinejoin="round" />;
  return (
    <g>
      {f(sy, [P(x, y + d, z), P(x + w, y + d, z), P(x + w, y + d, z + h), P(x, y + d, z + h)])}
      {f(sx, [P(x + w, y, z), P(x + w, y + d, z), P(x + w, y + d, z + h), P(x + w, y, z + h)])}
      {f(top, [P(x, y, z + h), P(x + w, y, z + h), P(x + w, y + d, z + h), P(x, y + d, z + h)])}
    </g>
  );
}

// ---------- icons ----------
function NavIcon({ size = 40, col = NAV_C, ring: rc }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size / 2, border: `${Math.round(size * 0.1)}px solid ${rc || col}`, boxSizing: 'border-box', position: 'relative', flex: 'none' }}>
      <div style={{ position: 'absolute', left: '50%', top: '50%', width: size * 0.24, height: size * 0.66, transform: 'translate(-50%, -50%) rotate(40deg)', clipPath: 'polygon(50% 0, 100% 50%, 50% 100%, 0 50%)', background: `linear-gradient(${rc || col} 50%, ${CORAL} 50%)` }}></div>
    </div>
  );
}
function OMIcon({ size = 40, col = OM_C }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size * 0.24, background: col, flex: 'none', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: size * 0.11, paddingLeft: size * 0.2, boxSizing: 'border-box' }}>
      {[0.5, 0.36, 0.44].map((w, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: size * 0.08 }}>
          <div style={{ width: size * 0.1, height: size * 0.1, borderRadius: size, background: '#fff' }}></div>
          <div style={{ height: size * 0.08, borderRadius: 2, background: '#fff', width: size * w }}></div>
        </div>
      ))}
    </div>
  );
}
function Check({ size = 30, col = OKG }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size / 2, background: col, position: 'relative', flex: 'none' }}>
      <div style={{ position: 'absolute', left: size * 0.37, top: size * 0.2, width: size * 0.22, height: size * 0.42, borderRight: `${size * 0.1}px solid #fff`, borderBottom: `${size * 0.1}px solid #fff`, transform: 'rotate(45deg)' }}></div>
    </div>
  );
}

// ---------- 0a. Problem ----------
const DOCS = [
  { x: 330, y: 250, r: -4, kind: 'sheet', a: 'sites_FINAL_v7.xlsx', b: 'last edited 2019' },
  { x: 1290, y: 210, r: 3, kind: 'diagram', a: 'core-racks.vsd', b: '3 different versions' },
  { x: 800, y: 130, r: -2, kind: 'sheet', a: 'IP-plan (old).xlsx', b: 'do not use?' },
  { x: 1380, y: 600, r: 4, kind: 'pdf', a: 'fiber-routes.pdf', b: 'scanned in 2016' },
  { x: 260, y: 620, r: 3, kind: 'note', a: 'Ask Martin', b: 'he knows the patching' },
  { x: 820, y: 650, r: -3, kind: 'csv', a: 'ports_export.csv', b: '4,112 rows' },
];
const docC = (i) => [DOCS[i].x + 150, DOCS[i].y + 105];
const TANGLE = [[0, 2], [2, 1], [1, 3], [3, 5], [5, 4], [4, 0], [0, 5], [2, 3], [4, 2]];
const QS = [
  { x: 760, y: 500, t: 'Where is this device?' },
  { x: 1230, y: 455, t: 'Which port is this cable on?' },
  { x: 980, y: 590, t: 'Is this still up to date?' },
];
function DocArt({ kind }) {
  if (kind === 'sheet') return (
    <div style={{ position: 'absolute', left: 20, top: 18, right: 20, bottom: 14, display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gridTemplateRows: 'repeat(5, 1fr)', gap: 3 }}>
      {Array.from({ length: 25 }).map((_, k) => <div key={k} style={{ borderRadius: 2, background: k < 5 ? OKG : k === 13 ? CORAL : k % 3 ? '#FFFFFF' : '#E4E7EC', font: `700 10px ${MONO}`, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{k === 13 ? '#REF!' : ''}</div>)}
    </div>
  );
  if (kind === 'diagram') return (
    <svg width="300" height="130" style={{ position: 'absolute', inset: 0 }}>
      <line x1="80" y1="45" x2="220" y2="45" stroke="#8A93A6" strokeWidth="2.5" />
      <line x1="80" y1="45" x2="150" y2="100" stroke="#8A93A6" strokeWidth="2.5" />
      <line x1="220" y1="45" x2="150" y2="100" stroke={CORAL} strokeWidth="2.5" strokeDasharray="6 6" />
      {[[80, 45], [220, 45], [150, 100]].map(([x, y], k) => <rect key={k} x={x - 36} y={y - 16} width="72" height="32" rx="7" fill={k === 2 ? '#fff' : tint2(255)} stroke={hc(255)} strokeWidth="2.5" />)}
    </svg>
  );
  if (kind === 'pdf') return (
    <div style={{ position: 'absolute', left: 88, top: 12, width: 124, height: 118, background: '#fff', boxShadow: '0 2px 8px rgba(0,0,0,0.12)', transform: 'rotate(-3deg)', padding: 14, boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: 8 }}>
      {[1, 0.8, 0.9, 0.6, 0.85, 0.7].map((w, k) => <div key={k} style={{ height: 6, width: `${w * 100}%`, borderRadius: 3, background: '#C3C7CF' }}></div>)}
      <div style={{ position: 'absolute', right: -10, bottom: 10, padding: '2px 8px', borderRadius: 4, background: CORAL, font: `700 13px ${SANS}`, color: '#fff' }}>PDF</div>
    </div>
  );
  if (kind === 'note') return (
    <svg width="300" height="130" style={{ position: 'absolute', inset: 0 }}>
      <rect x="110" y="-6" width="80" height="26" rx="3" fill="rgba(255,255,255,0.55)" transform="rotate(-4 150 7)" />
      {[46, 74, 102].map((y, k) => <path key={k} d={`M40 ${y} q 20 -10 40 0 t 40 0 t 40 0 t 40 0 t 40 0`} fill="none" stroke="oklch(0.45 0.08 80)" strokeWidth="3" strokeLinecap="round" opacity={k === 2 ? 0.5 : 0.8} />)}
    </svg>
  );
  return (
    <div style={{ position: 'absolute', left: 22, top: 16, right: 22, display: 'flex', flexDirection: 'column', gap: 5, font: `500 13px ${MONO}`, color: '#6B7489' }}>
      {['id;site;rack;port', '1101;FFM;R04;12', '1102;FFM;R04;??', '1103;FFM;;14', '1104;?;R05;12'].map((l, k) => <div key={k} style={{ color: k === 0 ? CB.text : l.includes('?') ? CORAL : '#6B7489' }}>{l}</div>)}
    </div>
  );
}
function ClockIcon({ T }) {
  return (
    <div style={{ width: 44, height: 44, borderRadius: 22, border: `4px solid ${CB.navy}`, boxSizing: 'border-box', position: 'relative', flex: 'none' }}>
      <div style={{ position: 'absolute', left: 16, top: 6, width: 4, height: 14, borderRadius: 2, background: CORAL, transformOrigin: '2px 14px', transform: `rotate(${T * 300}deg)` }}></div>
      <div style={{ position: 'absolute', left: 16, top: 11, width: 4, height: 9, borderRadius: 2, background: CB.navy, transformOrigin: '2px 9px', transform: `rotate(${T * 25}deg)` }}></div>
    </div>
  );
}
function WarnIcon() {
  return (
    <div style={{ width: 48, height: 44, position: 'relative', flex: 'none' }}>
      <div style={{ position: 'absolute', inset: 0, background: CORAL, clipPath: 'polygon(50% 0, 100% 100%, 0 100%)', borderRadius: 4 }}></div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 12, textAlign: 'center', font: `700 24px ${SANS}`, color: '#fff' }}>!</div>
    </div>
  );
}
function Problem({ T, K }) {
  const t = T - K.Pb, ts = T - K.So;
  if (ts > 1.3) return null;
  const conv = (i) => tw(ts, 0.05 * i, 0.9 + 0.05 * i, M.move);
  const gone = tw(ts, 0, 0.5);
  const qO = (1 - tw(t, 5.6, 6.0)) * (1 - gone);
  const cons = [{ t: 'Hours lost searching', icon: 'clock' }, { t: 'Outages from wrong patching', icon: 'warn' }];
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: tw(T, 0, 0.4) }}>
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0 }}>
        {TANGLE.map(([a, b], k) => {
          const A = docC(a), B = docC(b);
          const mx = (A[0] + B[0]) / 2 + (k % 2 ? 90 : -90), my = (A[1] + B[1]) / 2 + ((k % 3) - 1) * 80;
          const p = tw(t, 1.8 + k * 0.12, 2.7 + k * 0.12, M.move);
          const q = tw(t, 2.6 + k * 0.12, 3.0 + k * 0.12, M.pop);
          const mid = [(A[0] + 2 * mx + B[0]) / 4, (A[1] + 2 * my + B[1]) / 4];
          return (
            <g key={k} opacity={1 - gone}>
              <path d={`M${A[0]} ${A[1]} Q${mx} ${my} ${B[0]} ${B[1]}`} fill="none" stroke={CORAL} strokeOpacity="0.7" strokeWidth="3" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - p} />
              {k % 2 === 0 && q > 0 && (
                <g transform={`translate(${mid[0]} ${mid[1]}) scale(${q})`}>
                  <circle r="16" fill={CORAL} />
                  <text y="7" textAnchor="middle" style={{ font: `700 20px ${SANS}`, fill: '#fff' }}>?</text>
                </g>
              )}
            </g>
          );
        })}
      </svg>
      {DOCS.map((d, i) => {
        const p = tw(t, 0.3 + i * 0.22, 0.8 + i * 0.22, M.pop);
        if (p <= 0) return null;
        const c = conv(i);
        const fl = Math.sin(T * 0.9 + i * 1.7) * 6 * (1 - c);
        const shake = t > 6.3 && t < 7.3 ? Math.sin(T * 38 + i * 2) * 2.5 : 0;
        const x = lerp(d.x, 810, c) + shake, y = lerp(d.y + fl, 365, c);
        const note = d.kind === 'note';
        return (
          <div key={i} style={{ position: 'absolute', left: x, top: y, width: 300, opacity: clampN(p * 2) * (1 - tw(ts, 0.6 + 0.05 * i, 1.0 + 0.05 * i)), transform: `rotate(${d.r * (1 - c)}deg) scale(${lerp(1, 0.25, c) * lerp(0.6, 1, Math.min(1, p))})`, background: note ? 'oklch(0.93 0.11 95)' : '#fff', borderRadius: 14, boxShadow: SHADOW, overflow: 'hidden' }}>
            <div style={{ height: 130, position: 'relative', background: note ? 'transparent' : '#F3F1EC' }}><DocArt kind={d.kind} /></div>
            <div style={{ padding: '12px 18px 16px' }}>
              <div style={{ font: `${note ? 'italic 600 26px' : '600 21px'} ${note ? SANS : MONO}`, color: CB.text, whiteSpace: 'nowrap' }}>{d.a}</div>
              <div style={{ font: `400 18px ${SANS}`, color: CB.dim, marginTop: 4 }}>{d.b}</div>
            </div>
          </div>
        );
      })}
      {QS.map((q, i) => {
        const p = tw(t, 3.0 + i * 0.5, 3.5 + i * 0.5, M.pop);
        if (p <= 0 || qO <= 0) return null;
        return (
          <div key={i} style={{ position: 'absolute', left: q.x, top: q.y, transform: `translate(-50%, -50%) scale(${lerp(0.6, 1, Math.min(1, p))})`, opacity: clampN(p * 2) * qO, display: 'flex', alignItems: 'center', gap: 12, padding: '12px 24px 12px 12px', borderRadius: 40, background: CB.navy, boxShadow: SHADOW }}>
            <div style={{ width: 36, height: 36, borderRadius: 18, background: CORAL, color: '#fff', font: `700 22px ${SANS}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>?</div>
            <div style={{ font: `500 25px ${SANS}`, color: '#fff', whiteSpace: 'nowrap' }}>{q.t}</div>
          </div>
        );
      })}
      {cons.map((c, i) => {
        const p = tw(t, 6.1 + i * 0.6, 6.6 + i * 0.6, M.pop) * (1 - gone);
        if (p <= 0) return null;
        return (
          <div key={c.t} style={{ position: 'absolute', left: 960, top: 470 + i * 100, transform: `translate(-50%, -50%) scale(${lerp(0.6, 1, Math.min(1, p))})`, opacity: clampN(p * 2), display: 'flex', alignItems: 'center', gap: 18, padding: '16px 30px 16px 18px', borderRadius: 18, background: '#fff', boxShadow: SHADOW }}>
            {c.icon === 'clock' ? <ClockIcon T={T} /> : <WarnIcon />}
            <div style={{ font: `600 32px ${SANS}`, color: CB.text, whiteSpace: 'nowrap' }}>{c.t}</div>
          </div>
        );
      })}
    </div>
  );
}

// ---------- 0b. Solution ----------
const BENEFITS = ['One source of truth', 'Every asset precisely located', 'Every connection traceable'];
const MODULES = [
  { name: 'Navigator', d: 'Explore locations, from city down to rack', icon: 'nav' },
  { name: 'Object Management', d: 'Manage object properties, from serial number to CORIA-ID', icon: 'om' },
];
function Wordmark({ size = 110, mark = 52 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: size * 0.26 }}>
      <div style={{ width: mark, height: mark, transform: 'rotate(45deg)', borderRadius: mark * 0.16, background: `linear-gradient(135deg, ${hc(LV.city)}, ${hc(LV.rack)})` }}></div>
      <div style={{ font: `600 ${size}px ${SANS}`, color: CB.text, letterSpacing: -size * 0.03, whiteSpace: 'nowrap' }}>FNT Command</div>
    </div>
  );
}
function Solution({ T, K }) {
  const t = T - K.So;
  if (t < 0.5 || T > K.Lo + 0.2) return null;
  const out = tw(T, K.Lo - 0.7, K.Lo);
  const logo = tw(t, 0.8, 1.5, M.pop);
  const up = tw(t, 3.9, 4.6);
  const burst = t > 0.9 && t < 2.0 ? (t - 0.9) / 1.1 : -1;
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: 1 - out, transform: `scale(${lerp(1, 0.94, out)})`, transformOrigin: '960px 540px' }}>
      {burst >= 0 && <div style={{ position: 'absolute', left: 960 - 80 - burst * 500, top: 420 - 80 - burst * 500, width: 160 + burst * 1000, height: 160 + burst * 1000, borderRadius: '50%', border: `4px solid ${hc(LV.city)}`, opacity: 1 - burst, boxSizing: 'border-box' }}></div>}
      <div style={{ position: 'absolute', left: 0, right: 0, top: lerp(420, 290, up) - 66, display: 'flex', justifyContent: 'center', opacity: clampN(logo * 2), transform: `scale(${lerp(0.6, 1, logo) * lerp(1, 0.8, up)})` }}>
        <Wordmark />
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 560, display: 'flex', justifyContent: 'center', gap: 18 }}>
        {BENEFITS.map((b, i) => {
          const p = tw(t, 1.7 + i * 0.35, 2.1 + i * 0.35, M.pop) * (1 - up);
          return (
            <div key={b} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '14px 26px 14px 16px', borderRadius: 40, background: '#fff', boxShadow: SHADOW, opacity: clampN(p * 2), transform: `translateY(${(1 - Math.min(1, p)) * 20 - up * 30}px)` }}>
              <Check size={32} />
              <div style={{ font: `600 26px ${SANS}`, color: CB.text, whiteSpace: 'nowrap' }}>{b}</div>
            </div>
          );
        })}
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 440, display: 'flex', justifyContent: 'center', gap: 40 }}>
        {MODULES.map((m, i) => {
          const p = tw(t, 4.1 + i * 0.4, 4.6 + i * 0.4, M.pop);
          const col = i ? OM_C : NAV_C;
          return (
            <div key={m.name} style={{ width: 560, padding: '30px 34px', borderRadius: 24, background: '#fff', boxShadow: SHADOW, boxSizing: 'border-box', display: 'flex', gap: 24, alignItems: 'flex-start', opacity: clampN(p * 2), transform: `translateY(${(1 - Math.min(1, p)) * 40}px)` }}>
              {i ? <OMIcon size={68} /> : <NavIcon size={68} />}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <div style={{ font: `600 15px ${MONO}`, color: col, letterSpacing: 1.5, textTransform: 'uppercase' }}>Module</div>
                <div style={{ font: `600 40px ${SANS}`, color: CB.text, lineHeight: 1.05 }}>{m.name}</div>
                <div style={{ font: `400 24px ${SANS}`, color: CB.dim, lineHeight: 1.3, textWrap: 'pretty' }}>{m.d}</div>
              </div>
            </div>
          );
        })}
      </div>
      {(() => {
        const mp = tw(t, 5.6, 6.6, M.enter);
        if (mp <= 0) return null;
        return (
          <div style={{ position: 'absolute', left: 0, right: 0, top: 700, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 12 }}>
            {[0, 1, 2, 3, 4, 5].map((k) => {
              const q = clampN(mp * 3 - k * 0.25);
              return <div key={k} style={{ width: 54, height: 54, borderRadius: 14, background: `oklch(0.62 0.13 ${[285, 250, 215, 180, 150, 35][k]})`, opacity: q * 0.9, transform: `scale(${lerp(0.4, 1, q)})`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><div style={{ width: 22, height: 22, borderRadius: k % 2 ? 11 : 4, border: '3px solid rgba(255,255,255,0.85)', boxSizing: 'border-box' }}></div></div>;
            })}
            <div style={{ marginLeft: 8, padding: '12px 24px', borderRadius: 40, background: CB.navy, font: `600 24px ${SANS}`, color: '#fff', whiteSpace: 'nowrap', opacity: clampN(mp * 2 - 0.6), transform: `translateX(${(1 - clampN(mp * 2 - 0.6)) * -16}px)` }}>+ many more modules</div>
          </div>
        );
      })()}
    </div>
  );
}

// ---------- 1. World ----------
const RH = { AME: 35, WEU: 290, EEU: 175, ASI: 80 };
const RNAME = { AME: 'Americas', WEU: 'Western Europe', EEU: 'Eastern Europe', ASI: 'Asia' };
const DOTREST = '#D8D4CB';
const rcol = (h, l = 0.68, c = 0.15, al) => `oklch(${l} ${c} ${h}${al != null ? ' / ' + al : ''})`;
const FEAT = { LON: ['WEU/GB/LON', 'l'], DXB: ['ASI/AE/DXB', 'b'], KUL: ['ASI/MY/KUL', 'l'], SIN: ['ASI/SG/SIN', 'r'] };
const CITY4 = [
  { id: 'NY', code: ['AME', 'US', 'NY'], name: 'New York', r: 'AME', c: 'US' },
  { id: 'FFM', code: ['WEU', 'DE', 'FFM'], name: 'Frankfurt', r: 'WEU', c: 'DE', key: 1 },
  { id: 'SOF', code: ['EEU', 'BG', 'SOF'], name: 'Sofia', r: 'EEU', c: 'BG', below: 1 },
  { id: 'TOK', code: ['ASI', 'JP', 'TOK'], name: 'Tokyo', r: 'ASI', c: 'JP' },
];
function World({ T, K }) {
  useHue(LV.city);
  const W = window.WORLD;
  if (!W || T < K.Lo - 0.3) return null;
  const xf = zoomXf(T, null, null, 1, K.B - 0.3, [960, 540], 6);
  if (xf.display === 'none') return null;
  const t = T - K.Lo;
  const F = W.cities.FFM;
  const [fx, fy, s] = kf(t, [[0, 960, 540, 1.1], [2.0, 960, 540, 1], [4.3, 960, 540, 1], [5.4, F[0], F[1], 2.8]]);
  const scr = (p) => [(p[0] - fx) * s + 960, (p[1] - fy) * s + 540];
  const reveal = tw(t, -0.2, 2.0, M.move);
  const tintP = tw(t, 1.3, 2.3);
  const focus = tw(t, 4.3, 5.2);
  const dec = (i) => tw(t, 5.2 + i * 0.4, 5.6 + i * 0.4, M.enter);
  const ctry = tw(t, 2.0, 2.8);
  const rp = ring(t, 6.5);
  const keep = (r) => (r === 'WEU' ? 1 : 1 - focus);
  const dotCol = (r) => (r === 'rest' ? DOTREST : mix(DOTREST, rcol(RH[r], r === 'WEU' ? lerp(0.7, 0.6, dec(0)) : 0.7, 0.13), tintP * (r === 'WEU' ? 1 : 1 - 0.8 * focus)));
  return (
    <Layer xf={xf}>
      <div style={{ position: 'absolute', inset: 0, opacity: tw(T, K.Lo - 0.3, K.Lo + 0.3) }}>
        <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0 }}>
          <defs>
            <radialGradient id="wrev"><stop offset="0.8" stopColor="#fff" /><stop offset="1" stopColor="#000" /></radialGradient>
            <mask id="wmask" maskUnits="userSpaceOnUse" x="-400" y="-400" width="2720" height="1880"><circle cx={F[0]} cy={F[1]} r={Math.max(1, reveal * 1700)} fill="url(#wrev)" /></mask>
          </defs>
          <g transform={`translate(${960 - fx * s} ${540 - fy * s}) scale(${s})`}>
            <g mask="url(#wmask)">
              <path d={W.land} fill="#EAE6DD" />
              {CITY4.map((c) => {
                const isDE = c.c === 'DE';
                const al = isDE ? lerp(0.32 * ctry, 0.92, dec(1)) : 0.32 * ctry * (1 - focus);
                return <path key={c.c} d={W.countries[c.c]} fill={rcol(RH[c.r], isDE ? lerp(0.8, 0.6, dec(1)) : 0.8, isDE ? lerp(0.1, 0.16, dec(1)) : 0.1, al)} stroke={isDE && dec(1) > 0 ? '#fff' : 'none'} strokeWidth={1.4 / s} />;
              })}
              {Object.keys(W.dots).map((r) => <path key={r} d={W.dots[r]} fill="none" stroke={dotCol(r)} strokeWidth={W.sp * 0.62} strokeLinecap="round" />)}
            </g>
            {W.sec.map((c, i) => {
              const p = tw(t, 3.2 + i * 0.05, 3.9 + i * 0.05, M.move);
              return <path key={c.id} d={c.d} fill="none" stroke={rcol(RH[c.r], 0.6, 0.15)} strokeOpacity={0.7 * keep(c.r)} strokeWidth={1.8 / s} strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - p} />;
            })}
            {W.arcs.map((d, k) => {
              const p = tw(t, 2.9 + k * 0.22, 3.9 + k * 0.22, M.move);
              return (
                <g key={k} opacity={1 - 0.75 * focus}>
                  <path d={d} fill="none" stroke="oklch(0.36 0.06 265)" strokeWidth={2.6 / s} strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - p} />
                  {p >= 1 && <path d={d} fill="none" stroke="oklch(0.36 0.06 265)" strokeWidth={8 / s} strokeLinecap="round" pathLength="1" strokeDasharray="0.001 0.999" strokeDashoffset={-((T * 0.3 + k * 0.27) % 1)} />}
                </g>
              );
            })}
          </g>
          {W.sec.map((c, i) => {
            const [x, y] = scr(c.p);
            const p = tw(t, 3.0 + i * 0.05, 3.4 + i * 0.05, M.pop);
            if (p <= 0) return null;
            return (
              <g key={c.id} transform={`translate(${x} ${y}) scale(${Math.max(0, p)})`} opacity={keep(c.r)}>
                <circle r="12" fill={rcol(RH[c.r], 0.88, 0.06)} opacity="0.75" />
                <circle r="6.5" fill={rcol(RH[c.r], 0.6, 0.17)} stroke="#fff" strokeWidth="2.5" />
              </g>
            );
          })}
        </svg>
        {CITY4.map((c, i) => {
          const [x, y] = scr(W.cities[c.id]);
          const drop = tw(t, 2.2 + i * 0.18, 2.75 + i * 0.18, M.pop);
          if (drop <= 0) return null;
          return (
            <div key={c.id} style={{ position: 'absolute', left: x, top: y, opacity: clampN(drop * 3) * (c.key ? 1 : 1 - focus) }}>
              {c.key && rp >= 0 && <div style={{ position: 'absolute', left: -(14 + rp * 50), top: -(7 + rp * 25), width: 2 * (14 + rp * 50), height: 14 + rp * 50, borderRadius: '50%', border: `3px solid ${rcol(RH[c.r], 0.55, 0.17)}`, boxSizing: 'border-box', opacity: 1 - rp }}></div>}
              <div style={{ position: 'absolute', left: -10, top: -4, width: 20, height: 8, borderRadius: '50%', background: 'rgba(24,33,58,0.28)', transform: `scale(${clampN(drop)})` }}></div>
              <div style={{ position: 'absolute', left: -17, top: -41, width: 34, height: 34, transform: `translateY(${(1 - drop) * -70}px)` }}>
                <div style={{ position: 'absolute', inset: 0, borderRadius: '50% 50% 50% 0', transform: 'rotate(-45deg)', background: rcol(RH[c.r], 0.6, 0.17), boxShadow: '0 4px 10px rgba(24,33,58,0.25)' }}></div>
                <div style={{ position: 'absolute', left: 10, top: 10, width: 14, height: 14, borderRadius: 7, background: '#fff' }}></div>
              </div>
            </div>
          );
        })}
        {W.sec.filter((c) => FEAT[c.id]).map((c, i) => {
          const [x, y] = scr(c.p);
          const [code, side] = FEAT[c.id];
          const o = tw(t, 3.4 + i * 0.12, 3.8 + i * 0.12, M.enter) * (1 - focus);
          if (o <= 0) return null;
          const tf = side === 'l' ? 'translate(calc(-100% - 14px), -50%)' : side === 'r' ? 'translate(14px, -50%)' : 'translate(-50%, 14px)';
          return <div key={'f' + c.id} style={{ position: 'absolute', left: x, top: y, transform: tf, opacity: o, padding: '3px 9px', borderRadius: 8, background: '#fff', font: `600 15px ${MONO}`, color: CB.text, whiteSpace: 'nowrap', boxShadow: '0 2px 8px rgba(24,33,58,0.14)' }}>{code}</div>;
        })}
        {W.sec.filter((c) => c.r === 'WEU').map((c, i) => {
          const [x, y] = scr(c.p);
          const o = tw(t, 5.0 + i * 0.1, 5.4 + i * 0.1, M.enter);
          if (o <= 0) return null;
          return <div key={c.id} style={{ position: 'absolute', left: x, top: y + 14, transform: 'translateX(-50%)', opacity: o, padding: '2px 8px', borderRadius: 8, background: '#fff', font: `600 15px ${MONO}`, color: CB.text, boxShadow: '0 2px 8px rgba(24,33,58,0.12)' }}>{c.id}</div>;
        })}
        {CITY4.map((c, i) => {
          const [x, y] = scr(W.cities[c.id]);
          const o = tw(t, 2.5 + i * 0.18, 2.9 + i * 0.18, M.enter) * (c.key ? 1 : 1 - focus);
          if (o <= 0) return null;
          const big = c.key ? focus : 0;
          const fs = lerp(22, 46, big), cw = fs * 0.6;
          const d0 = c.key ? dec(0) : 0;
          const col = rcol(RH[c.r], 0.6, 0.17);
          const below = !!c.below;
          return (
            <div key={c.id} style={{ position: 'absolute', left: x, top: below ? y + 18 : y - 54 - 12 * big, transform: `translate(-50%, ${below ? 0 : -100}%) translateY(${(1 - o) * (below ? -8 : 8)}px)`, opacity: o }}>
              <div style={{ position: 'relative', background: '#fff', borderRadius: 14, padding: `10px 16px ${lerp(10, 54, d0)}px`, boxShadow: '0 8px 24px rgba(24,33,58,0.14)' }}>
                <div style={{ position: 'absolute', left: '50%', [below ? 'top' : 'bottom']: -6, width: 14, height: 14, background: '#fff', transform: 'translateX(-50%) rotate(45deg)' }}></div>
                <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: lerp(12, 18, big), height: lerp(12, 18, big), borderRadius: 10, background: col, flex: 'none' }}></div>
                  <div style={{ position: 'relative', display: 'flex', font: `600 ${fs}px ${MONO}`, whiteSpace: 'pre', color: CB.text }}>
                    {c.code.map((seg, k) => <span key={k} style={{ color: c.key ? mix(CB.text, C.deep, dec(k)) : CB.text }}>{(k ? '/' : '') + seg}</span>)}
                    {c.key && ['Region', 'Country', 'City'].map((l, k) => {
                      const st = [0, 4, 7][k] * cw, w = c.code[k].length * cw, p = dec(k);
                      return (
                        <div key={l} style={{ position: 'absolute', left: st, top: fs * 1.3, width: w, opacity: p, transform: `translateY(${(1 - p) * 8}px)` }}>
                          <div style={{ height: 8, borderLeft: `3px solid ${C.acc}`, borderRight: `3px solid ${C.acc}`, borderBottom: `3px solid ${C.acc}`, boxSizing: 'border-box' }}></div>
                          <div style={{ position: 'absolute', left: '50%', top: 14, transform: 'translateX(-50%)', padding: '3px 10px', borderRadius: 12, background: C.acc, font: `600 15px ${SANS}`, color: '#fff', whiteSpace: 'nowrap' }}>{l}</div>
                        </div>
                      );
                    })}
                  </div>
                </div>
                <div style={{ font: `500 17px ${SANS}`, color: CB.dim, marginTop: lerp(2, 0, d0), height: lerp(22, 0, d0), overflow: 'hidden', opacity: 1 - d0, paddingLeft: 22 }}>{c.name}</div>
              </div>
            </div>
          );
        })}
        <div style={{ position: 'absolute', left: 70, top: 600, display: 'flex', flexDirection: 'column', gap: 10, opacity: 1 - focus }}>
          {['AME', 'WEU', 'EEU', 'ASI'].map((r, i) => {
            const o = tw(t, 1.4 + i * 0.12, 1.8 + i * 0.12, M.enter);
            return (
              <div key={r} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 16px 8px 12px', borderRadius: 30, background: '#fff', boxShadow: '0 4px 14px rgba(24,33,58,0.10)', opacity: o, transform: `translateX(${(1 - o) * -16}px)`, alignSelf: 'flex-start' }}>
                <div style={{ width: 14, height: 14, borderRadius: 7, background: rcol(RH[r], 0.62, 0.16) }}></div>
                <div style={{ font: `600 18px ${MONO}`, color: CB.text }}>{r}</div>
                <div style={{ font: `400 18px ${SANS}`, color: CB.dim }}>{RNAME[r]}</div>
              </div>
            );
          })}
        </div>
      </div>
    </Layer>
  );
}

// ---------- 2. Buildings ----------
const BLDG = [
  { x: 380, w: 250, h: 300, n: 'Mainzer Landstrasse 147', f: 3 },
  { x: 810, w: 300, h: 460, n: 'Mainzer Landstrasse 151', f: 4, key: 1 },
  { x: 1290, w: 250, h: 240, n: 'Mainzer Landstrasse 155', f: 2 },
];
const TREES = [270, 700, 1190, 1640];
const SKY = [[220, 100, 210], [330, 70, 340], [520, 80, 170], [640, 120, 260], [1110, 90, 380], [1215, 70, 220], [1560, 110, 300], [1680, 80, 190]];
const GROUND = 780;
function Buildings({ T, K }) {
  useHue(LV.bldg);
  const xf = zoomXf(T, K.B - 0.3, [960, 540], 6, K.Fl - 0.3, [960, 550], 2.6);
  if (xf.display === 'none') return null;
  const s = sel(T, K.Fl - 1.5);
  const rp = ring(T, K.Fl - 1.5);
  const g = tw(T, K.B + 0.3, K.B + 1.1);
  return (
    <Layer xf={xf}>
      <div style={{ position: 'absolute', left: 960 - 800 * g, top: GROUND, width: 1600 * g, height: 70, borderRadius: '0 0 40px 40px', background: 'oklch(0.92 0.02 90)' }}></div>
      {SKY.map(([x, w, h], i) => {
        const p = tw(T, K.B + 0.3 + i * 0.05, K.B + 0.9 + i * 0.05, M.enter);
        return <div key={'s' + i} style={{ position: 'absolute', left: x, top: GROUND - h, width: w, height: h, transform: `scaleY(${p})`, transformOrigin: 'bottom', background: `oklch(0.91 0.03 ${LV.bldg})`, borderRadius: '6px 6px 0 0' }}></div>;
      })}
      {TREES.map((x, i) => {
        const p = tw(T, K.B + 1.0 + i * 0.12, K.B + 1.5 + i * 0.12, M.pop);
        return (
          <div key={i} style={{ position: 'absolute', left: x - 34, top: GROUND - 110, width: 68, height: 110, transform: `scale(${Math.max(0, p)})`, transformOrigin: 'bottom' }}>
            <div style={{ position: 'absolute', left: 30, top: 60, width: 8, height: 50, borderRadius: 3, background: 'oklch(0.55 0.06 60)' }}></div>
            <div style={{ position: 'absolute', left: 0, top: 0, width: 68, height: 68, borderRadius: 34, background: 'oklch(0.76 0.12 145)' }}></div>
          </div>
        );
      })}
      {BLDG.map((b, i) => {
        const rise = tw(T, K.B + 0.6 + i * 0.2, K.B + 1.3 + i * 0.2, M.pop);
        const on = b.key ? s : 0;
        const lo = tw(T, K.B + 1.0 + i * 0.2, K.B + 1.4 + i * 0.2, M.enter);
        return (
          <div key={i}>
            <div style={{ position: 'absolute', left: b.x, top: GROUND - b.h, width: b.w, height: b.h, transform: `scaleY(${Math.max(0, rise)})`, transformOrigin: 'bottom', background: mix(C.tint2, C.acc, on), borderRadius: '8px 8px 0 0', boxShadow: on ? `0 0 0 6px ${C.tint2}` : 'none' }}>
              {b.key && <div style={{ position: 'absolute', left: b.w / 2 - 3, top: -46, width: 6, height: 46, background: mix(C.tint2, C.acc, on) }}></div>}
              {b.key && <div style={{ position: 'absolute', left: b.w / 2 - 9, top: -58, width: 18, height: 18, borderRadius: 9, background: mix(C.tint2, C.acc, on) }}></div>}
              {Array.from({ length: b.f - 1 }).map((_, k) => <div key={k} style={{ position: 'absolute', left: 0, right: 0, top: ((k + 1) * b.h) / b.f - 2, height: 4, background: 'rgba(255,255,255,0.45)' }}></div>)}
              {Array.from({ length: b.f }).map((_, k) => (
                <div key={k} style={{ position: 'absolute', left: 26, right: 26, top: (k * b.h) / b.f + b.h / b.f / 2 - 14, display: 'flex', justifyContent: 'space-between' }}>
                  {Array.from({ length: Math.floor(b.w / 62) }).map((_, j) => <div key={j} style={{ width: 28, height: 28, borderRadius: 4, background: (j + k) % 3 === 0 && on > 0.5 ? 'oklch(0.92 0.12 90)' : 'rgba(255,255,255,0.7)' }}></div>)}
                </div>
              ))}
              {b.key && <div style={{ position: 'absolute', left: b.w / 2 - 30, bottom: 0, width: 60, height: 70, borderRadius: '30px 30px 0 0', background: 'rgba(255,255,255,0.75)' }}></div>}
            </div>
            {b.key && rp >= 0 && <div style={{ position: 'absolute', left: b.x - 14 - rp * 30, top: GROUND - b.h - 14 - rp * 30, width: b.w + 28 + rp * 60, height: b.h + 14 + rp * 30, border: `3px solid ${C.acc}`, borderBottom: 'none', borderRadius: 14, opacity: 1 - rp, boxSizing: 'border-box' }}></div>}
            <div style={{ position: 'absolute', left: b.x - 60, width: b.w + 120, top: GROUND + 20, display: 'flex', justifyContent: 'center', opacity: lo }}>
              <div style={{ padding: '6px 16px', borderRadius: 20, background: on > 0.5 ? C.acc : '#fff', font: `600 22px ${SANS}`, color: on > 0.5 ? '#fff' : CB.text, whiteSpace: 'nowrap', boxShadow: '0 2px 8px rgba(24,33,58,0.1)' }}>{b.n}</div>
            </div>
          </div>
        );
      })}
    </Layer>
  );
}

// ---------- 3. Floors ----------
const FL = [['Floor 0', 'Reception · loading bay'], ['Floor 1', 'Offices'], ['Floor 2', 'Technical rooms', 1], ['Floor 3', 'Offices']];
const FCX = 820, FY0 = 720, FGAP = 118, FSL = 170;
function Floors({ T, K }) {
  useHue(LV.floor);
  const xf = zoomXf(T, K.Fl - 0.3, [960, 550], 2.6, K.Ro - 0.3, [FCX + FSL, FY0 - 2 * FGAP], 3);
  if (xf.display === 'none') return null;
  const s = sel(T, K.Ro - 1.8);
  const slide = tw(T, K.Ro - 1.8, K.Ro - 1.0, M.move);
  return (
    <Layer xf={xf}>
      {FL.map(([n, u, key], b) => {
        const o = tw(T, K.Fl + 0.4 + b * 0.2, K.Fl + 0.9 + b * 0.2, M.enter);
        const on = key ? s : 0;
        const dx = key ? FSL * slide : 0;
        const dy = (1 - o) * -80;
        const cy = FY0 - b * FGAP;
        const fade = key ? 1 : 1 - 0.45 * slide;
        const plate = (off, bg, extra) => (
          <div style={{ position: 'absolute', left: FCX - 200, top: cy - 200 + off, width: 400, height: 400, transform: `translate(${dx}px, ${dy}px) rotateX(60deg) rotateZ(-45deg)`, borderRadius: 14, background: bg, ...extra }}></div>
        );
        return (
          <div key={n} style={{ opacity: o * fade }}>
            {plate(18, mix(`oklch(0.76 0.08 ${LV.floor})`, C.deep, on))}
            {plate(0, mix(`oklch(0.92 0.045 ${LV.floor})`, C.acc, on), { backgroundImage: 'linear-gradient(rgba(255,255,255,0.55) 3px, transparent 3px), linear-gradient(90deg, rgba(255,255,255,0.55) 3px, transparent 3px)', backgroundSize: '100px 100px, 133px 133px', backgroundPosition: '-1px -1px' })}
            <div style={{ position: 'absolute', left: FCX + 283 + dx, top: cy + dy - 1, width: 60, height: 3, background: on > 0.5 ? C.acc : CB.line2 }}></div>
            <div style={{ position: 'absolute', left: FCX + 356 + dx, top: cy - 30 + dy, display: 'flex', flexDirection: 'column', gap: 2 }}>
              <div style={{ font: `600 32px ${MONO}`, color: on > 0.5 ? C.deep : CB.text, whiteSpace: 'nowrap' }}>{n}</div>
              <div style={{ font: `400 22px ${SANS}`, color: CB.dim, whiteSpace: 'nowrap' }}>{u}</div>
            </div>
          </div>
        );
      })}
    </Layer>
  );
}

// ---------- 4. Room choice (isometric floor plan) ----------
const FP_O = [769, 196], WALL = 56;
const FROOMS = [
  { id: '2.10', u: 'Office', x: 0, y: 0, w: 360, d: 300, f: 'desk' },
  { id: '2.11', u: 'Office', x: 360, y: 0, w: 360, d: 300, f: 'desk' },
  { id: '2.12', u: 'Meeting', x: 720, y: 0, w: 580, d: 300, f: 'meet' },
  { id: '2.13', u: 'Storage', x: 0, y: 420, w: 400, d: 340, f: 'shelf' },
  { id: '2.14', u: 'Server room', x: 400, y: 420, w: 520, d: 340, f: 'rack', key: 1 },
  { id: '2.15', u: 'UPS / power', x: 920, y: 420, w: 380, d: 340, f: 'ups' },
];
const KEYROOM = iso(FP_O, 660, 590, 0);
const N3 = { top: CB.navyTop, sy: CB.navy, sx: CB.navy2 };
const WALL0 = { top: '#FFFFFF', sy: '#E8E5DE', sx: '#D3CFC6' };
const FCOL = { desk: shade(70, 0.86, 0.03), mon: N3, chair: shade(255, 0.7, 0.05), table: shade(70, 0.86, 0.03), shelf: shade(255, 0.8, 0.03), rack: N3, ups: shade(80, 0.8, 0.12), batt: { top: '#46516E', sy: CB.navy3, sx: CB.navy } };
function furn(r) {
  const B = [];
  if (r.f === 'desk') for (const [dx, dy] of [[40, 50], [200, 50], [40, 180], [200, 180]]) { B.push([r.x + dx, r.y + dy, 120, 64, 26, 'desk']); B.push([r.x + dx + 40, r.y + dy + 8, 50, 10, 34, 'mon', 26]); }
  if (r.f === 'meet') { B.push([r.x + 120, r.y + 90, 340, 120, 26, 'table']); for (let i = 0; i < 4; i++) { B.push([r.x + 140 + i * 80, r.y + 46, 40, 30, 20, 'chair']); B.push([r.x + 140 + i * 80, r.y + 224, 40, 30, 20, 'chair']); } }
  if (r.f === 'shelf') { B.push([r.x + 40, r.y + 40, 320, 50, 110, 'shelf']); B.push([r.x + 40, r.y + 190, 320, 50, 110, 'shelf']); }
  if (r.f === 'rack') for (let i = 0; i < 5; i++) { B.push([r.x + 50 + i * 86, r.y + 50, 66, 70, 150, 'rack']); B.push([r.x + 50 + i * 86, r.y + 220, 66, 70, 150, 'rack']); }
  if (r.f === 'ups') { B.push([r.x + 50, r.y + 50, 120, 90, 120, 'ups']); B.push([r.x + 200, r.y + 50, 120, 90, 120, 'ups']); B.push([r.x + 50, r.y + 210, 270, 70, 80, 'batt']); }
  return B.sort((a, b) => a[0] + a[1] - (b[0] + b[1]));
}
function FloorPlan({ T, K }) {
  useHue(LV.room);
  const xf = zoomXf(T, K.Ro - 0.3, [FCX + FSL, FY0 - 2 * FGAP], 3, K.Ra - 0.3, KEYROOM, 2.7);
  if (xf.display === 'none') return null;
  const o = FP_O;
  const s = sel(T, K.Ra - 1.6), rp = ring(T, K.Ra - 1.6);
  const slab = tw(T, K.Ro, K.Ro + 0.6, M.enter);
  const key = shade(LV.room, 0.66, 0.12);
  const cl = [iso(o, 20, 360), iso(o, 1280, 360)];
  return (
    <Layer xf={xf}>
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
        <g opacity={slab}>
          <IsoBox o={o} x={0} y={0} z={-28} w={1300} d={760} h={28} top="#FFFFFF" sy="#DDD9D0" sx="#C9C4BA" />
          <polygon points={isoRect(o, 0, 300, 1300, 120)} fill="#F8F7F3" />
          <line x1={cl[0][0]} y1={cl[0][1]} x2={cl[1][0]} y2={cl[1][1]} stroke="#D6D2C8" strokeWidth="3" strokeDasharray="14 12" />
        </g>
        {FROOMS.map((r, i) => {
          const on = r.key ? s : 0, lift = 28 * on;
          const fo = tw(T, K.Ro + 0.3 + i * 0.1, K.Ro + 0.7 + i * 0.1, M.enter);
          const wp = tw(T, K.Ro + 0.5 + i * 0.1, K.Ro + 1.0 + i * 0.1, M.enter);
          const fp = tw(T, K.Ro + 0.9 + i * 0.08, K.Ro + 1.4 + i * 0.08, M.pop);
          const wc = r.key ? { top: mix(WALL0.top, key.top, on), sy: mix(WALL0.sy, key.sy, on), sx: mix(WALL0.sx, key.sx, on) } : WALL0;
          return (
            <g key={r.id} opacity={fo}>
              {on > 0 && <polygon points={isoRect(o, r.x + 14, r.y + 14, r.w - 4, r.d - 4, 0)} fill="rgba(24,33,58,0.18)" />}
              <polygon points={isoRect(o, r.x + 4, r.y + 4, r.w - 8, r.d - 8, lift)} fill={r.key ? mix('#ECE8E0', tint2(LV.room), on) : '#ECE8E0'} />
              {r.key && <polygon points={isoRect(o, r.x + 40, r.y + 130, r.w - 80, 80, lift)} fill="oklch(0.9 0.05 220)" />}
              <IsoBox o={o} x={r.x} y={r.y} z={lift} w={r.w} d={10} h={WALL * wp} {...wc} />
              <IsoBox o={o} x={r.x} y={r.y} z={lift} w={10} d={r.d} h={WALL * wp} {...wc} />
              {furn(r).map(([x, y, w, d, h, kind, z = 0], j) => <IsoBox key={j} o={o} x={x} y={y} z={lift + z * fp} w={w} d={d} h={Math.max(0.1, h * fp)} {...FCOL[kind]} />)}
              {r.key && rp >= 0 && <polygon points={isoRect(o, r.x - rp * 70, r.y - rp * 70, r.w + rp * 140, r.d + rp * 140, lift)} fill="none" stroke={C.acc} strokeWidth="3" opacity={1 - rp} />}
            </g>
          );
        })}
      </svg>
      {FROOMS.map((r, i) => {
        const on = r.key ? s : 0;
        const [cx, cy] = iso(o, r.x + r.w / 2, r.y + r.d / 2, 28 * on + 40);
        const lo = tw(T, K.Ro + 1.3 + i * 0.08, K.Ro + 1.7 + i * 0.08, M.enter);
        const rise = 150 * on;
        return (
          <div key={r.id} style={{ opacity: lo }}>
            {on > 0 && <div style={{ position: 'absolute', left: cx - 1.5, top: cy - rise, width: 3, height: rise, background: C.acc }}></div>}
            {on > 0 && <div style={{ position: 'absolute', left: cx - 7, top: cy - 7, width: 14, height: 14, borderRadius: 7, background: C.acc }}></div>}
            <div style={{ position: 'absolute', left: cx, top: cy - rise, transform: `translate(-50%, ${lerp(-50, -100, on)}%) scale(${lerp(1, 1.3, on)})`, transformOrigin: '50% 100%', display: 'flex', alignItems: 'baseline', gap: 10, padding: '8px 16px', borderRadius: 24, background: mix('#ffffff', C.acc, on), boxShadow: '0 4px 14px rgba(24,33,58,0.14)', whiteSpace: 'nowrap' }}>
              <div style={{ font: `600 22px ${MONO}`, color: on > 0.5 ? '#fff' : CB.text }}>{r.id}</div>
              <div style={{ font: `500 17px ${SANS}`, color: on > 0.5 ? '#fff' : CB.dim }}>{r.u}</div>
            </div>
          </div>
        );
      })}
    </Layer>
  );
}

// ---------- 5. Rack choice (isometric server room) ----------
const RM_O = [840, 330];
const RKD = { w: 110, d: 90, h: 260 };
const RROWS = [0, 1].flatMap((row) => Array.from({ length: 5 }).map((_, i) => ({ id: 'R' + String(row ? i + 1 : i + 6).padStart(2, '0'), x: 80 + i * 150, y: row ? 330 : 80, row, i, key: row === 1 && i === 3 })));
const RK_F = iso(RM_O, 585, 480, 144);
function IsoRack({ o, x, y, z, T, seed, hi }) {
  const { w, d, h } = RKD, fy = y + d;
  const P = (a, b, c) => iso(o, a, b, c);
  const face = (x0, x1, z0, z1) => pts([P(x0, fy, z0), P(x1, fy, z0), P(x1, fy, z1), P(x0, fy, z1)]);
  const hd = [P(x + w - 20, fy, z + 70), P(x + w - 20, fy, z + 130)];
  return (
    <g>
      <IsoBox o={o} x={x} y={y} z={z} w={w} d={d} h={h} top={mix(CB.navyTop, hc(LV.rack), hi)} sy={CB.navy} sx={CB.navy2} />
      <polygon points={face(x + 10, x + w - 10, z + 14, z + h - 14)} fill="#222B42" stroke={hi > 0.5 ? hc(LV.rack) : '#2F3A57'} strokeWidth={hi > 0.5 ? 3 : 2} />
      {Array.from({ length: 8 }).map((_, k) => { const zz = z + 40 + k * 24; const A = P(x + 18, fy, zz), B = P(x + w - 36, fy, zz); return <line key={k} x1={A[0]} y1={A[1]} x2={B[0]} y2={B[1]} stroke="#303B59" strokeWidth="3" strokeLinecap="round" />; })}
      {[0, 1, 2, 3].map((k) => { const p = P(x + w - 20, fy, z + h - 34 - k * 16); return <circle key={k} cx={p[0]} cy={p[1]} r="3.2" fill={k === 3 ? AMBER : LED} opacity={blink(T, seed + k)} />; })}
      <line x1={hd[0][0]} y1={hd[0][1]} x2={hd[1][0]} y2={hd[1][1]} stroke="#5B6785" strokeWidth="4" strokeLinecap="round" />
    </g>
  );
}
function Room({ T, K }) {
  useHue(LV.rack);
  const xf = zoomXf(T, K.Ra - 0.3, KEYROOM, 2.7, K.Ra + 2.8, RK_F, 4.2);
  if (xf.display === 'none') return null;
  const o = RM_O;
  const s = sel(T, K.Ra + 1.6), rp = ring(T, K.Ra + 1.6);
  const wo = tw(T, K.Ra + 0.1, K.Ra + 0.6, M.enter);
  const wp = tw(T, K.Ra + 0.3, K.Ra + 0.8, M.enter);
  const grid = [];
  for (let gx = 60; gx < 900; gx += 60) { const a = iso(o, gx, 0), b = iso(o, gx, 560); grid.push([a, b]); }
  for (let gy = 60; gy < 560; gy += 60) { const a = iso(o, 0, gy), b = iso(o, 900, gy); grid.push([a, b]); }
  const perf = [];
  for (let gx = 70; gx < 860; gx += 40) for (let gy = 190; gy < 320; gy += 40) perf.push(iso(o, gx, gy));
  return (
    <Layer xf={xf}>
      <svg width="1920" height="1080" style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
        <g opacity={wo}>
          <IsoBox o={o} x={0} y={0} z={-22} w={900} d={560} h={22} top="#ECE8E0" sy="#DDD9D0" sx="#C9C4BA" />
          {grid.map(([a, b], k) => <line key={k} x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke="#DDD8CF" strokeWidth="1.5" />)}
          <polygon points={isoRect(o, 40, 175, 820, 150)} fill="oklch(0.91 0.045 220)" />
          {perf.map((p, k) => <circle key={k} cx={p[0]} cy={p[1]} r="2.2" fill="oklch(0.80 0.07 220)" />)}
          <IsoBox o={o} x={0} y={0} w={900} d={12} h={90 * wp} {...WALL0} />
          <IsoBox o={o} x={0} y={0} w={12} d={560} h={90 * wp} {...WALL0} />
        </g>
        {RROWS.map((r) => {
          const p = tw(T, K.Ra + 0.4 + (r.row * 5 + r.i) * 0.06, K.Ra + 0.9 + (r.row * 5 + r.i) * 0.06, M.pop);
          if (p <= 0) return null;
          const on = r.key ? s : 0;
          return (
            <g key={r.id} opacity={clampN(p * 2)}>
              {on > 0 && <polygon points={isoRect(o, r.x + 8, r.y + 60 * on + 8, RKD.w, RKD.d, 0)} fill="rgba(24,33,58,0.22)" />}
              <IsoRack o={o} x={r.x} y={r.y + 60 * on} z={14 * on + (1 - p) * 140} T={T} seed={r.i + r.row * 5} hi={on} />
              {r.key && rp >= 0 && <polygon points={isoRect(o, r.x - rp * 50, r.y + 60 * on - rp * 50, RKD.w + rp * 100, RKD.d + rp * 100, 0)} fill="none" stroke={C.acc} strokeWidth="3" opacity={1 - rp} />}
            </g>
          );
        })}
      </svg>
      {RROWS.filter((r) => r.row === 1).map((r) => {
        const on = r.key ? s : 0;
        const lo = tw(T, K.Ra + 1.0 + r.i * 0.06, K.Ra + 1.4 + r.i * 0.06, M.enter);
        const [bx, by] = iso(o, r.x + 55, r.y + 90 + 50, 0);
        const [tx, ty] = iso(o, r.x + 55, r.y + 45 + 60 * s, RKD.h + 14 * s + 40);
        return (
          <div key={r.id} style={{ position: 'absolute', left: lerp(bx, tx, on), top: lerp(by, ty, on), transform: `translate(-50%, ${lerp(-50, -100, on)}%)`, opacity: lo, display: 'flex', alignItems: 'baseline', gap: 10, padding: `${lerp(4, 10, on)}px ${lerp(12, 20, on)}px`, borderRadius: 20, background: mix('#ffffff', C.acc, on), boxShadow: '0 4px 14px rgba(24,33,58,0.14)', whiteSpace: 'nowrap' }}>
            <div style={{ font: `600 ${lerp(18, 28, on)}px ${MONO}`, color: on > 0.5 ? '#fff' : CB.text }}>{r.id}</div>
            {r.key && on > 0.05 && <div style={{ font: `500 18px ${SANS}`, color: '#fff', opacity: on }}>RITTAL-42 · 42 U</div>}
          </div>
        );
      })}
    </Layer>
  );
}

// ---------- 6. Rack elevation ----------
const OX = 690, OY = 160, UY = 113, UH = 40;
const RACKS = [
  { x: 120, name: 'R04', slots: [[0, 1, 'PC5-1002', 'pp'], [2, 2, 'RTR-1101', 'rtr', 1], [5, 2, 'FW-1102', 'fw'], [7, 1, 'SW-1103', 'sw'], [9, 1, 'SRV-1204', 'srv'], [10, 1, 'SRV-1205', 'srv'], [12, 2, 'UPS-1301', 'ups']] },
  { x: 560, name: 'R05', slots: [[0, 1, 'PC5-2001', 'pp'], [2, 2, 'RTR-2101', 'rtr'], [5, 1, 'SW-2103', 'sw'], [7, 2, 'STO-2201', 'sto'], [10, 1, 'SRV-2207', 'srv']] },
];
const FACE = {
  pp: { bg: '#E7EAF1', ink: '#1C2438', type: 'PC5-16RJ45' },
  rtr: { bg: 'oklch(0.48 0.14 275)', ink: '#fff', type: 'ASR1002-X' },
  fw: { bg: 'oklch(0.52 0.10 200)', ink: '#fff', type: 'FPR-2130' },
  sw: { bg: 'oklch(0.55 0.13 245)', ink: '#fff', type: 'C9300-48T' },
  srv: { bg: '#D7DCE6', ink: '#1C2438', type: 'DL380 G10' },
  sto: { bg: 'oklch(0.60 0.06 290)', ink: '#fff', type: 'MSA 2060' },
  ups: { bg: 'oklch(0.80 0.13 80)', ink: '#1C2438', type: 'SRT3000' },
};
const CABLE = 'M268 240 C268 196 327 186 327 135 C327 70 340 29 400 29 L700 29 C754 29 767 70 767 135 C767 186 708 196 708 240';
const PLUGS = [[268, 240, 0.01], [327, 135, 0.15], [767, 135, 0.85], [708, 240, 0.98]];
const TRACE = [
  ['RTR-1101 · Gi0/1', 'ASR1002-X · R04 / U39', 0.02],
  ['PC5-1002 · Port 12', 'PC5-16RJ45 · R04 / U42', 0.15],
  ['CBL-11873', 'Cat6A · 14 m', 0.5],
  ['PC5-2001 · Port 12', 'PC5-16RJ45 · R05 / U42', 0.85],
  ['RTR-2101 · Gi0/1', 'ASR1002-X · R05 / U39', 0.98],
];
function Device({ rx, s, k, T, K, cableP }) {
  const [i, u, name, kind, isSel] = s;
  const top = UY + i * UH + 2, h = u * UH - 4, W = 256;
  const pin = tw(T, K.Ra + 3.5 + k * 0.14, K.Ra + 3.9 + k * 0.14, M.pop);
  const on = isSel ? Math.max(tw(T, K.Pr + 0.3, K.Pr + 0.7, M.enter) * (1 - tw(T, K.Ca, K.Ca + 0.5)), tw(T, K.Ca + 1.0, K.Ca + 1.4, M.enter)) : 0;
  const F = FACE[kind], left = rx < 300, dark = F.ink === '#fff';
  const hole = dark ? 'rgba(8,12,24,0.6)' : '#2A3248';
  const el = [];
  const port = (key, x, y, w, ph, lit) => el.push(<div key={key} style={{ position: 'absolute', left: x, top: y, width: w, height: ph, borderRadius: 2, background: lit ? CORAL : hole, boxShadow: lit ? `0 0 0 3px ${CORAL_S}` : 'none' }}></div>);
  const led = (key, x, y, seed, col = LED) => el.push(<div key={key} style={{ position: 'absolute', left: x, top: y, width: 6, height: 6, borderRadius: 3, background: col, opacity: blink(T, seed + k) }}></div>);
  const bay = (key, x, y, w, bh) => el.push(<div key={key} style={{ position: 'absolute', left: x, top: y, width: w, height: bh, borderRadius: 3, background: dark ? 'rgba(255,255,255,0.18)' : '#B8C0CF', boxShadow: 'inset 0 -2px 0 rgba(0,0,0,0.12)' }}></div>);
  const label = (x, y, size) => el.push(<div key="nm" style={{ position: 'absolute', left: x, top: y, font: `600 ${size}px ${MONO}`, color: F.ink, whiteSpace: 'nowrap' }}>{name}</div>);
  const sub = (x, y) => el.push(<div key="tp" style={{ position: 'absolute', left: x, top: y, font: `500 11px ${SANS}`, color: F.ink, opacity: 0.75, whiteSpace: 'nowrap' }}>{F.type}</div>);
  if (kind === 'pp') {
    for (let j = 0; j < 16; j++) {
      el.push(<div key={'n' + j} style={{ position: 'absolute', left: 12 + j * 15, top: 1, width: 16, textAlign: 'center', font: `600 8px ${MONO}`, color: '#59627A' }}>{j + 1}</div>);
      port('p' + j, 14 + j * 15, 14, 12, 12, j === 11 && cableP > (left ? 0.15 : 0.85));
    }
  } else if (kind === 'rtr') {
    label(14, 10, 14); sub(14, 30);
    led('pw', 14, 56, 0.3); led('sy', 26, 56, 1.9, AMBER);
    for (let j = 0; j < 8; j++) { const px = 120 + j * 16 + (j > 3 ? 8 : 0); led('l' + j, px + 3, 28, j * 0.7); port('p' + j, px, 40, 12, 10, j === 0 && cableP > (left ? 0.01 : 0.97)); }
  } else if (kind === 'fw') {
    label(14, 10, 14); sub(14, 30); led('pw', 14, 56, 0.8);
    el.push(<div key="lcd" style={{ position: 'absolute', left: 130, top: 18, width: 66, height: 28, borderRadius: 4, background: '#0E1424', font: `600 12px ${MONO}`, color: LED, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>OK</div>);
    for (let j = 0; j < 5; j++) el.push(<div key={'v' + j} style={{ position: 'absolute', left: 210 + j * 8, top: 12, width: 4, height: 50, borderRadius: 2, background: 'rgba(8,12,24,0.35)' }}></div>);
  } else if (kind === 'sw') {
    label(8, 11, 10);
    for (let j = 0; j < 12; j++) { port('a' + j, 62 + j * 13, 6, 10, 8); port('b' + j, 62 + j * 13, 20, 10, 8); }
    for (let j = 0; j < 4; j++) port('s' + j, 222 + j * 8, 10, 6, 14);
  } else if (kind === 'srv') {
    label(8, 11, 10);
    for (let j = 0; j < 6; j++) { bay('b' + j, 66 + j * 28, 6, 24, 24); led('d' + j, 66 + j * 28 + 17, 9, j * 1.3, 'oklch(0.72 0.14 240)'); }
    el.push(<div key="pb" style={{ position: 'absolute', left: 238, top: 11, width: 12, height: 12, borderRadius: 6, border: `2px solid ${OKG}`, boxSizing: 'border-box' }}></div>);
  } else if (kind === 'sto') {
    label(14, 10, 14); sub(14, 30);
    for (let r2 = 0; r2 < 2; r2++) for (let j = 0; j < 6; j++) { bay(`b${r2}${j}`, 108 + j * 24, 6 + r2 * 34, 20, 28); led(`d${r2}${j}`, 108 + j * 24 + 7, 10 + r2 * 34, j + r2 * 3, 'oklch(0.85 0.12 240)'); }
  } else if (kind === 'ups') {
    label(14, 10, 14); sub(14, 30);
    el.push(<div key="lcd" style={{ position: 'absolute', left: 130, top: 16, width: 90, height: 36, borderRadius: 4, background: '#0E1424', padding: 7, boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: 5 }}><div style={{ font: `600 10px ${MONO}`, color: AMBER }}>100%</div><div style={{ height: 5, borderRadius: 3, background: AMBER }}></div></div>);
    led('a', 234, 20, 0.2); led('b', 234, 34, 1.1); led('c', 234, 48, 2.0, AMBER);
  }
  return (
    <div style={{ position: 'absolute', left: rx + 22, top, width: W, height: h, opacity: clampN(pin * 2), transform: `translateX(${(1 - pin) * 70}px)`, background: F.bg, borderRadius: 4, boxShadow: on ? `0 0 0 3px ${C.acc}, 0 0 26px ${hc(LV.rack, 0.55)}` : 'inset 0 -3px 0 rgba(0,0,0,0.12), inset 0 1px 0 rgba(255,255,255,0.25)' }}>
      {el}
    </div>
  );
}
function Cabinet({ r, isKey, hiP, T }) {
  const rx = r.x;
  const holes = [];
  for (let k = 0; k < 14; k++) for (let q = 0; q < 3; q++) for (const hx of [rx + 11, rx + 283]) holes.push(<div key={k + '-' + q + '-' + hx} style={{ position: 'absolute', left: hx, top: UY + k * UH + 6 + q * 12, width: 5, height: 5, borderRadius: 1, background: CB.navy2 }}></div>);
  return (
    <>
      <svg width="1" height="1" style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible' }}>
        <polygon points={`${rx + 6},80 ${rx + 42},54 ${rx + 338},54 ${rx + 300},80`} fill={CB.navyTop} />
        <polygon points={`${rx + 300},80 ${rx + 338},54 ${rx + 338},680 ${rx + 300},706`} fill={CB.navy2} />
        {Array.from({ length: 9 }).map((_, k) => <line key={k} x1={rx + 310} y1={140 + k * 56} x2={rx + 328} y2={128 + k * 56} stroke={CB.navy3} strokeWidth="3" strokeLinecap="round" />)}
      </svg>
      <div style={{ position: 'absolute', left: rx, top: 80, width: 300, height: 626, background: CB.navy, borderRadius: '8px 0 6px 8px', boxShadow: isKey ? `0 0 0 ${lerp(0, 5, hiP)}px ${C.acc}` : 'none' }}></div>
      <div style={{ position: 'absolute', left: rx + 6, top: 110, width: 16, height: 566, borderRadius: 3, background: CB.navy3 }}></div>
      <div style={{ position: 'absolute', left: rx + 278, top: 110, width: 16, height: 566, borderRadius: 3, background: CB.navy3 }}></div>
      {holes}
      <div style={{ position: 'absolute', left: rx + 26, top: 92, width: 6, height: 6, borderRadius: 3, background: LED, opacity: blink(T, rx) }}></div>
      <div style={{ position: 'absolute', left: rx + 110, top: 86, width: 80, height: 20, borderRadius: 4, background: CB.navy3, display: 'flex', alignItems: 'center', justifyContent: 'center', font: `600 13px ${MONO}`, color: '#fff' }}>{r.name}</div>
      {Array.from({ length: 14 }).map((_, k) => <div key={'u' + k} style={{ position: 'absolute', left: rx - 36, top: UY + k * UH + 11, width: 28, textAlign: 'right', font: `600 14px ${MONO}`, color: CB.dim }}>{42 - k}</div>)}
      <div style={{ position: 'absolute', left: rx + 30, top: 682, width: 240, height: 14, borderRadius: 3, background: `repeating-linear-gradient(90deg, ${CB.navy3} 0 6px, transparent 6px 11px)` }}></div>
      <div style={{ position: 'absolute', left: rx + 18, top: 706, width: 24, height: 10, borderRadius: '0 0 4px 4px', background: CB.navy2 }}></div>
      <div style={{ position: 'absolute', left: rx + 258, top: 706, width: 24, height: 10, borderRadius: '0 0 4px 4px', background: CB.navy2 }}></div>
    </>
  );
}

// ---------- Object Management panel ----------
const OGROUPS = [
  ['General', [['Visible-ID', 'RTR-1101'], ['Object type', 'ASR1002-X · Router, 2 U'], ['Manufacturer', 'Cisco'], ['Serial number', 'FOX2417P1AB'], ['Asset tag', 'AT-0048213'], ['Status', 'In service']]],
  ['Network', [['Hostname', 'ffm-rtr-1101'], ['Management IP', '10.48.12.21'], ['OS version', 'IOS XE 17.9.4'], ['MAC address', '00:1A:2B:3C:4D:5E']]],
  ['Location', [['Rack position', 'R04 · U39–40'], ['Room', '2.14 · Floor 2'], ['Building', 'Mainzer Landstrasse 151']]],
  ['Lifecycle', [['Purchase date', '2023-03-14'], ['Warranty end', '2028-03-31'], ['Support contract', 'SC-77120']]],
  ['Ownership', [['CORIA-ID', '41-17-06'], ['Cost centre', '4711-NET'], ['Responsible', 'Network Operations']]],
];
const OROWS = (() => {
  const rows = []; let y = 0;
  OGROUPS.forEach(([g, list], gi) => { rows.push({ head: g, y, gi }); y += 42; list.forEach(([l, v]) => { rows.push({ l, v, y, gi }); y += 56; }); });
  return { rows, heads: rows.filter((r) => r.head).map((r) => r.y), total: y };
})();
const VH = 392;
const HI_AT = { 'Serial number': 2.0, 'Management IP': 4.4, 'CORIA-ID': 8.6 };
function ObjectPanel({ T, K }) {
  const t = T - K.Pr;
  const o = tw(t, 0.4, 0.9, M.enter) * (1 - tw(T, K.Ca, K.Ca + 0.6));
  if (o <= 0) return null;
  const line = tw(t, 0.3, 0.9, M.move);
  const H = OROWS.heads, mx = OROWS.total - VH;
  const [scroll] = kf(t, [[0, 0], [3.0, 0], [3.8, H[1]], [5.4, H[1]], [6.0, H[2]], [6.6, H[2]], [7.2, H[3]], [7.6, H[3]], [8.2, mx]]);
  const tab = scroll >= mx - 2 ? H.length - 1 : H.reduce((a, y, i) => (y <= scroll + 60 ? i : a), 0);
  return (
    <>
      <svg width="1" height="1" style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible', opacity: o }}>
        <line x1="142" y1="233" x2={lerp(142, -110, line)} y2="233" stroke={OM_C} strokeWidth="3" />
        <circle cx="142" cy="233" r="7" fill={OM_C} />
      </svg>
      <div style={{ position: 'absolute', left: -620, top: 64, width: 510, opacity: o, transform: `translateX(${(1 - o) * -24}px)`, background: '#fff', borderRadius: 20, overflow: 'hidden', boxShadow: SHADOW }}>
        <div style={{ background: OM_C, padding: '18px 26px', display: 'flex', alignItems: 'center', gap: 18 }}>
          <OMIcon size={48} col="rgba(255,255,255,0.22)" />
          <div>
            <div style={{ font: `600 14px ${MONO}`, color: '#fff', letterSpacing: 1.5, textTransform: 'uppercase', opacity: 0.9 }}>Object Management</div>
            <div style={{ font: `600 34px ${MONO}`, color: '#fff', marginTop: 2 }}>RTR-1101</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 4, padding: '0 14px', borderBottom: `1px solid ${CB.line}` }}>
          {OGROUPS.map(([g], i) => <div key={g} style={{ padding: '13px 8px 11px', font: `600 16px ${SANS}`, color: i === tab ? deep(150) : CB.dim, borderBottom: `3px solid ${i === tab ? OM_C : 'transparent'}`, whiteSpace: 'nowrap' }}>{g}</div>)}
        </div>
        <div style={{ position: 'relative', height: VH, overflow: 'hidden' }}>
          <div style={{ position: 'absolute', left: 0, right: 0, top: -scroll }}>
            {OROWS.rows.map((r, i) => {
              const ro = tw(t, 0.9 + Math.min(i, 8) * 0.07, 1.3 + Math.min(i, 8) * 0.07, M.enter);
              if (r.head) return <div key={'h' + r.gi} style={{ position: 'absolute', left: 28, right: 28, top: r.y, height: 42, display: 'flex', alignItems: 'flex-end', paddingBottom: 6, boxSizing: 'border-box', font: `700 14px ${SANS}`, letterSpacing: 1.2, textTransform: 'uppercase', color: deep(150), opacity: ro }}>{r.head}</div>;
              const at = HI_AT[r.l]; const hi = at != null ? tw(t, at, at + 0.35, M.enter) : 0;
              return (
                <div key={r.l} style={{ position: 'absolute', left: 14, right: 14, top: r.y, height: 52, borderRadius: 10, padding: '0 14px', boxSizing: 'border-box', background: mix('#ffffff', tint(150), hi), display: 'flex', alignItems: 'center', gap: 14, opacity: ro }}>
                  <div style={{ width: 10, height: 10, borderRadius: 5, flex: 'none', background: mix(CB.line, OM_C, hi), transform: `scale(${1 + 0.6 * Math.sin(hi * Math.PI)})` }}></div>
                  <div style={{ flex: 1, minWidth: 0, display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 12 }}>
                    <div style={{ font: `500 17px ${SANS}`, color: CB.dim, whiteSpace: 'nowrap' }}>{r.l}</div>
                    <div style={{ font: `600 ${hi > 0.5 ? 21 : 19}px ${MONO}`, color: mix(CB.text, deep(150), hi), whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.v}</div>
                  </div>
                </div>
              );
            })}
          </div>
          <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 44, background: 'linear-gradient(rgba(255,255,255,0), #fff)' }}></div>
        </div>
      </div>
    </>
  );
}

function RackView({ T, K }) {
  useHue(LV.rack);
  const xf = zoomXf(T, K.Ra + 2.8, RK_F, 4.2, null, null, 1);
  if (xf.display === 'none') return null;
  const pan = tw(T, K.Ca, K.Ca + 1.3);
  const pull = tw(T, K.Cl, K.Cl + 1.2);
  const cableP = tw(T, K.Ca + 1.6, K.Ca + 4.6, M.move);
  const cardO = tw(T, K.Ca + 1.0, K.Ca + 1.6, M.enter);
  const r5 = tw(T, K.Ra + 3.4, K.Ra + 4.0, M.enter);
  const tray = tw(T, K.Ca + 0.8, K.Ca + 1.4, M.enter);
  const hiP = 1 - 0.6 * tw(T, K.Ra + 4.6, K.Ra + 5.2);
  const portPulse = T > K.Ca + 1.3 && T < K.Ca + 2.1 ? (T - K.Ca - 1.3) / 0.8 : -1;
  const drift = lerp(1, 1.03, tw(T, K.Ra + 4.1, K.Ca));
  return (
    <Layer xf={xf}>
      <div style={{ position: 'absolute', inset: 0, opacity: lerp(1, 0.1, pull), transform: `translateX(${-450 * pan}px) scale(${drift * lerp(1, 0.94, pull)})`, transformOrigin: `${960 + 450 * pan}px 540px` }}>
        <div style={{ position: 'absolute', left: OX, top: OY, width: 1360, height: 744 }}>
          <div style={{ position: 'absolute', left: 290, top: 20, width: 540, height: 18, borderRadius: 9, background: 'repeating-linear-gradient(90deg, #C3C9D6 0 4px, #DDE1E9 4px 22px)', border: '2px solid #B4BBCA', boxSizing: 'border-box', opacity: tray, transform: `scaleX(${tray})`, transformOrigin: 'left' }}></div>
          {RACKS.map((r, ri) => (
            <div key={r.name} style={{ opacity: ri ? r5 : 1 }}>
              <Cabinet r={r} isKey={!ri} hiP={hiP} T={T} />
              {r.slots.map((s, k) => <Device key={s[2]} rx={r.x} s={s} k={k + ri * 2} T={T} K={K} cableP={cableP} />)}
              <div style={{ position: 'absolute', left: r.x, top: 726, width: 300, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 10 }}>
                <div style={{ padding: '4px 16px', borderRadius: 16, background: ri ? '#fff' : C.acc, color: ri ? CB.text : '#fff', font: `600 22px ${MONO}`, boxShadow: '0 2px 8px rgba(24,33,58,0.1)' }}>{r.name}</div>
                <div style={{ font: `500 17px ${SANS}`, color: CB.dim }}>RITTAL-42 · 42 U</div>
              </div>
            </div>
          ))}
          <svg width="1360" height="744" style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
            <path d={CABLE} fill="none" stroke={CORAL_S} strokeWidth="18" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - cableP} />
            <path d={CABLE} fill="none" stroke={CORAL_D} strokeWidth="8" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - cableP} />
            <path d={CABLE} fill="none" stroke={CORAL} strokeWidth="5" strokeLinecap="round" pathLength="1" strokeDasharray="1 1" strokeDashoffset={1 - cableP} />
            {cableP >= 1 && [0, 0.5].map((ph) => <path key={ph} d={CABLE} fill="none" stroke="#fff" strokeWidth="4" strokeLinecap="round" pathLength="1" strokeDasharray="0.02 0.98" strokeDashoffset={-((T * 0.35 + ph) % 1)} />)}
            {PLUGS.map(([x, y, th], i) => (cableP > th ? <rect key={i} x={x - 7} y={y - 8} width="14" height="16" rx="3" fill={CORAL_D} stroke="#fff" strokeWidth="1.5" /> : null))}
            {portPulse >= 0 && <circle cx="268" cy="240" r={8 + portPulse * 32} fill="none" stroke={CORAL} strokeWidth="3" opacity={1 - portPulse} />}
          </svg>
          <ObjectPanel T={T} K={K} />
          <div style={{ position: 'absolute', left: 950, top: 80, width: 390, opacity: cardO, transform: `translateY(${(1 - cardO) * 20}px)`, background: '#fff', borderRadius: 18, padding: '26px 28px 10px', boxSizing: 'border-box', boxShadow: SHADOW }}>
            <div style={{ font: `600 15px ${MONO}`, color: CORAL_D, letterSpacing: 1.5, textTransform: 'uppercase' }}>Connection trace</div>
            <div style={{ position: 'relative', marginTop: 22 }}>
              <div style={{ position: 'absolute', left: 8, top: 10, width: 4, height: 4 * 88, borderRadius: 2, background: CB.line }}></div>
              <div style={{ position: 'absolute', left: 8, top: 10, width: 4, height: 4 * 88 * cableP, borderRadius: 2, background: CORAL }}></div>
              {TRACE.map(([a, b, th], i) => {
                const lit = tw(T, K.Ca + 1.6 + th * 3, K.Ca + 1.9 + th * 3, M.enter);
                return (
                  <div key={i} style={{ position: 'relative', height: 88, paddingLeft: 38 }}>
                    <div style={{ position: 'absolute', left: 0, top: 2, width: 20, height: 20, borderRadius: 10, background: lit > 0.5 ? CORAL : '#fff', border: `3px solid ${lit > 0.5 ? CORAL : CB.line2}`, boxSizing: 'border-box', transform: `scale(${1 + 0.35 * Math.sin(lit * Math.PI)})` }}></div>
                    <div style={{ font: `600 21px ${MONO}`, color: lit > 0.5 ? CB.text : CB.faint }}>{a}</div>
                    <div style={{ font: `400 18px ${SANS}`, color: CB.dim, marginTop: 4, opacity: 0.4 + 0.6 * lit }}>{b}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </Layer>
  );
}

// ---------- overlays ----------
function PathBar({ T, K, end }) {
  C = CB;
  const segs = [
    ['City', 'WEU/DE/FFM', K.Lo + 6.5, LV.city],
    ['Building', 'Mainzer Landstrasse 151', K.Fl - 1.4, LV.bldg],
    ['Floor', '2', K.Ro - 1.6, LV.floor],
    ['Room', '2.14', K.Ra - 1.4, LV.room],
    ['Rack', 'R04', K.Ra + 1.8, LV.rack],
  ];
  const c = tw(T, K.Cl + 0.3, K.Cl + 1.5);
  const fade = 1 - tw(T, end - 0.7, end - 0.05);
  const lastOn = segs.reduce((a, s, i) => (T >= s[2] ? i : a), -1);
  return (
    <div style={{ position: 'absolute', left: lerp(80, 960, c), top: lerp(48, 450, c), transform: `translateX(${lerp(0, -50, c)}%) scale(${lerp(1, 1.4, c)})`, transformOrigin: `${lerp(0, 50, c)}% 0`, display: 'flex', alignItems: 'center', gap: 14, opacity: fade }}>
      {segs.map(([l, v, at, h], i) => {
        const o = tw(T, at, at + 0.5, M.pop);
        if (o <= 0) return null;
        const act = Math.max(i === lastOn ? 1 : 0, c);
        return (
          <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 14, opacity: clampN(o), transform: `scale(${lerp(0.7, 1, o)})` }}>
            {i > 0 && <div style={{ width: 18, height: 3, borderRadius: 2, background: CB.line2 }}></div>}
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '9px 20px 9px 14px', borderRadius: 40, background: mix('#ffffff', hc(h), act), boxShadow: '0 4px 14px rgba(24,33,58,0.10)' }}>
              <div style={{ width: 14, height: 14, borderRadius: 7, background: act > 0.5 ? '#fff' : hc(h) }}></div>
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                <div style={{ font: `600 13px ${MONO}`, color: act > 0.5 ? '#fff' : CB.dim, letterSpacing: 1.5, textTransform: 'uppercase' }}>{l}</div>
                <div style={{ font: `600 24px ${MONO}`, color: act > 0.5 ? '#fff' : CB.text, whiteSpace: 'nowrap' }}>{v}</div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
function ModuleBadge({ T, K }) {
  const nav = tw(T, K.Lo + 0.6, K.Lo + 1.1, M.enter) * (1 - tw(T, K.Pr - 0.2, K.Pr + 0.2));
  const om = tw(T, K.Pr + 0.2, K.Pr + 0.7, M.enter) * (1 - tw(T, K.Ca - 0.2, K.Ca + 0.2));
  const items = [[nav, 'Navigator', 'Exploring locations', 0], [om, 'Object Management', 'Managing object properties', 1]];
  return (
    <>
      {items.map(([o, n, d, i]) => (o <= 0 ? null : (
        <div key={n} style={{ position: 'absolute', right: 60, top: 46, opacity: o, transform: `translateY(${(1 - o) * -12}px)`, display: 'flex', alignItems: 'center', gap: 14, padding: '10px 22px 10px 12px', borderRadius: 40, background: '#fff', boxShadow: '0 4px 14px rgba(24,33,58,0.10)' }}>
          {i ? <OMIcon size={40} /> : <NavIcon size={40} />}
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ font: `600 21px ${SANS}`, color: CB.text, whiteSpace: 'nowrap' }}>{n}</div>
            <div style={{ font: `400 15px ${SANS}`, color: CB.dim, whiteSpace: 'nowrap' }}>{d}</div>
          </div>
        </div>
      )))}
    </>
  );
}
function CloseCard({ T, K, end }) {
  const w = tw(T, K.Cl + 1.4, K.Cl + 2.0, M.enter);
  const fade = 1 - tw(T, end - 0.7, end - 0.05);
  if (w <= 0) return null;
  const mods = [['Navigator', 'Where it is'], ['Object Management', 'What it is']];
  return (
    <div style={{ opacity: fade }}>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 270, display: 'flex', justifyContent: 'center', opacity: w, transform: `translateY(${(1 - w) * 16}px)` }}><Wordmark size={72} mark={34} /></div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 640, display: 'flex', justifyContent: 'center', gap: 24 }}>
        {mods.map(([n, d], i) => {
          const p = tw(T, K.Cl + 2.0 + i * 0.3, K.Cl + 2.5 + i * 0.3, M.pop);
          return (
            <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '14px 28px 14px 16px', borderRadius: 40, background: '#fff', boxShadow: SHADOW, opacity: clampN(p * 2), transform: `scale(${lerp(0.7, 1, Math.min(1, p))})` }}>
              {i ? <OMIcon size={46} /> : <NavIcon size={46} />}
              <div style={{ font: `600 26px ${SANS}`, color: CB.text, whiteSpace: 'nowrap' }}>{n}</div>
              <div style={{ font: `400 24px ${SANS}`, color: CB.dim, whiteSpace: 'nowrap' }}>{d}</div>
            </div>
          );
        })}
      </div>
      {(() => {
        const mp = tw(T, K.Cl + 2.7, K.Cl + 3.6, M.enter);
        if (mp <= 0) return null;
        return (
          <div style={{ position: 'absolute', left: 0, right: 0, top: 740, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 12 }}>
            {[0, 1, 2, 3, 4, 5].map((k) => {
              const q = clampN(mp * 3 - k * 0.25);
              return <div key={k} style={{ width: 54, height: 54, borderRadius: 14, background: `oklch(0.62 0.13 ${[285, 250, 215, 180, 150, 35][k]})`, opacity: q * 0.9, transform: `scale(${lerp(0.4, 1, q)})`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><div style={{ width: 22, height: 22, borderRadius: k % 2 ? 11 : 4, border: '3px solid rgba(255,255,255,0.85)', boxSizing: 'border-box' }}></div></div>;
            })}
            <div style={{ marginLeft: 8, padding: '12px 24px', borderRadius: 40, background: CB.navy, font: `600 24px ${SANS}`, color: '#fff', whiteSpace: 'nowrap', opacity: clampN(mp * 2 - 0.6), transform: `translateX(${(1 - clampN(mp * 2 - 0.6)) * -16}px)` }}>+ many more modules</div>
          </div>
        );
      })()}
    </div>
  );
}

function Piece({ tweaks }) {
  const { T, CUES, authoredTotal } = useComposition();
  C = CB;
  const K = { Pb: CUES.Problem, So: CUES.Solution, Lo: CUES.Locations, B: CUES.Building, Fl: CUES.Floor, Ro: CUES.Room, Ra: CUES.Rack, Pr: CUES.Properties, Ca: CUES.Cabling, Cl: CUES.Close };
  const end = authoredTotal;
  const caps = [
    { at: K.Pb + 0.4, text: "Without one system, network documentation ends up scattered across spreadsheets, old diagrams and people's memory." },
    { at: K.Pb + 6.0, text: 'Finding a device or tracing a cable takes hours, and mistakes cause outages.' },
    { at: K.So + 0.6, text: 'FNT Command brings it all together in one model.' },
    { at: K.So + 4.2, text: 'The Navigator is for exploring locations. Object Management is for managing object properties. And there are many more modules.' },
    { at: K.Lo + 0.4, text: 'In the Navigator, every asset starts with a location.' },
    { at: K.Lo + 3.6, text: 'Cities are coded by region, country and city: WEU/DE/FFM is Frankfurt.' },
    { at: K.B + 0.4, text: 'Within a city, each site is a building, named by its street address.' },
    { at: K.Fl + 0.3, text: 'Each building is divided into floors…' },
    { at: K.Ro + 0.3, text: '…and each floor into rooms.' },
    { at: K.Ra + 0.3, text: 'Racks sit inside rooms, and every device has a fixed position in its rack.' },
    { at: K.Pr + 0.3, text: 'In Object Management, each object carries its own properties: serial number, management IP, CORIA-ID and many more.' },
    { at: K.Pr + 6.4, text: 'They cover everything from network details to lifecycle and ownership.' },
    { at: K.Ca + 0.3, text: 'Cables run from device ports through patch panels, so every connection can be traced end to end.' },
    { at: K.Cl + 0.4, until: end - 0.5, text: 'City, building, floor, room, rack: every asset has a precise address and documented properties.' },
  ];
  const fade = 1 - tw(T, end - 0.7, end - 0.05);
  const gh = nh(kf(T, [[K.So, 35], [K.So + 1, -70], [K.B, -70], [K.B + 1, -105], [K.Fl, -105], [K.Fl + 1, -140], [K.Ro, -140], [K.Ro + 1, -175], [K.Ra, -175], [K.Ra + 1, -210], [K.Ca, -210], [K.Ca + 1, -325], [K.Cl, -325], [K.Cl + 1, -430]])[0]);
  return (
    <div data-screen-label={`t=${Math.floor(T)}s`} style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: CB.bg }}>
      <div style={{ position: 'absolute', inset: 0, background: `radial-gradient(ellipse 65% 60% at 50% 50%, oklch(0.93 0.05 ${gh.toFixed(1)}), transparent 75%)` }}></div>
      <div style={{ position: 'absolute', inset: -40, backgroundImage: 'radial-gradient(circle, #DDD8CD 1.4px, transparent 1.8px)', backgroundSize: '40px 40px', transform: `translate(${(T * 3) % 40}px, ${(T * 1.5) % 40}px)` }}></div>
      <div style={{ position: 'absolute', inset: 0, opacity: fade }}>
        <Problem T={T} K={K} />
        <Solution T={T} K={K} />
        <World T={T} K={K} />
        <Buildings T={T} K={K} />
        <Floors T={T} K={K} />
        <FloorPlan T={T} K={K} />
        <Room T={T} K={K} />
        <RackView T={T} K={K} />
      </div>
      <PathBar T={T} K={K} end={end} />
      <ModuleBadge T={T} K={K} />
      <CloseCard T={T} K={K} end={end} />
      {tweaks.captions !== false && (
        <Captions items={caps} style={{ left: '50%', right: 'auto', bottom: 40, transform: 'translateX(-50%)', width: 'max-content', maxWidth: 1560, padding: '14px 30px', borderRadius: 14, background: 'rgba(24,33,58,0.94)', font: `500 34px ${SANS}`, color: '#F4F2EE', textShadow: 'none', lineHeight: 1.3, textAlign: 'center' }} />
      )}
    </div>
  );
}

function FNTVideo() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <>
      <CompositionStage width={1920} height={1080} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#F4F2EE">
        <Piece tweaks={t} />
      </CompositionStage>
      <TweaksPanel>
        <TweakSection label="Playback" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        <TweakToggle label="Captions" value={t.captions} onChange={(v) => setTweak('captions', v)} />
      </TweaksPanel>
    </>
  );
}

window.FNTVideo = FNTVideo;
